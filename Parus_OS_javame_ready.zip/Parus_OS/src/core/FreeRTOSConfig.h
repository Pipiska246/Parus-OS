// ================================================================
//  FreeRTOSConfig.h — minimal config for arduino-pico + FreeRTOS SMP
//
//  This file is required by the "FreeRTOS" Arduino library (Earle
//  Philhower's RP2040 SMP port of FreeRTOS-Kernel). The Arduino IDE
//  picks up FreeRTOSConfig.h automatically as long as it sits next to
//  the .ino file. See README.md for install instructions for the
//  library itself.
// ================================================================
#pragma once

#define configUSE_PREEMPTION                   1
#define configUSE_TIME_SLICING                 1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 1
#define configUSE_TICKLESS_IDLE                 0

#define configCPU_CLOCK_HZ                     ( 125000000 )
#define configTICK_RATE_HZ                      ( 1000 )

// Two RP2040 cores, SMP scheduler.
#define configNUM_CORES                         2
#define configUSE_CORE_AFFINITY                 1
#define configRUN_MULTIPLE_PRIORITIES           1
#define configUSE_TIME_SLICING                  1

#define configMAX_PRIORITIES                    8
#define configMINIMAL_STACK_SIZE                 ( 512 )
#define configMAX_TASK_NAME_LEN                  16
#define configUSE_16_BIT_TICKS                   0
#define configIDLE_SHOULD_YIELD                  1

#define configUSE_MUTEXES                        1
#define configUSE_RECURSIVE_MUTEXES              1
#define configUSE_COUNTING_SEMAPHORES            1
#define configQUEUE_REGISTRY_SIZE                8

#define configSUPPORT_STATIC_ALLOCATION           0
#define configSUPPORT_DYNAMIC_ALLOCATION           1
#define configTOTAL_HEAP_SIZE                     ( 64 * 1024 )
#define configAPPLICATION_ALLOCATED_HEAP           0

#define configUSE_IDLE_HOOK                       0
#define configUSE_TICK_HOOK                       0
#define configCHECK_FOR_STACK_OVERFLOW             2
#define configUSE_MALLOC_FAILED_HOOK               1
#define configUSE_DAEMON_TASK_STARTUP_HOOK         0

#define configGENERATE_RUN_TIME_STATS              0
#define configUSE_TRACE_FACILITY                   0
#define configUSE_STATS_FORMATTING_FUNCTIONS       0

#define configUSE_CO_ROUTINES                      0
#define configMAX_CO_ROUTINE_PRIORITIES            1

// Software timers - used by some libraries; keep them available.
#define configUSE_TIMERS                           1
#define configTIMER_TASK_PRIORITY                  2
#define configTIMER_QUEUE_LENGTH                   10
#define configTIMER_TASK_STACK_DEPTH               1024

// Allow direct-to-task notifications.
#define configUSE_TASK_NOTIFICATIONS               1

// Include the optional task/queue/timer functions we touch.
#define INCLUDE_vTaskPrioritySet                   1
#define INCLUDE_uxTaskPriorityGet                  1
#define INCLUDE_vTaskDelete                        1
#define INCLUDE_vTaskSuspend                       1
#define INCLUDE_vTaskDelayUntil                    1
#define INCLUDE_vTaskDelay                         1
#define INCLUDE_xTaskGetSchedulerState              1
#define INCLUDE_xTaskGetCurrentTaskHandle            1
#define INCLUDE_uxTaskGetStackHighWaterMark          1
#define INCLUDE_xTaskGetIdleTaskHandle               0
#define INCLUDE_eTaskGetState                        1
#define INCLUDE_xEventGroupSetBitFromISR             1
#define INCLUDE_xTimerPendFunctionCall                1
#define INCLUDE_xTaskAbortDelay                       1
#define INCLUDE_xTaskGetHandle                        1
#define INCLUDE_xTaskResumeFromISR                    1

#define configASSERT( x ) if ( (x) == 0 ) { taskDISABLE_INTERRUPTS(); for( ;; ); }
