#pragma once
#include <Arduino.h>

// ================================================================
//  buttons.h — структуры кнопок и энкодера
// ================================================================

struct Btn {
    uint8_t pin;
    bool state = false, last = false;
    unsigned long pressedAt = 0, lastRepeat = 0;

    bool pressed() { return state && !last; }
    bool released() { return !state && last; }
    bool held(unsigned long ms) { return state && (millis() - pressedAt) >= ms; }
    bool repeat() {
        if (!state) return false;
        unsigned long now = millis();
        if (!last) return false;
        if (now - pressedAt > 350 && now - lastRepeat > 100) {
            lastRepeat = now;
            return true;
        }
        return false;
    }
    void update() {
        bool raw = digitalRead(pin) == LOW;
        last = state;
        state = raw;
        if (state && !last) {
            pressedAt = millis();
            lastRepeat = millis();
        }
    }
};

struct EncBtn {
    bool state = false, last = false;
    unsigned long pressedAt = 0;

    bool pressed() { return state && !last; }
    bool released() { return !state && last; }
    void update(int pin) {
        bool raw = (digitalRead(pin) == LOW);
        last = state;
        state = raw;
        if (state && !last) pressedAt = millis();
    }
};

// Глобальные экземпляры (определены в .ino)
extern Btn bUp, bDown, bLeft, bRight, bOk, bHome, bCancel;
extern EncBtn bEncBtn;
