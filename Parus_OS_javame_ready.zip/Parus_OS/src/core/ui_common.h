#pragma once
#include <Arduino.h>

// ================================================================
//  ui_common.h — общие константы для UI (размеры шрифта, экрана,
//  кнопки) чтобы не дублировать их в каждом модуле.
// ================================================================

// ---- Размеры дисплея ----
#define UI_DISPLAY_WIDTH   160
#define UI_DISPLAY_HEIGHT  128

// ---- Шрифт (6x8 пикселей) ----
#define UI_CHAR_W          6
#define UI_CHAR_H          8
#define UI_LINE_H          10

// ---- Внешние объявления глобальных кнопок (определены в .ino) ----
struct Btn {
  uint8_t pin;
  bool state = false, last = false;
  unsigned long pressedAt = 0, lastRepeat = 0;

  bool pressed() { return state && !last; }
  bool released() { return !state && last; }
  bool held(unsigned long ms) { return state && (millis() - pressedAt) >= ms; }
  bool repeat() {
    if (!state) return false;
    unsigned long now = millis();
    if (!last) return false;
    if (now - pressedAt > 350 && now - lastRepeat > 100) {
      lastRepeat = now;
      return true;
    }
    return false;
  }
  void update() {
    bool raw = digitalRead(pin) == LOW;
    last = state;
    state = raw;
    if (state && !last) {
      pressedAt = millis();
      lastRepeat = millis();
    }
  }
};

struct EncBtn {
  bool state = false, last = false;
  unsigned long pressedAt = 0;

  bool pressed() { return state && !last; }
  bool released() { return !state && last; }
  void update(int pin) {
    bool raw = (digitalRead(pin) == LOW);
    last = state;
    state = raw;
    if (state && !last) pressedAt = millis();
  }
};

// ---- Глобальные кнопки (определены в TextReaderVFS.ino) ----
extern Btn bUp, bDown, bLeft, bRight, bOk, bHome, bCancel;
extern EncBtn bEncBtn;

// ---- Функции отображения (определены в .ino) ----
void sendFillScreen(uint8_t r, uint8_t g, uint8_t b);
void sendSetCursor(uint16_t x, uint16_t y);
void sendSetTextColor(uint8_t r, uint8_t g, uint8_t b);
void sendPrintText(const char* t);
void sendPrintStr(const String& s);
void sendFillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);
void sendDrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);
void sendDrawPixel(uint16_t x, uint16_t y, uint8_t r, uint8_t g, uint8_t b);
void sendDrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t r, uint8_t g, uint8_t b);

// ---- Чтение энкодера ----
int readEncoderDelta();

// ---- UTF-8 helpers ----
int utf8Len(const String& s);
String utf8Substr(const String& s, int from, int to);
