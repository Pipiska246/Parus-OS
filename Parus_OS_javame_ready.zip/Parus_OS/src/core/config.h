#pragma once

// Used by vfs.cpp only - kept separate from the pin/macro definitions in the
// main .ino so there's no risk of clashing with its BTN_*/ENC_* macros.

// ----- USB Host (external USB flash drive) -----
// Requires pio-usb. D- is automatically DP_PIN+1 (so GPIO3 must stay free).
#define USB_HOST_DP_PIN   2

// ----- Virtual filesystem prefixes (Linux-style device names) -----
// /sda          = onboard flash (LittleFS)
// /sdb1,/sdb2.. = partitions on the USB flash drive (sdb1 if it's a single,
//                 unpartitioned "superfloppy" drive - which is most of them)
#define VFS_INTERNAL_PREFIX   "/sda"
#define VFS_EXTERNAL_BASE     "/sdb"   // + partition number (1-based)
#define VFS_MAX_EXT_PARTS     8

// ----- Audio engine (audio.h/.cpp) -----
#define AUDIO_PIN                26     // PWM audio output pin
#define AUDIO_DEFAULT_SAMPLE_RATE 8000   // fallback rate for headerless raw PCM
// Ring buffer size in samples (mono, int16). Must be a power of two.
// ~8192 samples @ 16kHz =~ 0.5s of slack to absorb slow USB/FAT reads.
#define AUDIO_RING_SAMPLES   8192
