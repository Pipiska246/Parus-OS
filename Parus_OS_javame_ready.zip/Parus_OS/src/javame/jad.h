#pragma once
#include <Arduino.h>
#include <vector>

// ================================================================
//  jad.h — разбор JAD-дескрипторов и JAR-манифестов (META-INF/
//  MANIFEST.MF). Оба формата - текст "Ключ: Значение" по строкам,
//  поэтому парсер один на двоих.
// ================================================================

struct JavaAttrs {
  std::vector<String> keys;
  std::vector<String> vals;

  String get(const String &key) const;      // "" если нет
  bool   has(const String &key) const;
};

// Разбирает буфер "Key: Value\n..." (принимает CRLF/LF). Значения,
// перенесённые по MANIFEST-правилу (строка, начинающаяся с пробела -
// продолжение предыдущего значения), склеиваются.
bool javaAttrsParse(const uint8_t *data, size_t len, JavaAttrs &out);
bool javaAttrsParse(const String &text, JavaAttrs &out);

struct MidletInfo {
  String name;         // MIDlet-Name
  String vendor;       // MIDlet-Vendor
  String version;      // MIDlet-Version
  String mainClass;    // из MIDlet-1: "Label, icon, Class" -> "Class" (в форме com/foo/Bar)
  String jarUrl;       // MIDlet-Jar-URL (обычно просто "App.jar")
  String iconPath;     // из MIDlet-1 или MIDlet-Icon
  bool valid() const { return mainClass.length() > 0; }
};

// Достаёт MidletInfo из уже разобранных атрибутов (JAD или MANIFEST).
// mainClass возвращается в форме со слэшами ("com/foo/Bar"), как
// требует загрузчик классов (jvm_interp.cpp).
bool javaMidletFromAttrs(const JavaAttrs &a, MidletInfo &out);
