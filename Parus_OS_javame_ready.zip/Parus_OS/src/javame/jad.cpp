#include "jad.h"

// ================================================================
//  jad.cpp — разбор "Key: Value" (JAD / MANIFEST.MF).
// ================================================================

namespace {
String trim(const String &s) {
  int a = 0, b = s.length();
  while (a < b && (s[a] == ' ' || s[a] == '\t' || s[a] == '\r' || s[a] == '\n')) a++;
  while (b > a && (s[b - 1] == ' ' || s[b - 1] == '\t' || s[b - 1] == '\r' || s[b - 1] == '\n')) b--;
  return s.substring(a, b);
}
} // namespace

String JavaAttrs::get(const String &key) const {
  for (size_t i = 0; i < keys.size(); i++) if (keys[i].equalsIgnoreCase(key)) return vals[i];
  return "";
}
bool JavaAttrs::has(const String &key) const {
  for (size_t i = 0; i < keys.size(); i++) if (keys[i].equalsIgnoreCase(key)) return true;
  return false;
}

bool javaAttrsParse(const uint8_t *data, size_t len, JavaAttrs &out) {
  out.keys.clear();
  out.vals.clear();

  String line;
  size_t i = 0;
  auto flushLine = [&](const String &raw) {
    // Продолжение MANIFEST-значения: строка начинается с пробела.
    if (raw.length() > 0 && (raw[0] == ' ' || raw[0] == '\t')) {
      if (!out.vals.empty()) out.vals.back() += trim(raw);
      return;
    }
    int colon = raw.indexOf(':');
    if (colon <= 0) return;             // пустые/битые строки пропускаем
    String k = trim(raw.substring(0, colon));
    String v = trim(raw.substring(colon + 1));
    if (k.length() == 0) return;
    out.keys.push_back(k);
    out.vals.push_back(v);
  };

  while (i <= len) {
    char c = (i < len) ? (char)data[i] : '\n';
    if (c == '\n') {
      // не тримим ведущий пробел здесь - он нужен для детекта продолжения
      String raw = line;
      if (raw.length() && raw[raw.length() - 1] == '\r') raw.remove(raw.length() - 1);
      flushLine(raw);
      line = "";
    } else {
      line += c;
    }
    i++;
  }
  return !out.keys.empty();
}

bool javaAttrsParse(const String &text, JavaAttrs &out) {
  return javaAttrsParse((const uint8_t *)text.c_str(), text.length(), out);
}

bool javaMidletFromAttrs(const JavaAttrs &a, MidletInfo &out) {
  out.name    = a.get("MIDlet-Name");
  out.vendor  = a.get("MIDlet-Vendor");
  out.version = a.get("MIDlet-Version");
  out.jarUrl  = a.get("MIDlet-Jar-URL");
  out.iconPath = a.get("MIDlet-Icon");

  // MIDlet-1: "DisplayName, /icon.png, com.foo.Bar"
  String m1 = a.get("MIDlet-1");
  if (m1.length() > 0) {
    int c1 = m1.indexOf(',');
    int c2 = (c1 >= 0) ? m1.indexOf(',', c1 + 1) : -1;
    if (c1 >= 0 && c2 >= 0) {
      String label = m1.substring(0, c1);        label.trim();
      String icon  = m1.substring(c1 + 1, c2);   icon.trim();
      String cls   = m1.substring(c2 + 1);       cls.trim();
      if (out.name.length() == 0) out.name = label;
      if (out.iconPath.length() == 0 && icon.length()) out.iconPath = icon;
      cls.replace('.', '/');                     // com.foo.Bar -> com/foo/Bar
      out.mainClass = cls;
    }
  }
  if (out.name.length() == 0) out.name = out.mainClass;
  return out.valid();
}
