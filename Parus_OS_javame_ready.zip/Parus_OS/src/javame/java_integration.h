// ============================================================
//  java_integration.h
//  Вставь этот файл рядом с .ino и сделай:
//    #include "src/javame/java_integration.h"
//  СРАЗУ ПОСЛЕ updateButtons() в .ino, там же, где уже подключён
//  turbine_integration.h (см. инструкцию в самом низу файла) - НЕ
//  в самом начале, иначе будет "not declared in this scope".
//
//  Сам движок (парсер .class, интерпретатор байткода, натив-мост
//  System/String/lcdui) живёт в src/javame/jvm.* и не знает о .ino -
//  этот файл, наоборот, ничего не знает о JVM изнутри и просто
//  дергает публичный jvm.h так же, как turbine_integration.h дергает
//  Turbine (см. README, раздел "Архитектура").
// ============================================================
#pragma once
#include "jvm.h"

// ── фильтр: .class файлы в файловом менеджере ────────────────
bool isClassFile(const String& filename) {
  String fn = filename; fn.toLowerCase();
  return fn.endsWith(".class");
}

// ── launcher (полноэкранный, из файлового браузера) ──────────
// В отличие от runTuFile() ничего не рисует сам после успешного
// запуска - экран сразу принадлежит приложению (текстовая консоль
// System.out.println либо canvas.paint(), см. jvm_natives.cpp).
void runJavaFile(const String& path) {
  sendFillScreen(0, 0, 0);
  sendSetCursor(14, 55);
  sendSetTextColor(200, 200, 0);
  sendPrintText("Loading JavaME app...");

  String err;
  if (!jvmRunMidlet(path, err)) {
    sendFillScreen(0, 0, 0);
    sendFillRect(0, 0, DISPLAY_WIDTH, 13, 60, 0, 0);
    sendSetCursor(2, 2);
    sendSetTextColor(255, 220, 220);
    sendPrintText("JavaME error");
    sendSetCursor(2, 30);
    sendSetTextColor(255, 150, 150);
    String e = err;
    if ((int)e.length() > 26) e = e.substring(0, 25) + "..";
    sendPrintStr(e);
    sendSetCursor(2, 100);
    sendSetTextColor(130, 130, 130);
    sendPrintText("(see /proc/jvm - HOME=back)");
    delay(1500);
    currentState = STATE_FILE_BROWSER;
    drawFileBrowser();
  }
}

// ── "redraw" для refreshCurrentScreen() ──────────────────────
// Как и остальные draw*() в проекте, ничего не решает сама -
// просто перерисовывает то, что уже есть (текущий Canvas, если он
// у MIDlet-а есть; для чисто консольных приложений System.out уже
// нарисовал всё, что нужно, в момент println() - см. jvm_natives.cpp).
void drawJavaRunner() {
  jvmTick();
}

// ── STATE_JAVA_RUNNER handler — вставь в loop() ───────────────
void handleJavaRunner() {
  jvmTick(); // paint()/keyPressed() активного Canvas, если есть

  if (jvmWantsExit() || bHome.pressed() || bCancel.pressed()) {
    currentState = STATE_FILE_BROWSER;
    drawFileBrowser();
  }
}

// ============================================================
//  КАК ПОДКЛЮЧИТЬ к Parus_OS.ino (актуальная схема проекта)
//  ─────────────────────────────────────────────────────────────
//  1. Подключи ПОСЛЕ updateButtons() (т.е. там же, где уже
//     подключён turbine_integration.h - после того как SerialPC,
//     DISPLAY_WIDTH/HEIGHT, sendFillScreen/sendSetCursor/... и
//     bUp/bDown/.../bCancel уже определены):
//
//       #include "src/javame/java_integration.h"
//
//  2. В enum AppState добавь STATE_JAVA_RUNNER (после STATE_TU_RUNNER).
//
//  3. В обоих местах открытия файла из браузера (лямбда openSelected
//     в STATE_FILE_BROWSER и блок "Open" в STATE_FILE_BROWSER_MENU)
//     добавь ветку ПЕРЕД isTuFile(...) (или после - порядок неважен,
//     главное чтобы .class не попал в "Unsupported file type"):
//
//       } else if (isClassFile(e.name)) {
//         currentState = STATE_JAVA_RUNNER;
//         runJavaFile(fullPath);
//
//  4. В refreshCurrentScreen() (там же, где `case STATE_TU_RUNNER:`)
//     добавь:
//       case STATE_JAVA_RUNNER: drawJavaRunner(); break;
//
//  5. В loop(), рядом с существующим
//     "else if (currentState == STATE_TU_RUNNER) { handleTuRunner(encDelta); }"
//     добавь:
//       else if (currentState == STATE_JAVA_RUNNER) {
//         handleJavaRunner();
//       }
//
//  6. В appLaunchByName() (bin_vfs.cpp launcher) добавь "java" туда же,
//     где уже перечислены "editor"/"imageview"/"tu" (программе нужен
//     файл-аргумент, поэтому "run java" без пути просто открывает
//     файловый браузер, чтобы выбрать .class):
//
//       if (name == "editor" || name == "imageview" || name == "tu" || name == "java") {
//
//  7. В setup(), рядом с bootStep("Init turbine engine", true), добавь:
//       jvmEngineInit();
//
//  .class-файлы кидаются в /sda/java/ (см. JVM_APPS_DIR в
//  jvm_config.h) - оттуда их же подхватывает автопоиск зависимых
//  классов (наследование), даже если MIDlet запущен из другой
//  директории.
//
//  Известные ограничения движка - см. docs/HISTORY.md, раздел
//  "JavaME" (нет GC, нет long/double, нет Form/TextBox/List/Image
//  из lcdui, нет верификатора байткода, набор опкодов - подмножество
//  из jvm_interp_exec.cpp).
// ============================================================
