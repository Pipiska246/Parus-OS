#pragma once
#include <Arduino.h>
#include "jvm_object.h"

// ================================================================
//  jvm_natives.h — методы, которые эта VM не интерпретирует из
//  байткода, а реализует напрямую на C++: часть java/lang/*,
//  java/io/PrintStream, и урезанный javax/microedition/lcdui/*
//  (Graphics/Canvas/Display), связанный с существующим дисплейным
//  UART-мостом Parus OS (sendFillRect/sendDrawLine/... в .ino).
//
//  Полный MIDP тут не реализован - см. docs/HISTORY.md, раздел
//  "JavaME — известные ограничения", там же список того, что
//  реально стоит портировать дальше (список layout/форм/итемов).
// ================================================================

// true для классов, которые эта VM обслуживает нативно (значит,
// jvm_interp.cpp не должен пытаться грузить для них .class-файл).
bool jvmIsNativeClassName(const String &className);

// Сбрасывает состояние натива (текущий Canvas/Display, буфер
// StringBuffer-ов и т.п.) - вызывается из jvmResetRuntime().
void jvmNativesReset();

// Основная точка входа для вызовов методов на нативных классах
// (или на объектах, чей classId==-1 / OBJ_STRING / OBJ_NATIVE).
bool jvmNativeInvoke(const String &className, const String &methodName,
                     const String &descriptor, JRef thisRef,
                     JWord *args, int argCount,
                     JWord &outResult, bool &hasResult, String &err);

// Вызывается из главного UI-цикла (.ino) на каждый "тик" экрана
// STATE_JAVA: если у текущего запущенного MIDlet есть активный
// Canvas (через Display.setCurrent(canvas)), перерисовывает его
// (canvas.paint(Graphics)) и рассылает нажатия кнопок в keyPressed(int).
// midletClassId/midletRef - экземпляр текущего MIDlet, из jvm.cpp.
void jvmNativesTick(int midletClassId, JRef midletRef);

// true, если MIDlet вызвал notifyDestroyed()/System.exit() - .ino должен
// вернуться из STATE_JAVA в меню на следующем тике.
bool jvmNativeWantsExit();

// getstatic/putstatic на *нативном* классе (сейчас - только
// java/lang/System.{out,err}) не могут идти через обычный
// jvmResolveClass (у System нет .class-файла) - перехватываются
// прямо в опкодах getstatic/putstatic (см. jvm_interp_exec.cpp).
bool jvmNativeGetStaticField(const String &cls, const String &name, const String &desc, JWord &outValue);

// Есть ли у запущенного MIDlet активный Canvas, ожидающий перерисовки
// (используется .ino, чтобы понять, кто сейчас "владеет" экраном -
// сам движок JavaME, или ещё стоит показывать консоль System.out).
bool jvmNativesHasActiveCanvas();
