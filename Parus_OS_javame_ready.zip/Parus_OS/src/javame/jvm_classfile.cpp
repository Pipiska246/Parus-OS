#include "jvm_classfile.h"
#include "../vfs/vfs.h"

namespace {

// Небольшой курсор поверх байт файла, целиком читаемого в RAM.
// class-файлы простых MIDlet-ов - единицы КБ, так что это не
// расточительно (и сильно проще, чем стримить .class байт-в-байт
// через VfsFile на каждый read()).
struct Cursor {
  const std::vector<uint8_t> &b;
  size_t pos = 0;
  bool ok = true;

  explicit Cursor(const std::vector<uint8_t> &buf) : b(buf) {}

  uint8_t u8() {
    if (pos >= b.size()) { ok = false; return 0; }
    return b[pos++];
  }
  uint16_t u16() { uint16_t hi = u8(); return (hi << 8) | u8(); }
  uint32_t u32() { uint32_t hi = u16(); return (hi << 16) | u16(); }
  int32_t  s32() { return (int32_t)u32(); }

  bool skip(size_t n) {
    if (pos + n > b.size()) { ok = false; return false; }
    pos += n;
    return true;
  }
};

bool readWholeFile(const String &path, std::vector<uint8_t> &out, String &errOut) {
  VfsFile f;
  if (!f.openRead(path)) { errOut = "cannot open " + path; return false; }
  uint32_t sz = f.size();
  out.resize(sz);
  size_t got = sz ? f.read(out.data(), sz) : 0;
  f.close();
  if (got != sz) { errOut = "short read on " + path; return false; }
  return true;
}

bool parseConstantPool(Cursor &c, RawClassFile &out, String &errOut) {
  uint16_t cpCount = c.u16();
  out.cp.resize(cpCount); // индекс 0 не используется, как в спеке
  for (uint16_t i = 1; i < cpCount && c.ok; i++) {
    CpEntry e;
    uint8_t tag = c.u8();
    switch (tag) {
      case CP_UTF8: {
        e.tag = CP_UTF8;
        uint16_t len = c.u16();
        String s;
        s.reserve(len);
        for (uint16_t k = 0; k < len; k++) s += (char)c.u8();
        e.utf8 = s;
        break;
      }
      case CP_INTEGER: case CP_FLOAT:
        e.tag = (CpTag)tag;
        e.intOrFloatBits = c.s32();
        break;
      case CP_LONG: case CP_DOUBLE:
        // long/double в кучу этой VM пока не заводим (см. jvm_config.h
        // и HISTORY.md - "известные ограничения"). Пропускаем 8 байт
        // и, по спеке JVM, следующий индекс пула тоже "занят".
        e.tag = (CpTag)tag;
        c.skip(8);
        i++;
        break;
      case CP_CLASS:
        e.tag = CP_CLASS;
        e.nameIndex = c.u16();
        break;
      case CP_STRING:
        e.tag = CP_STRING;
        e.nameIndex = c.u16(); // индекс UTF8 с содержимым строки
        break;
      case CP_FIELDREF: case CP_METHODREF: case CP_INTERFACE_METHODREF:
        e.tag = (CpTag)tag;
        e.classIndex = c.u16();
        e.nameAndTypeIndex = c.u16();
        break;
      case CP_NAME_AND_TYPE:
        e.tag = CP_NAME_AND_TYPE;
        e.nameIndex = c.u16();
        e.descriptorIndex = c.u16();
        break;
      default:
        errOut = "unsupported constant pool tag " + String((int)tag) +
                 " at entry " + String((int)i) +
                 " (MethodHandle/MethodType/InvokeDynamic/module-info "
                 "are not CLDC 1.1 and this VM does not implement them)";
        return false;
    }
    out.cp[i] = e;
  }
  if (!c.ok) { errOut = "truncated constant pool"; return false; }
  return true;
}

// Пропускает содержимое одного attribute_info целиком (имя ещё не
// прочитано интерпретатором - обычно это неинтересные для нас вещи
// вроде LineNumberTable, SourceFile и т.п.)
bool skipAttribute(Cursor &c) {
  c.u16();          // attribute_name_index
  uint32_t len = c.u32();
  return c.skip(len);
}

bool parseCodeAttribute(Cursor &c, MethodInfo &m, String &errOut) {
  m.maxStack  = c.u16();
  m.maxLocals = c.u16();
  uint32_t codeLen = c.u32();
  if (codeLen == 0 || codeLen > 0xFFFF) { errOut = "bad code_length"; return false; }
  m.code.resize(codeLen);
  for (uint32_t i = 0; i < codeLen; i++) m.code[i] = c.u8();

  uint16_t excLen = c.u16();
  m.handlers.resize(excLen);
  for (uint16_t i = 0; i < excLen; i++) {
    ExceptionHandler h;
    h.startPc   = c.u16();
    h.endPc     = c.u16();
    h.handlerPc = c.u16();
    h.catchType = c.u16();
    m.handlers[i] = h;
  }
  // Вложенные атрибуты Code (StackMapTable и т.п.) нам не нужны -
  // верификатора у этой VM нет, пропускаем как обычные attribute_info.
  uint16_t attrCount = c.u16();
  for (uint16_t i = 0; i < attrCount; i++) if (!skipAttribute(c)) return false;
  return c.ok;
}

bool parseMethodsOrFields(Cursor &c, RawClassFile &out, bool isMethods, String &errOut) {
  uint16_t count = c.u16();
  for (uint16_t i = 0; i < count && c.ok; i++) {
    uint16_t access = c.u16();
    uint16_t nameIdx = c.u16();
    uint16_t descIdx = c.u16();
    uint16_t attrCount = c.u16();

    String name = out.utf8At(nameIdx);
    String desc = out.utf8At(descIdx);

    MethodInfo mi; FieldInfo fi;
    mi.accessFlags = fi.accessFlags = access;
    mi.name = fi.name = name;
    mi.descriptor = fi.descriptor = desc;

    for (uint16_t a = 0; a < attrCount; a++) {
      uint16_t attrNameIdx = c.u16();
      uint32_t attrLen = c.u32();
      size_t before = c.pos;
      String attrName = out.utf8At(attrNameIdx);
      if (isMethods && attrName == "Code") {
        if (!parseCodeAttribute(c, mi, errOut)) return false;
      } else {
        c.skip(attrLen);
      }
      // Гарантия целостности на случай, если какой-то Code-парсер
      // прочитал не ровно attrLen байт (защита от рассинхрона курсора).
      size_t consumed = c.pos - before;
      if (consumed != attrLen) { c.pos = before; c.skip(attrLen); }
    }
    if (isMethods) out.methods.push_back(mi); else out.fields.push_back(fi);
  }
  return c.ok;
}

} // namespace

const String &RawClassFile::utf8At(uint16_t idx) const {
  static const String kEmpty = "";
  if (idx == 0 || idx >= cp.size() || cp[idx].tag != CP_UTF8) return kEmpty;
  return cp[idx].utf8;
}

String RawClassFile::thisClassName() const {
  if (thisClassIdx == 0 || thisClassIdx >= cp.size()) return "";
  return utf8At(cp[thisClassIdx].nameIndex);
}

String RawClassFile::superClassName() const {
  if (superClassIdx == 0 || superClassIdx >= cp.size()) return "";
  return utf8At(cp[superClassIdx].nameIndex);
}

bool jvmParseClassFile(const String &path, RawClassFile &out, String &errOut) {
  std::vector<uint8_t> buf;
  if (!readWholeFile(path, buf, errOut)) return false;

  Cursor c(buf);
  uint32_t magic = c.u32();
  if (magic != 0xCAFEBABEu) { errOut = path + ": bad magic (not a .class file)"; return false; }

  out.minorVersion = c.u16();
  out.majorVersion = c.u16();
  // 45..52 покрывает JDK 1.1 .. Java SE 8 javac -target — практический
  // диапазон для CLDC 1.1/1.3-совместимых сборок (multi-release
  // class-файлы и record/sealed classes majorVersion>52 всё равно
  // используют attribute-и, которых у нас нет, так что смысла
  // жёстко резать по версии нет - проверим на реальном использовании
  // конструкций, а не на номере версии).

  if (!parseConstantPool(c, out, errOut)) return false;

  out.accessFlags  = c.u16();
  out.thisClassIdx = c.u16();
  out.superClassIdx = c.u16();

  uint16_t ifaceCount = c.u16();
  out.interfaces.resize(ifaceCount);
  for (uint16_t i = 0; i < ifaceCount; i++) out.interfaces[i] = c.u16();

  if (!parseMethodsOrFields(c, out, /*isMethods=*/false, errOut)) return false;
  if (!parseMethodsOrFields(c, out, /*isMethods=*/true, errOut)) return false;

  // Атрибуты уровня класса (SourceFile, InnerClasses...) - не нужны.
  uint16_t classAttrCount = c.u16();
  for (uint16_t i = 0; i < classAttrCount; i++) if (!skipAttribute(c)) { errOut = "bad class attribute"; return false; }

  if (!c.ok) { errOut = path + ": truncated class file"; return false; }
  if (out.methods.empty()) { errOut = path + ": no methods (empty class?)"; return false; }
  return true;
}
