#pragma once
#include <Arduino.h>
#include "../core/buttons.h"

// ================================================================
//  jvm_display_bridge.h — объявления функций/переменных, которые
//  на самом деле определены в Parus_OS.ino (тот же паттерн, что уже
//  используют clock.cpp, turbine_integration.h и остальные модули
//  проекта - см. README "Архитектура": .ino остаётся владельцем
//  экрана и кнопок, модули из src/ вызывают его функции через extern).
// ================================================================

#define DISPLAY_WIDTH   160
#define DISPLAY_HEIGHT  128
#define CHAR_W          6   // должно совпадать с CHAR_W из .ino (см. bootLog/шрифт)

extern void sendFillScreen(uint8_t r, uint8_t g, uint8_t b);
extern void sendSetCursor(uint16_t x, uint16_t y);
extern void sendSetTextColor(uint8_t r, uint8_t g, uint8_t b);
extern void sendPrintText(const char *t);
extern void sendPrintStr(const String &s);
extern void sendFillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);
extern void sendDrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);
extern void sendDrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t r, uint8_t g, uint8_t b);

extern Btn bUp, bDown, bLeft, bRight, bOk, bHome, bCancel;
