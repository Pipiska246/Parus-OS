#include "jar.h"
#include "puff.h"
#include "../vfs/vfs.h"

// ================================================================
//  jar.cpp — разбор ZIP (см. APPNOTE.TXT / PKZIP) + распаковка.
// ================================================================

namespace {

// little-endian чтение из буфера с проверкой границ.
inline uint16_t rd16(const std::vector<uint8_t> &b, size_t off) {
  if (off + 2 > b.size()) return 0;
  return (uint16_t)(b[off] | (b[off + 1] << 8));
}
inline uint32_t rd32(const std::vector<uint8_t> &b, size_t off) {
  if (off + 4 > b.size()) return 0;
  return (uint32_t)b[off] | ((uint32_t)b[off + 1] << 8) |
         ((uint32_t)b[off + 2] << 16) | ((uint32_t)b[off + 3] << 24);
}

const uint32_t SIG_EOCD    = 0x06054b50; // End Of Central Directory
const uint32_t SIG_CENDIR  = 0x02014b50; // Central directory file header
const uint32_t SIG_LOCAL   = 0x04034b50; // Local file header

bool readWholeFile(const String &path, std::vector<uint8_t> &out, String &errOut) {
  VfsFile f;
  if (!f.openRead(path)) { errOut = "cannot open " + path; return false; }
  uint32_t sz = f.size();
  out.resize(sz);
  size_t got = sz ? f.read(out.data(), sz) : 0;
  f.close();
  if (got != sz) { errOut = "short read on " + path; return false; }
  return true;
}

} // namespace

uint32_t jarCrc32(const uint8_t *data, size_t len) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i = 0; i < len; i++) {
    crc ^= data[i];
    for (int k = 0; k < 8; k++) {
      uint32_t mask = -(int32_t)(crc & 1u);
      crc = (crc >> 1) ^ (0xEDB88320u & mask);
    }
  }
  return ~crc;
}

bool JarArchive::open(const String &vfsPath, String &err) {
  _ok = false;
  _entries.clear();
  _buf.clear();

  if (!readWholeFile(vfsPath, _buf, err)) return false;
  if (_buf.size() < 22) { err = vfsPath + ": too small to be a zip/jar"; return false; }

  // Поиск EOCD с конца (у ZIP-комментария макс. 65535 байт, но у
  // джарников его почти никогда нет - ищем в разумном хвосте).
  size_t n = _buf.size();
  size_t eocd = 0;
  bool found = false;
  size_t minPos = (n > 22 + 0xFFFF) ? (n - 22 - 0xFFFF) : 0;
  for (size_t i = n - 22; ; i--) {
    if (rd32(_buf, i) == SIG_EOCD) { eocd = i; found = true; break; }
    if (i == minPos) break;
  }
  if (!found) { err = vfsPath + ": end-of-central-directory not found (not a jar?)"; return false; }

  uint16_t totalEntries = rd16(_buf, eocd + 10);
  uint32_t cdSize       = rd32(_buf, eocd + 12);
  uint32_t cdOffset     = rd32(_buf, eocd + 16);
  (void)cdSize;

  size_t p = cdOffset;
  for (uint16_t i = 0; i < totalEntries; i++) {
    if (p + 46 > n || rd32(_buf, p) != SIG_CENDIR) {
      err = vfsPath + ": corrupt central directory";
      return false;
    }
    JarEntry e;
    e.method            = rd16(_buf, p + 10);
    e.crc32             = rd32(_buf, p + 16);
    e.compSize          = rd32(_buf, p + 20);
    e.uncompSize        = rd32(_buf, p + 24);
    uint16_t fnLen      = rd16(_buf, p + 28);
    uint16_t extraLen   = rd16(_buf, p + 30);
    uint16_t commentLen = rd16(_buf, p + 32);
    e.localHeaderOffset = rd32(_buf, p + 42);

    String name;
    name.reserve(fnLen);
    for (uint16_t k = 0; k < fnLen; k++) name += (char)_buf[p + 46 + k];
    e.name = name;

    _entries.push_back(e);
    p += 46 + fnLen + extraLen + commentLen;
  }

  _ok = true;
  return true;
}

const JarEntry *JarArchive::find(const String &name) const {
  for (const auto &e : _entries) if (e.name == name) return &e;
  return nullptr;
}

bool JarArchive::read(const JarEntry &e, std::vector<uint8_t> &out, String &err) const {
  out.clear();
  size_t lh = e.localHeaderOffset;
  if (lh + 30 > _buf.size() || rd32(_buf, lh) != SIG_LOCAL) {
    err = e.name + ": bad local header";
    return false;
  }
  uint16_t fnLen    = rd16(_buf, lh + 26);
  uint16_t extraLen = rd16(_buf, lh + 28);
  size_t dataOff    = lh + 30 + fnLen + extraLen;
  if (dataOff + e.compSize > _buf.size()) { err = e.name + ": truncated entry data"; return false; }

  if (e.method == 0) {                  // stored
    out.assign(_buf.begin() + dataOff, _buf.begin() + dataOff + e.compSize);
  } else if (e.method == 8) {           // deflate
    out.resize(e.uncompSize);
    unsigned long destLen = e.uncompSize;
    unsigned long srcLen  = e.compSize;
    int rc = puff(e.uncompSize ? out.data() : nullptr, &destLen,
                  _buf.data() + dataOff, &srcLen);
    if (rc != 0) { err = e.name + ": inflate failed (puff rc=" + String(rc) + ")"; return false; }
    if (destLen != e.uncompSize) { err = e.name + ": inflate size mismatch"; return false; }
  } else {
    err = e.name + ": unsupported compression method " + String((int)e.method);
    return false;
  }

  if (!out.empty() && jarCrc32(out.data(), out.size()) != e.crc32) {
    err = e.name + ": CRC-32 mismatch after inflate";
    return false;
  }
  return true;
}

bool JarArchive::readByName(const String &name, std::vector<uint8_t> &out, String &err) const {
  const JarEntry *e = find(name);
  if (!e) { err = "entry not found: " + name; return false; }
  return read(*e, out, err);
}
