#pragma once
#include <Arduino.h>
#include <stdint.h>
#include "jvm_config.h"
#include "jvm_types.h"

// ================================================================
//  jvm_object.h — модель объектов рантайма.
//
//  Дизайн намеренно упрощён относительно "настоящей" JVM ради
//  умещаемости в RAM RP2040 и простоты (см. docs/HISTORY.md,
//  раздел JavaME):
//
//   - Операндный стек и локальные переменные - нетипизированные
//     32-битных слова (int32_t). Корректность типов гарантирует
//     javac при компиляции .class (та же логика, что и у NanoVM/
//     первых embedded JVM - полноценного verifier тут нет).
//   - float хранится как raw-биты в том же int32_t слоте.
//   - long/double не поддерживаются (см. jvm_classfile.cpp).
//   - Куча - фиксированный пул слов (JVM_HEAP_CELLS) с bump-
//     аллокатором. GC нет: программа перезапускается "с нуля"
//     каждый `run java <file>` (см. jvmRunMidlet в jvm.cpp) -
//     ограничение, приемлемое для MIDlet-масштаба приложений.
// ================================================================

typedef int32_t JWord;      // элемент операндного стека / локальная переменная
typedef int32_t JRef;       // хендл объекта (индекс+1 в g_objects; 0 = null)

enum ObjKind : uint8_t {
  OBJ_FREE = 0,
  OBJ_INSTANCE,   // обычный объект пользовательского/загруженного класса
  OBJ_ARRAY,      // однородный массив (int/ref/float/byte - все как JWord)
  OBJ_STRING,     // java/lang/String - иммутабельная, хранит Arduino String
  OBJ_NATIVE,     // "непрозрачный" нативный объект (StringBuffer, Graphics, Canvas...)
};

// Нативные под-типы для OBJ_NATIVE (jvm_natives.cpp трактует slotStart
// как индекс в своей собственной таблице соответствующего типа).
enum NativeKind : uint8_t {
  NATIVE_STRINGBUFFER = 1,
  NATIVE_GRAPHICS     = 2,
  NATIVE_CANVAS       = 3,   // помечает, что this - подкласс Canvas/MIDlet с UI
  NATIVE_DISPLAY      = 4,
};

struct ObjHeader {
  ObjKind  kind = OBJ_FREE;
  uint8_t  nativeKind = 0;     // валиден при kind==OBJ_NATIVE
  int16_t  classId = -1;       // индекс в g_classes[] (jvm_interp.*); -1 если не применимо
  int32_t  length = 0;         // кол-во элементов (массив) / кол-во полей (instance)
  int32_t  slotStart = 0;      // начало данных в g_heapWords, либо индекс во внешней таблице
};

// --- Глобальное состояние кучи (определено в jvm_interp.cpp) ---
extern ObjHeader g_objects[];
extern const int  kJvmMaxObjects;
extern JWord      g_heapWords[JVM_HEAP_CELLS];
extern int        g_heapTop;

// Утилиты доступа (инлайн, чтобы не плодить call-overhead в горячем цикле)
inline ObjHeader *jvmObj(JRef ref) {
  if (ref <= 0) return nullptr;
  return &g_objects[ref - 1];
}
inline JWord *jvmFields(JRef ref) {
  ObjHeader *o = jvmObj(ref);
  return o ? &g_heapWords[o->slotStart] : nullptr;
}

// Аллокация: возвращает 0 (null-хендл), если куча/таблица объектов
// исчерпаны - вызывающий код должен показать пользователю понятную
// ошибку ("java: out of memory"), а не падать в UB.
JRef jvmAllocInstance(int classId, int fieldCount);
JRef jvmAllocArray(int length);
JRef jvmAllocString(const String &s);
JRef jvmAllocNative(uint8_t nativeKind, int32_t externalIndex);

// float <-> raw-bits в JWord (без long/double - см. выше)
inline JWord jvmFloatToWord(float f) { union { float f; JWord w; } u; u.f = f; return u.w; }
inline float jvmWordToFloat(JWord w) { union { float f; JWord w; } u; u.w = w; return u.f; }
