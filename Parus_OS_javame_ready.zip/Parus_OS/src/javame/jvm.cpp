#include "jvm.h"
#include "jvm_interp.h"
#include "jvm_classfile.h"
#include "jvm_natives.h"

static int  g_midletClassId = -1;
static JRef g_midletRef = 0;

void jvmEngineInit() {
  jvmResetRuntime();
}

static String dirOf(const String &path) {
  int slash = path.lastIndexOf('/');
  return slash > 0 ? path.substring(0, slash) : "";
}
static String classNameFromClassFilePath(const String &path) {
  int slash = path.lastIndexOf('/');
  String base = slash >= 0 ? path.substring(slash + 1) : path;
  if (base.endsWith(".class")) base = base.substring(0, base.length() - 6);
  return base; // допущение: плоский classpath, без пакетов в имени файла (см. README)
}

bool jvmRunMidlet(const String &classFilePath, String &err) {
  String dir = dirOf(classFilePath);
  String className = classNameFromClassFilePath(classFilePath);
  return jvmRunMidletClass(dir, className, err);
}

bool jvmRunMidletClass(const String &searchDir, const String &className, String &err) {
  jvmResetRuntime();
  g_midletClassId = -1;
  g_midletRef = 0;

  String dir = searchDir;

  int cid = jvmResolveClass(dir, className, err);
  if (cid < 0) return false;

  bool isMidlet = (g_classes[cid].rootNativeBase == "javax/microedition/midlet/MIDlet");

  if (isMidlet) {
    JRef inst = jvmAllocInstance(cid, g_classes[cid].totalFieldCount);
    if (inst == 0) { err = "out of memory allocating " + className; return false; }
    JWord res; bool hasRes;
    // Конструктор без аргументов - подавляющее большинство MIDlet-ов
    // ничего не принимают в <init>(), а параметризованные тут не
    // поддерживаются (нечего было бы передать - см. README/HISTORY).
    if (!jvmInvokeByName(className, "<init>", "()V", 1, inst, nullptr, 0, res, hasRes, err)) return false;
    if (!jvmInvokeByName(className, "startApp", "()V", 2, inst, nullptr, 0, res, hasRes, err)) return false;
    g_midletClassId = cid;
    g_midletRef = inst;
    return true;
  }

  // Не MIDlet - ищем public static void main(String[])
  int ownerId; MethodInfo *m;
  if (jvmFindMethod(cid, "main", "([Ljava/lang/String;)V", ownerId, m)) {
    JWord res; bool hasRes;
    JWord args[1] = { jvmAllocArray(0) }; // пустой String[] - argv не пробрасывается
    if (!jvmInvokeByName(className, "main", "([Ljava/lang/String;)V", 0, 0, args, 1, res, hasRes, err)) return false;
    g_midletClassId = cid;
    g_midletRef = 0; // static-приложение без экземпляра - jvmTick() не будет пытаться рисовать Canvas
    return true;
  }

  err = className + ": neither a MIDlet subclass nor a public static void main(String[]) was found";
  return false;
}

void jvmTick() {
  if (g_midletClassId < 0) return;
  jvmNativesTick(g_midletClassId, g_midletRef);
}

bool jvmWantsExit() { return jvmNativeWantsExit(); }
bool jvmHasActiveCanvas() { return jvmNativesHasActiveCanvas(); }

String jvmStatusLine() {
  if (g_midletClassId < 0) return "idle - no MIDlet running";
  return "running: " + g_classes[g_midletClassId].name +
         " | classes=" + String(g_classCount) + "/" + String((int)JVM_MAX_CLASSES) +
         " | heap=" + String(g_heapTop) + "/" + String((int)JVM_HEAP_CELLS) + " words" +
         " | canvas=" + String(jvmNativesHasActiveCanvas() ? "yes" : "no");
}
