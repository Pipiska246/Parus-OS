#include "jvm_interp.h"
#include "jvm_classfile.h"
#include "jvm_natives.h"
#include "../vfs/vfs.h"

// ================================================================
//  jvm_interp.cpp (часть 1/2) — линковка классов: поиск .class на
//  VFS, разбор через jvm_classfile.*, вычисление layout полей
//  (instance/static) с учётом наследования.
//
//  Сам байткод-интерпретатор - в jvm_interp_exec.cpp (часть 2/2),
//  чтобы каждый файл оставался в разумных пределах для ревью.
// ================================================================

JvmClass g_classes[JVM_MAX_CLASSES];
int      g_classCount = 0;

ObjHeader g_objects[JVM_MAX_OBJECTS];
const int kJvmMaxObjects = JVM_MAX_OBJECTS;
JWord     g_heapWords[JVM_HEAP_CELLS];
int       g_heapTop = 0;

// --- строковый пул (java/lang/String) - отдельно от g_heapWords ---
static String g_strings[JVM_MAX_STRINGS];
static int    g_stringCount = 0;

int jvmInternString(const String &s) {
  // Небольшая дедупликация - строковые константы (ldc) одного класса
  // часто повторяются (println несколько раз с теми же литералами).
  for (int i = 0; i < g_stringCount; i++) if (g_strings[i] == s) return i;
  if (g_stringCount >= JVM_MAX_STRINGS) return -1;
  g_strings[g_stringCount] = s;
  return g_stringCount++;
}
const String &jvmStringAt(int idx) {
  static const String kEmpty = "";
  if (idx < 0 || idx >= g_stringCount) return kEmpty;
  return g_strings[idx];
}

void jvmResetRuntime() {
  for (int i = 0; i < g_classCount; i++) g_classes[i] = JvmClass();
  g_classCount = 0;
  g_heapTop = 0;
  for (int i = 0; i < JVM_MAX_OBJECTS; i++) g_objects[i] = ObjHeader();
  g_stringCount = 0;
  jvmNativesReset();
}

JRef jvmAllocInstance(int classId, int fieldCount) {
  for (int i = 0; i < JVM_MAX_OBJECTS; i++) {
    if (g_objects[i].kind == OBJ_FREE) {
      if (g_heapTop + fieldCount > JVM_HEAP_CELLS) return 0;
      g_objects[i].kind = OBJ_INSTANCE;
      g_objects[i].classId = (int16_t)classId;
      g_objects[i].length = fieldCount;
      g_objects[i].slotStart = g_heapTop;
      for (int k = 0; k < fieldCount; k++) g_heapWords[g_heapTop + k] = 0;
      g_heapTop += fieldCount;
      return i + 1;
    }
  }
  return 0;
}

JRef jvmAllocArray(int length) {
  if (length < 0) length = 0;
  for (int i = 0; i < JVM_MAX_OBJECTS; i++) {
    if (g_objects[i].kind == OBJ_FREE) {
      if (g_heapTop + length > JVM_HEAP_CELLS) return 0;
      g_objects[i].kind = OBJ_ARRAY;
      g_objects[i].classId = -1;
      g_objects[i].length = length;
      g_objects[i].slotStart = g_heapTop;
      for (int k = 0; k < length; k++) g_heapWords[g_heapTop + k] = 0;
      g_heapTop += length;
      return i + 1;
    }
  }
  return 0;
}

JRef jvmAllocString(const String &s) {
  int idx = jvmInternString(s);
  if (idx < 0) return 0;
  for (int i = 0; i < JVM_MAX_OBJECTS; i++) {
    if (g_objects[i].kind == OBJ_FREE) {
      g_objects[i].kind = OBJ_STRING;
      g_objects[i].classId = -1;
      g_objects[i].length = s.length();
      g_objects[i].slotStart = idx;
      return i + 1;
    }
  }
  return 0;
}

JRef jvmAllocNative(uint8_t nativeKind, int32_t externalIndex) {
  for (int i = 0; i < JVM_MAX_OBJECTS; i++) {
    if (g_objects[i].kind == OBJ_FREE) {
      g_objects[i].kind = OBJ_NATIVE;
      g_objects[i].nativeKind = nativeKind;
      g_objects[i].classId = -1;
      g_objects[i].slotStart = externalIndex;
      return i + 1;
    }
  }
  return 0;
}

// --- дескрипторы методов: "(IFLjava/lang/String;[B)I" ------------

bool jvmParseMethodDescriptor(const String &desc, int &argWordCount, bool &hasReturn, String &err) {
  argWordCount = 0;
  int i = 0, n = desc.length();
  if (n == 0 || desc[0] != '(') { err = "bad descriptor " + desc; return false; }
  i = 1;
  while (i < n && desc[i] != ')') {
    char c = desc[i];
    if (c == 'J' || c == 'D') { err = "long/double parameters are not supported: " + desc; return false; }
    if (c == 'L') { while (i < n && desc[i] != ';') i++; i++; argWordCount++; continue; }
    if (c == '[') { i++; while (i < n && desc[i] == '[') i++; if (i < n && desc[i] == 'L') { while (i < n && desc[i] != ';') i++; } i++; argWordCount++; continue; }
    // I F Z B C S - все занимают одно слово
    i++; argWordCount++;
  }
  if (i >= n) { err = "unterminated descriptor " + desc; return false; }
  i++; // ')'
  if (i >= n) { err = "descriptor missing return type " + desc; return false; }
  char r = desc[i];
  if (r == 'V') hasReturn = false;
  else if (r == 'J' || r == 'D') { err = "long/double return is not supported: " + desc; return false; }
  else hasReturn = true;
  return true;
}

// --- поиск .class-файла соседа по имени класса ---------------------

static bool findClassFile(const String &searchDir, const String &className, String &pathOut) {
  // className может быть "com/example/Hello". Установленные из .jar
  // приложения хранят классы с полной структурой пакетов
  // (java_apps.cpp), поэтому сначала пробуем полный путь
  // "<dir>/com/example/Hello.class", а затем откатываемся на плоское
  // размещение "<dir>/Hello.class" (совместимость с "закинул один
  // .class в /sda/java" - см. jvm_config.h::JVM_APPS_DIR и README).
  int slash = className.lastIndexOf('/');
  String shortName = (slash >= 0) ? className.substring(slash + 1) : className;

  const String bases[2] = { searchDir, String(JVM_APPS_DIR) };
  for (int b = 0; b < 2; b++) {
    if (bases[b].length() == 0) continue;
    String full = bases[b] + "/" + className + ".class";
    if (vfsExists(full)) { pathOut = full; return true; }
    String flat = bases[b] + "/" + shortName + ".class";
    if (vfsExists(flat)) { pathOut = flat; return true; }
  }
  return false;
}

static int findLoadedClass(const String &name) {
  for (int i = 0; i < g_classCount; i++) if (g_classes[i].used && g_classes[i].name == name) return i;
  return -1;
}

int jvmResolveClass(const String &searchDir, const String &className, String &err) {
  int existing = findLoadedClass(className);
  if (existing >= 0) return existing;

  if (jvmIsNativeClassName(className)) {
    err = className + " is a native class and has no .class file to load";
    return -1;
  }

  if (g_classCount >= JVM_MAX_CLASSES) { err = "too many loaded classes (JVM_MAX_CLASSES=" + String(JVM_MAX_CLASSES) + ")"; return -1; }

  String path;
  if (!findClassFile(searchDir, className, path)) {
    err = "class not found: " + className + " (looked in " + searchDir + " and " JVM_APPS_DIR ")";
    return -1;
  }

  int id = g_classCount++;
  JvmClass &jc = g_classes[id];
  jc.used = true;
  jc.searchDir = searchDir;

  if (!jvmParseClassFile(path, jc.raw, err)) { jc.used = false; g_classCount--; return -1; }
  jc.name = jc.raw.thisClassName();

  String superName = jc.raw.superClassName();
  if (superName == "" || jvmIsNativeClassName(superName)) {
    jc.superId = -1;
    jc.rootNativeBase = (superName == "") ? "java/lang/Object" : superName;
  } else {
    int superId = jvmResolveClass(searchDir, superName, err);
    if (superId < 0) { jc.used = false; g_classCount--; return -1; }
    jc.superId = superId;
    jc.rootNativeBase = g_classes[superId].rootNativeBase;
  }

  int baseFieldCount = (jc.superId >= 0) ? g_classes[jc.superId].totalFieldCount : 0;
  int ownInstanceFields = 0, ownStaticFields = 0;
  for (auto &f : jc.raw.fields) {
    if (f.isStatic()) f.slot = ownStaticFields++;
    else f.slot = baseFieldCount + (ownInstanceFields++);
  }
  jc.ownFieldCount = ownInstanceFields;
  jc.totalFieldCount = baseFieldCount + ownInstanceFields;
  jc.staticStorage.assign(ownStaticFields, 0);

  return id;
}

// Ищет поле (по имени) в классе classId либо у его предков; кладёт
// абсолютный слот инстанса (для static - слот в staticStorage
// конкретного класса-владельца, ownerClassId).
bool jvmFindField(int classId, const String &name, bool isStaticLookup, int &slotOut, int &ownerClassIdOut) {
  for (int cid = classId; cid >= 0; cid = g_classes[cid].superId) {
    for (auto &f : g_classes[cid].raw.fields) {
      if (f.name == name && f.isStatic() == isStaticLookup) {
        slotOut = f.slot;
        ownerClassIdOut = cid;
        return true;
      }
    }
  }
  return false;
}

// Ищет метод (по имени+дескриптору) в классе classId либо у предков,
// не заходя за границу "загруженных" классов (родные базовые классы
// обрабатываются отдельно интерпретатором - см. jvm_interp_exec.cpp).
bool jvmFindMethod(int classId, const String &name, const String &desc, int &ownerClassIdOut, MethodInfo *&methodOut) {
  for (int cid = classId; cid >= 0; cid = g_classes[cid].superId) {
    for (auto &m : g_classes[cid].raw.methods) {
      if (m.name == name && m.descriptor == desc) {
        ownerClassIdOut = cid;
        methodOut = &m;
        return true;
      }
    }
  }
  return false;
}
