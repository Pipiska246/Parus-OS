#include "jvm_interp.h"
#include "jvm_natives.h"

// ================================================================
//  jvm_interp_exec.cpp (часть 2/2) — собственно интерпретатор.
//
//  Операндный стек и локальные переменные - массивы JWord на стеке
//  вызова C++ (每 кадр интерпретатора = один кадр C++-функции
//  jvmExecMethod, вызываемой рекурсивно на invoke* - глубина
//  ограничена JVM_MAX_CALL_DEPTH через явный счётчик, а не только
//  надеждой на стек RP2040).
//
//  Набор опкодов - осознанное подмножество JVM Spec §6.5: всё, что
//  реально генерирует javac для простых int/float/ref-программ и
//  MIDlet-ов. Чего тут нет - см. default: в switch и HISTORY.md.
// ================================================================

static int g_callDepth = 0;

struct Frame {
  JWord locals[JVM_MAX_LOCALS];
  JWord stack[JVM_MAX_OPSTACK];
  int   sp = 0; // указывает на первый свободный слот стека

  void push(JWord w) { if (sp < JVM_MAX_OPSTACK) stack[sp++] = w; }
  JWord pop() { return sp > 0 ? stack[--sp] : 0; }
};

// Резолвит Methodref/InterfaceMethodref из пула констант в
// (имяКласса, имяМетода, дескриптор).
static bool resolveMethodref(const RawClassFile &cf, uint16_t cpIdx,
                             String &clsName, String &mName, String &mDesc) {
  if (cpIdx == 0 || cpIdx >= cf.cp.size()) return false;
  const CpEntry &mr = cf.cp[cpIdx];
  if (mr.tag != CP_METHODREF && mr.tag != CP_INTERFACE_METHODREF) return false;
  if (mr.classIndex >= cf.cp.size() || mr.nameAndTypeIndex >= cf.cp.size()) return false;
  const CpEntry &cls = cf.cp[mr.classIndex];
  const CpEntry &nt  = cf.cp[mr.nameAndTypeIndex];
  clsName = cf.utf8At(cls.nameIndex);
  mName   = cf.utf8At(nt.nameIndex);
  mDesc   = cf.utf8At(nt.descriptorIndex);
  return true;
}

static bool resolveFieldref(const RawClassFile &cf, uint16_t cpIdx,
                            String &clsName, String &fName, String &fDesc) {
  if (cpIdx == 0 || cpIdx >= cf.cp.size()) return false;
  const CpEntry &fr = cf.cp[cpIdx];
  if (fr.tag != CP_FIELDREF) return false;
  const CpEntry &cls = cf.cp[fr.classIndex];
  const CpEntry &nt  = cf.cp[fr.nameAndTypeIndex];
  clsName = cf.utf8At(cls.nameIndex);
  fName   = cf.utf8At(nt.nameIndex);
  fDesc   = cf.utf8At(nt.descriptorIndex);
  return true;
}

bool jvmInvokeByName(const String &className, const String &methodName,
                     const String &descriptor, int invokeKind,
                     JRef thisRef, JWord *args, int argCount,
                     JWord &outResult, bool &hasResult, String &err) {
  if (jvmIsNativeClassName(className)) {
    return jvmNativeInvoke(className, methodName, descriptor, thisRef, args, argCount, outResult, hasResult, err);
  }

  int startClassId;
  if (invokeKind == 2 /* virtual */ && thisRef != 0) {
    ObjHeader *o = jvmObj(thisRef);
    if (!o) { err = "invokevirtual on null"; return false; }
    if (o->kind != OBJ_INSTANCE) {
      // this - строка/нативный объект (Graphics и т.п.): передаём
      // дальше как есть, jvm_natives сам разберётся по nativeKind.
      return jvmNativeInvoke(className, methodName, descriptor, thisRef, args, argCount, outResult, hasResult, err);
    }
    startClassId = o->classId;
  } else {
    // static/special вызов на классе, ещё не обязательно загруженном -
    // searchDir="" тут ок, jvmResolveClass откатывается на JVM_APPS_DIR
    // и в любом случае сначала проверяет, не загружен ли класс уже.
    startClassId = jvmResolveClass("", className, err);
  }
  if (startClassId < 0) return false;

  int ownerId; MethodInfo *m;
  if (jvmFindMethod(startClassId, methodName, descriptor, ownerId, m)) {
    if (m->isNativeOrAbstract()) { err = methodName + ": native/abstract method with no native handler"; return false; }
    JWord res = 0;
    bool ok = jvmExecMethod(ownerId, m, thisRef, args, argCount, res, err);
    if (!ok) return false;
    int argWords; bool hasRet; String derr;
    jvmParseMethodDescriptor(descriptor, argWords, hasRet, derr);
    hasResult = hasRet;
    outResult = res;
    return true;
  }
  // Не нашли байткодом - пробуем родного предка (Canvas/MIDlet/Object)
  String base = (startClassId >= 0) ? g_classes[startClassId].rootNativeBase : className;
  return jvmNativeInvoke(base, methodName, descriptor, thisRef, args, argCount, outResult, hasResult, err);
}

bool jvmExecMethod(int classId, MethodInfo *m, JRef thisRef,
                   JWord *args, int argCount, JWord &outResult, String &err) {
  if (g_callDepth >= JVM_MAX_CALL_DEPTH) { err = "stack overflow (JVM_MAX_CALL_DEPTH)"; return false; }
  if (m->maxLocals > JVM_MAX_LOCALS || m->maxStack > JVM_MAX_OPSTACK) {
    err = m->name + ": frame too large for this VM (maxLocals=" + String(m->maxLocals) +
          ", maxStack=" + String(m->maxStack) + ")";
    return false;
  }
  g_callDepth++;
  Frame fr;
  int li = 0;
  if (thisRef != 0 || !m->isStatic()) fr.locals[li++] = thisRef;
  for (int i = 0; i < argCount; i++) fr.locals[li++] = args[i];

  const RawClassFile &cf = g_classes[classId].raw;
  const uint8_t *code = m->code.data();
  int len = (int)m->code.size();
  int pc = 0;
  bool returned = false;
  JWord retVal = 0;
  bool ok = true;

  auto u8  = [&](int off){ return code[off]; };
  auto s8  = [&](int off){ return (int8_t)code[off]; };
  auto u16 = [&](int off){ return (uint16_t)((code[off] << 8) | code[off+1]); };
  auto s16 = [&](int off){ return (int16_t)u16(off); };
  auto s32 = [&](int off){ return (int32_t)((code[off]<<24)|(code[off+1]<<16)|(code[off+2]<<8)|code[off+3]); };

  while (pc < len && ok && !returned) {
    uint8_t op = code[pc];
    int next = pc + 1;
    switch (op) {
      case 0x00: break; // nop
      case 0x01: fr.push(0); break; // aconst_null
      case 0x02: fr.push(-1); break; // iconst_m1
      case 0x03: case 0x04: case 0x05: case 0x06: case 0x07: case 0x08: // iconst_0..5
        fr.push(op - 0x03); break;
      case 0x0B: fr.push(jvmFloatToWord(0.0f)); break; // fconst_0
      case 0x0C: fr.push(jvmFloatToWord(1.0f)); break; // fconst_1
      case 0x0D: fr.push(jvmFloatToWord(2.0f)); break; // fconst_2
      case 0x10: fr.push(s8(next)); next += 1; break; // bipush
      case 0x11: fr.push(s16(next)); next += 2; break; // sipush
      case 0x12: { // ldc
        uint8_t idx = u8(next); next += 1;
        const CpEntry &e = cf.cp[idx];
        if (e.tag == CP_INTEGER || e.tag == CP_FLOAT) fr.push(e.intOrFloatBits);
        else if (e.tag == CP_STRING) fr.push(jvmAllocString(cf.utf8At(e.nameIndex)));
        else { err = "ldc: unsupported constant tag"; ok = false; }
        break;
      }
      case 0x13: { // ldc_w
        uint16_t idx = u16(next); next += 2;
        const CpEntry &e = cf.cp[idx];
        if (e.tag == CP_INTEGER || e.tag == CP_FLOAT) fr.push(e.intOrFloatBits);
        else if (e.tag == CP_STRING) fr.push(jvmAllocString(cf.utf8At(e.nameIndex)));
        else { err = "ldc_w: unsupported constant tag"; ok = false; }
        break;
      }
      case 0x15: case 0x17: case 0x19: // iload / fload / aload
        fr.push(fr.locals[u8(next)]); next += 1; break;
      case 0x1A: case 0x1B: case 0x1C: case 0x1D: // iload_0..3
        fr.push(fr.locals[op - 0x1A]); break;
      case 0x22: case 0x23: case 0x24: case 0x25: // fload_0..3
        fr.push(fr.locals[op - 0x22]); break;
      case 0x2A: case 0x2B: case 0x2C: case 0x2D: // aload_0..3
        fr.push(fr.locals[op - 0x2A]); break;
      case 0x2E: { // iaload
        JWord idx = fr.pop(); JRef arr = fr.pop();
        JWord *fs = jvmFields(arr);
        if (!fs || idx < 0 || idx >= jvmObj(arr)->length) { err = "array index out of bounds"; ok = false; break; }
        fr.push(fs[idx]);
        break;
      }
      case 0x30: case 0x33: case 0x34: case 0x35: { // faload/baload/caload/saload - все как iaload здесь
        JWord idx = fr.pop(); JRef arr = fr.pop();
        JWord *fs = jvmFields(arr);
        if (!fs || idx < 0 || idx >= jvmObj(arr)->length) { err = "array index out of bounds"; ok = false; break; }
        fr.push(fs[idx]);
        break;
      }
      case 0x32: { // aaload
        JWord idx = fr.pop(); JRef arr = fr.pop();
        JWord *fs = jvmFields(arr);
        if (!fs || idx < 0 || idx >= jvmObj(arr)->length) { err = "array index out of bounds"; ok = false; break; }
        fr.push(fs[idx]);
        break;
      }
      case 0x36: case 0x38: case 0x3A: // istore/fstore/astore
        fr.locals[u8(next)] = fr.pop(); next += 1; break;
      case 0x3B: case 0x3C: case 0x3D: case 0x3E: // istore_0..3
        fr.locals[op - 0x3B] = fr.pop(); break;
      case 0x43: case 0x44: case 0x45: case 0x46: // fstore_0..3
        fr.locals[op - 0x43] = fr.pop(); break;
      case 0x4B: case 0x4C: case 0x4D: case 0x4E: // astore_0..3
        fr.locals[op - 0x4B] = fr.pop(); break;
      case 0x4F: case 0x51: case 0x52: case 0x53: { // iastore/fastore/aastore/bastore(-ish) - унифицировано
        JWord val = fr.pop(); JWord idx = fr.pop(); JRef arr = fr.pop();
        JWord *fs = jvmFields(arr);
        if (!fs || idx < 0 || idx >= jvmObj(arr)->length) { err = "array index out of bounds"; ok = false; break; }
        fs[idx] = val;
        break;
      }
      case 0x57: fr.pop(); break; // pop
      case 0x58: fr.pop(); fr.pop(); break; // pop2 (используем для пар int/float - long/double не поддерживаются)
      case 0x59: { JWord v = fr.pop(); fr.push(v); fr.push(v); break; } // dup
      case 0x5A: { // dup_x1
        JWord v1 = fr.pop(), v2 = fr.pop();
        fr.push(v1); fr.push(v2); fr.push(v1);
        break;
      }
      case 0x5F: { JWord v1 = fr.pop(), v2 = fr.pop(); fr.push(v1); fr.push(v2); break; } // swap
      case 0x60: { JWord b = fr.pop(), a = fr.pop(); fr.push(a + b); break; } // iadd
      case 0x62: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmFloatToWord(jvmWordToFloat(a) + jvmWordToFloat(b))); break; } // fadd
      case 0x64: { JWord b = fr.pop(), a = fr.pop(); fr.push(a - b); break; } // isub
      case 0x66: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmFloatToWord(jvmWordToFloat(a) - jvmWordToFloat(b))); break; } // fsub
      case 0x68: { JWord b = fr.pop(), a = fr.pop(); fr.push(a * b); break; } // imul
      case 0x6A: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmFloatToWord(jvmWordToFloat(a) * jvmWordToFloat(b))); break; } // fmul
      case 0x6C: { JWord b = fr.pop(), a = fr.pop(); if (b == 0) { err = "/ by zero"; ok = false; break; } fr.push(a / b); break; } // idiv
      case 0x6E: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmFloatToWord(jvmWordToFloat(a) / jvmWordToFloat(b))); break; } // fdiv
      case 0x70: { JWord b = fr.pop(), a = fr.pop(); if (b == 0) { err = "% by zero"; ok = false; break; } fr.push(a % b); break; } // irem
      case 0x74: fr.push(-fr.pop()); break; // ineg
      case 0x76: fr.push(jvmFloatToWord(-jvmWordToFloat(fr.pop()))); break; // fneg
      case 0x78: { JWord b = fr.pop(), a = fr.pop(); fr.push(a << (b & 31)); break; } // ishl
      case 0x7A: { JWord b = fr.pop(), a = fr.pop(); fr.push(a >> (b & 31)); break; } // ishr
      case 0x7C: { JWord b = fr.pop(), a = fr.pop(); fr.push((int32_t)((uint32_t)a >> (b & 31))); break; } // iushr
      case 0x7E: { JWord b = fr.pop(), a = fr.pop(); fr.push(a & b); break; } // iand
      case 0x80: { JWord b = fr.pop(), a = fr.pop(); fr.push(a | b); break; } // ior
      case 0x82: { JWord b = fr.pop(), a = fr.pop(); fr.push(a ^ b); break; } // ixor
      case 0x84: { uint8_t idx = u8(next); int8_t d = s8(next+1); fr.locals[idx] += d; next += 2; break; } // iinc
      case 0x85: fr.push(jvmFloatToWord((float)fr.pop())); break; // i2f
      case 0x8B: fr.push((int32_t)jvmWordToFloat(fr.pop())); break; // f2i
      case 0x91: fr.push((int8_t)fr.pop()); break; // i2b
      case 0x92: fr.push((int16_t)(uint16_t)fr.pop()); break; // i2c
      case 0x93: fr.push((int16_t)fr.pop()); break; // i2s
      case 0x95: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmWordToFloat(a) < jvmWordToFloat(b) ? -1 : (jvmWordToFloat(a) > jvmWordToFloat(b) ? 1 : 0)); break; } // fcmpl (упрощённо, без NaN-семантики)
      case 0x96: { JWord b = fr.pop(), a = fr.pop(); fr.push(jvmWordToFloat(a) < jvmWordToFloat(b) ? -1 : (jvmWordToFloat(a) > jvmWordToFloat(b) ? 1 : 0)); break; } // fcmpg
      case 0x99: { JWord v = fr.pop(); if (v == 0) next = pc + s16(next); else next += 2; break; } // ifeq
      case 0x9A: { JWord v = fr.pop(); if (v != 0) next = pc + s16(next); else next += 2; break; } // ifne
      case 0x9B: { JWord v = fr.pop(); if (v < 0)  next = pc + s16(next); else next += 2; break; } // iflt
      case 0x9C: { JWord v = fr.pop(); if (v >= 0) next = pc + s16(next); else next += 2; break; } // ifge
      case 0x9D: { JWord v = fr.pop(); if (v > 0)  next = pc + s16(next); else next += 2; break; } // ifgt
      case 0x9E: { JWord v = fr.pop(); if (v <= 0) next = pc + s16(next); else next += 2; break; } // ifle
      case 0x9F: { JWord b = fr.pop(), a = fr.pop(); if (a == b) next = pc + s16(next); else next += 2; break; } // if_icmpeq
      case 0xA0: { JWord b = fr.pop(), a = fr.pop(); if (a != b) next = pc + s16(next); else next += 2; break; } // if_icmpne
      case 0xA1: { JWord b = fr.pop(), a = fr.pop(); if (a < b)  next = pc + s16(next); else next += 2; break; } // if_icmplt
      case 0xA2: { JWord b = fr.pop(), a = fr.pop(); if (a >= b) next = pc + s16(next); else next += 2; break; } // if_icmpge
      case 0xA3: { JWord b = fr.pop(), a = fr.pop(); if (a > b)  next = pc + s16(next); else next += 2; break; } // if_icmpgt
      case 0xA4: { JWord b = fr.pop(), a = fr.pop(); if (a <= b) next = pc + s16(next); else next += 2; break; } // if_icmple
      case 0xA5: { JWord b = fr.pop(), a = fr.pop(); if (a == b) next = pc + s16(next); else next += 2; break; } // if_acmpeq
      case 0xA6: { JWord b = fr.pop(), a = fr.pop(); if (a != b) next = pc + s16(next); else next += 2; break; } // if_acmpne
      case 0xA7: next = pc + s16(next); break; // goto
      case 0xC6: { JWord v = fr.pop(); if (v == 0) next = pc + s16(next); else next += 2; break; } // ifnull
      case 0xC7: { JWord v = fr.pop(); if (v != 0) next = pc + s16(next); else next += 2; break; } // ifnonnull
      case 0xC8: next = pc + s32(next); break; // goto_w
      case 0xAC: case 0xAE: case 0xB0: // ireturn/freturn/areturn
        retVal = fr.pop(); returned = true; break;
      case 0xB1: returned = true; break; // return (void)
      case 0xBB: { // new
        uint16_t idx = u16(next); next += 2;
        String clsName = cf.utf8At(cf.cp[idx].nameIndex); // cp[idx] это CONSTANT_Class
        int cid = jvmResolveClass(g_classes[classId].searchDir, clsName, err);
        if (cid < 0) { ok = false; break; }
        JRef r = jvmAllocInstance(cid, g_classes[cid].totalFieldCount);
        if (r == 0) { err = "out of memory (new " + clsName + ")"; ok = false; break; }
        fr.push(r);
        break;
      }
      case 0xBC: { // newarray (primitive)
        next += 1; // atype - все примитивные массивы хранятся одинаково (JWord)
        JWord count = fr.pop();
        JRef r = jvmAllocArray(count);
        if (r == 0 && count > 0) { err = "out of memory (newarray)"; ok = false; break; }
        fr.push(r);
        break;
      }
      case 0xBD: { // anewarray (ref array) - имя типа элемента нам для хранения не нужно
        next += 2;
        JWord count = fr.pop();
        JRef r = jvmAllocArray(count);
        if (r == 0 && count > 0) { err = "out of memory (anewarray)"; ok = false; break; }
        fr.push(r);
        break;
      }
      case 0xBE: { // arraylength
        JRef arr = fr.pop();
        ObjHeader *o = jvmObj(arr);
        if (!o) { err = "arraylength on null"; ok = false; break; }
        fr.push(o->length);
        break;
      }
      case 0xB4: { // getfield
        uint16_t idx = u16(next); next += 2;
        String cn, fn, fd; resolveFieldref(cf, idx, cn, fn, fd);
        JRef obj = fr.pop();
        ObjHeader *o = jvmObj(obj);
        if (!o) { err = "getfield on null (" + fn + ")"; ok = false; break; }
        int slot, owner;
        if (!jvmFindField(o->classId, fn, false, slot, owner)) { err = "no such field " + fn; ok = false; break; }
        fr.push(jvmFields(obj)[slot]);
        break;
      }
      case 0xB5: { // putfield
        uint16_t idx = u16(next); next += 2;
        String cn, fn, fd; resolveFieldref(cf, idx, cn, fn, fd);
        JWord val = fr.pop(); JRef obj = fr.pop();
        ObjHeader *o = jvmObj(obj);
        if (!o) { err = "putfield on null (" + fn + ")"; ok = false; break; }
        int slot, owner;
        if (!jvmFindField(o->classId, fn, false, slot, owner)) { err = "no such field " + fn; ok = false; break; }
        jvmFields(obj)[slot] = val;
        break;
      }
      case 0xB2: { // getstatic
        uint16_t idx = u16(next); next += 2;
        String cn, fn, fd; resolveFieldref(cf, idx, cn, fn, fd);
        JWord nativeVal;
        if (jvmIsNativeClassName(cn)) {
          if (!jvmNativeGetStaticField(cn, fn, fd, nativeVal)) { err = cn + "." + fn + ": native static field not implemented"; ok = false; break; }
          fr.push(nativeVal);
          break;
        }
        int cid = jvmResolveClass(g_classes[classId].searchDir, cn, err);
        if (cid < 0) { ok = false; break; }
        int slot, owner;
        if (!jvmFindField(cid, fn, true, slot, owner)) { err = "no such static field " + fn; ok = false; break; }
        fr.push(g_classes[owner].staticStorage[slot]);
        break;
      }
      case 0xB3: { // putstatic
        uint16_t idx = u16(next); next += 2;
        String cn, fn, fd; resolveFieldref(cf, idx, cn, fn, fd);
        int cid = jvmResolveClass(g_classes[classId].searchDir, cn, err);
        if (cid < 0) { ok = false; break; }
        JWord val = fr.pop();
        int slot, owner;
        if (!jvmFindField(cid, fn, true, slot, owner)) { err = "no such static field " + fn; ok = false; break; }
        g_classes[owner].staticStorage[slot] = val;
        break;
      }
      case 0xB6: case 0xB7: case 0xB8: case 0xB9: { // invokevirtual/special/static/interface
        uint16_t idx = u16(next); next += 2;
        if (op == 0xB9) next += 2; // invokeinterface: +count +0
        String cn, mn, md;
        if (!resolveMethodref(cf, idx, cn, mn, md)) { err = "bad methodref"; ok = false; break; }
        int argWords; bool hasRet; String derr;
        if (!jvmParseMethodDescriptor(md, argWords, hasRet, derr)) { err = derr; ok = false; break; }
        JWord callArgs[JVM_MAX_OPSTACK];
        for (int i = argWords - 1; i >= 0; i--) callArgs[i] = fr.pop();
        JRef objRef = 0;
        int invokeKind = (op == 0xB8) ? 0 : (op == 0xB7 ? 1 : 2);
        if (op != 0xB8) objRef = fr.pop(); // static не берёт this
        JWord res = 0; bool hasResult = false;
        if (!jvmInvokeByName(cn, mn, md, invokeKind, objRef, callArgs, argWords, res, hasResult, err)) { ok = false; break; }
        if (hasResult) fr.push(res);
        break;
      }
      default:
        err = m->name + ": unsupported opcode 0x" + String(op, HEX) +
              " at pc=" + String(pc) + " (see docs/HISTORY.md - JavaME - opcode coverage)";
        ok = false;
        break;
    }
    pc = next;
  }

  g_callDepth--;
  if (!ok) return false;
  outResult = retVal;
  return true;
}
