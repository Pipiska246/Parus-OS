#pragma once
#include <Arduino.h>

// ================================================================
//  jvm.h — публичный вход в движок JavaME для остального проекта.
//
//  Использование из .ino (см. интеграционный патч в HISTORY.md /
//  README, раздел "JavaME"):
//
//    case STATE_JAVA_RUNNER:
//      jvmTick();                  // paint()/keyPressed() текущего Canvas
//      if (jvmWantsExit()) currentState = STATE_MENU;
//      break;
//
//  Запуск (например, из explorer/terminal при выборе .class файла):
//
//    String err;
//    if (!jvmRunMidlet(path, err)) { showError(err); }
//    else currentState = STATE_JAVA_RUNNER;
// ================================================================

void jvmEngineInit();  // вызывается один раз из setup()

// Грузит classFilePath, определяет тип точки входа:
//  - если класс (или предок) - javax/microedition/midlet/MIDlet:
//    создаёт экземпляр (конструктор без аргументов) и зовёт startApp().
//    Дальнейшая перерисовка/ввод идут через jvmTick() каждый UI-тик.
//  - иначе ищет "public static void main(String[])" и зовёт один раз
//    (для консольных Turbine-подобных .class без UI).
// Куча/классы предыдущего запуска сбрасываются (см. jvmResetRuntime -
// GC-а нет, поэтому один слот в памяти на одно запущенное приложение).
bool jvmRunMidlet(const String &classFilePath, String &err);

// То же, но точка входа задана явно: searchDir (каталог с .class,
// обычно каталог установки JavaME-приложения) + полное имя главного
// класса ("com/foo/Bar", как в MIDlet-1 дескриптора JAD/манифеста).
// Используется лаунчером установленных .jar/.jad-приложений.
bool jvmRunMidletClass(const String &searchDir, const String &className, String &err);

void jvmTick();          // перерисовка/ввод активного Canvas, если есть
bool jvmWantsExit();      // MIDlet вызвал notifyDestroyed()/System.exit()
bool jvmHasActiveCanvas(); // true - значит именно JavaME сейчас "владеет" экраном

// Однострочный статус для /proc/jvm (см. proc_vfs.cpp): классы, куча, MIDlet.
String jvmStatusLine();
