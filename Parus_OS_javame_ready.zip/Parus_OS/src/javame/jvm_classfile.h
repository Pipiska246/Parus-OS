#pragma once
#include <Arduino.h>
#include "jvm_types.h"

// ================================================================
//  jvm_classfile.h — читает .class файл через существующую VFS
//  (VfsFile, см. ../vfs/vfs.h) и разбирает его в RawClassFile.
//
//  Никакой Arduino/RP2040-специфики тут нет - чистый разбор байт,
//  поэтому это самая тестируемая часть движка.
// ================================================================

// path - полный VFS-путь ("/sda/java/Hello.class", "/sdb1/...").
// В случае ошибки возвращает false и кладёт причину в errOut
// (например "bad magic", "unsupported cp tag 6 (long)").
bool jvmParseClassFile(const String &path, RawClassFile &out, String &errOut);
