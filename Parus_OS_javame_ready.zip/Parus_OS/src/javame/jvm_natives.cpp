#include "jvm_natives.h"
#include "jvm_interp.h"
#include "jvm_display_bridge.h"
#include <math.h>

// ================================================================
//  jvm_natives.cpp — весь "не-байткодовый" мир этой VM:
//   - java/lang/Object, System, String, StringBuffer, Math (подмножество)
//   - java/io/PrintStream (System.out) - выводит на экран как консоль
//   - javax/microedition/midlet/MIDlet (жизненный цикл)
//   - javax/microedition/lcdui/{Display,Canvas,Graphics} - урезанный
//     lcdui, связанный с существующим UART-мостом дисплея (.ino)
//
//  См. docs/HISTORY.md, раздел "JavaME - известные ограничения" за
//  списком того, чего тут нет (Form/TextBox/Image/List/...).
// ================================================================

// --- состояние Display/Canvas на всё время работы MIDlet-а ---------
static JRef   g_currentDisplayable = 0;  // экземпляр Canvas-подкласса (или 0)
static bool   g_wantsExit = false;
static JRef   g_graphicsSingleton = 0;   // единственный переиспользуемый Graphics
static JRef   g_displaySingleton  = 0;

struct GfxState { uint8_t r = 255, g = 255, b = 255; };
static GfxState g_gfxState; // одно активное перо - MIDlet рисует последовательно, не параллельно

// --- простая текстовая консоль для System.out.println (пока нет Canvas) ---
#define JVM_CONSOLE_LINES 15
static String g_console[JVM_CONSOLE_LINES];
static int    g_consoleCount = 0;

static void consolePush(const String &line) {
  if (g_consoleCount < JVM_CONSOLE_LINES) {
    g_console[g_consoleCount++] = line;
  } else {
    for (int i = 1; i < JVM_CONSOLE_LINES; i++) g_console[i - 1] = g_console[i];
    g_console[JVM_CONSOLE_LINES - 1] = line;
  }
  sendFillScreen(0, 0, 0);
  sendSetTextColor(0, 255, 120);
  for (int i = 0; i < g_consoleCount; i++) {
    sendSetCursor(2, 2 + i * 8);
    sendPrintStr(g_console[i]);
  }
}

void jvmNativesReset() {
  g_currentDisplayable = 0;
  g_wantsExit = false;
  g_graphicsSingleton = 0;
  g_displaySingleton = 0;
  g_gfxState = GfxState();
  g_consoleCount = 0;
}

bool jvmNativeWantsExit() { return g_wantsExit; }

bool jvmNativeGetStaticField(const String &cls, const String &name, const String &desc, JWord &outValue) {
  (void)desc;
  if (cls == "java/lang/System" && (name == "out" || name == "err")) {
    // System.out/err - единственный "экземпляр" PrintStream, который
    // этой VM реально нужен: сам объект нигде не хранит состояния,
    // methodName+className для jvmInvokeByName достаточно того, что
    // мы вернём стабильный ненулевой хендл (сам объект-заглушка).
    static JRef s_out = 0;
    if (s_out == 0) s_out = jvmAllocNative(0 /* без спец. подтипа - неважно */, 0);
    outValue = s_out;
    return true;
  }
  return false;
}

bool jvmIsNativeClassName(const String &c) {
  return c == "java/lang/Object" || c == "java/lang/String" ||
         c == "java/lang/StringBuffer" || c == "java/lang/StringBuilder" ||
         c == "java/lang/System" || c == "java/io/PrintStream" ||
         c == "java/lang/Math" ||
         c == "javax/microedition/midlet/MIDlet" ||
         c == "javax/microedition/lcdui/Display" ||
         c == "javax/microedition/lcdui/Canvas" ||
         c == "javax/microedition/lcdui/Graphics";
}

bool jvmNativesHasActiveCanvas() { return g_currentDisplayable != 0; }

// Значение аргумента как String (для String/StringBuffer/println методов) -
// оба варианта (OBJ_STRING и голый int-код в редких случаях) на всякий
// случай, но в этой VM строки всегда OBJ_STRING.
static String argAsString(JRef ref) {
  ObjHeader *o = jvmObj(ref);
  if (!o || o->kind != OBJ_STRING) return "";
  return jvmStringAt(o->slotStart);
}

static void ensureSingletons() {
  if (g_graphicsSingleton == 0) g_graphicsSingleton = jvmAllocNative(NATIVE_GRAPHICS, 0);
  if (g_displaySingleton == 0)  g_displaySingleton  = jvmAllocNative(NATIVE_DISPLAY, 0);
}

// CLDC-совместимые коды клавиш (MIDP KEY_* / игровые действия) -
// см. javax.microedition.lcdui.Canvas в спецификации MIDP 2.0.
enum { MIDP_KEY_UP = -1, MIDP_KEY_DOWN = -2, MIDP_KEY_LEFT = -3, MIDP_KEY_RIGHT = -4,
       MIDP_KEY_FIRE = -5, MIDP_KEY_NUM0 = 48 };

void jvmNativesTick(int midletClassId, JRef midletRef) {
  (void)midletClassId; (void)midletRef;
  if (g_currentDisplayable == 0) return;
  ensureSingletons();

  ObjHeader *canvasObj = jvmObj(g_currentDisplayable);
  if (!canvasObj || canvasObj->kind != OBJ_INSTANCE) return;
  String canvasClass = g_classes[canvasObj->classId].name;

  JWord res; bool hasRes; String err;
  JWord paintArgs[1] = { g_graphicsSingleton };
  jvmInvokeByName(canvasClass, "paint", "(Ljavax/microedition/lcdui/Graphics;)V", 2,
                  g_currentDisplayable, paintArgs, 1, res, hasRes, err);
  // Ошибки перерисовки не валят UI-цикл прошивки - при желании их
  // можно вывести в консоль отладки (SerialPC) при доработке.

  struct { Btn *btn; int code; } keys[] = {
    { &bUp, MIDP_KEY_UP }, { &bDown, MIDP_KEY_DOWN },
    { &bLeft, MIDP_KEY_LEFT }, { &bRight, MIDP_KEY_RIGHT },
    { &bOk, MIDP_KEY_FIRE }, { &bCancel, MIDP_KEY_NUM0 },
  };
  for (auto &k : keys) {
    if (k.btn->pressed()) {
      JWord kArgs[1] = { k.code };
      jvmInvokeByName(canvasClass, "keyPressed", "(I)V", 2, g_currentDisplayable, kArgs, 1, res, hasRes, err);
    }
  }
}

bool jvmNativeInvoke(const String &cls, const String &name, const String &desc,
                     JRef thisRef, JWord *args, int argc,
                     JWord &outResult, bool &hasResult, String &err) {
  hasResult = false;
  outResult = 0;

  // --- java/lang/Object: единственное, что реально нужно - <init> как no-op
  if (cls == "java/lang/Object") {
    if (name == "<init>") return true;
    if (name == "toString") { outResult = jvmAllocString("java.lang.Object"); hasResult = true; return true; }
    err = "Object." + name + " not implemented"; return false;
  }

  // --- javax/microedition/midlet/MIDlet ---
  if (cls == "javax/microedition/midlet/MIDlet") {
    if (name == "<init>") return true;
    if (name == "notifyDestroyed") { g_wantsExit = true; return true; }
    if (name == "getAppProperty") { outResult = 0; hasResult = true; return true; } // null
    if (name == "platformRequest") { outResult = 0; hasResult = true; return true; }
    if (name == "resumeRequest") return true;
    err = "MIDlet." + name + " not implemented"; return false;
  }

  // --- javax/microedition/lcdui/Display ---
  if (cls == "javax/microedition/lcdui/Display") {
    ensureSingletons();
    if (name == "getDisplay") { outResult = g_displaySingleton; hasResult = true; return true; } // static
    if (name == "setCurrent") { g_currentDisplayable = args[0]; return true; }
    if (name == "getCurrent") { outResult = g_currentDisplayable; hasResult = true; return true; }
    if (name == "vibrate" || name == "flashBacklight") { outResult = 1; hasResult = true; return true; }
    err = "Display." + name + " not implemented"; return false;
  }

  // --- javax/microedition/lcdui/Canvas (база пользовательских экранов) ---
  if (cls == "javax/microedition/lcdui/Canvas") {
    if (name == "<init>") return true;
    if (name == "getWidth")  { outResult = DISPLAY_WIDTH;  hasResult = true; return true; }
    if (name == "getHeight") { outResult = DISPLAY_HEIGHT; hasResult = true; return true; }
    if (name == "repaint" || name == "serviceRepaints") return true; // тик вызовет paint() сам
    if (name == "setFullScreenMode" || name == "paint" || name == "keyPressed" ||
        name == "keyReleased" || name == "showNotify" || name == "hideNotify") return true; // no-op базового класса
    if (name == "hasPointerEvents" || name == "hasRepeatEvents" || name == "isDoubleBuffered") {
      outResult = 0; hasResult = true; return true;
    }
    err = "Canvas." + name + " not implemented"; return false;
  }

  // --- javax/microedition/lcdui/Graphics ---
  if (cls == "javax/microedition/lcdui/Graphics") {
    if (name == "setColor" && argc == 3) {
      g_gfxState = { (uint8_t)args[0], (uint8_t)args[1], (uint8_t)args[2] };
      return true;
    }
    if (name == "setColor" && argc == 1) {
      uint32_t rgb = (uint32_t)args[0];
      g_gfxState = { (uint8_t)(rgb >> 16), (uint8_t)(rgb >> 8), (uint8_t)rgb };
      return true;
    }
    if (name == "setGrayScale") {
      uint8_t v = (uint8_t)args[0];
      g_gfxState = { v, v, v };
      return true;
    }
    if (name == "drawLine") {
      sendDrawLine(args[0], args[1], args[2], args[3], g_gfxState.r, g_gfxState.g, g_gfxState.b);
      return true;
    }
    if (name == "drawRect") {
      sendDrawRect(args[0], args[1], args[2], args[3], g_gfxState.r, g_gfxState.g, g_gfxState.b);
      return true;
    }
    if (name == "fillRect") {
      sendFillRect(args[0], args[1], args[2], args[3], g_gfxState.r, g_gfxState.g, g_gfxState.b);
      return true;
    }
    if (name == "clearRect") {
      sendFillRect(args[0], args[1], args[2], args[3], 0, 0, 0);
      return true;
    }
    if (name == "drawString") {
      // (Ljava/lang/String;III)V - args: str, x, y, anchor (anchor игнорируется - top-left)
      sendSetTextColor(g_gfxState.r, g_gfxState.g, g_gfxState.b);
      sendSetCursor((uint16_t)args[1], (uint16_t)args[2]);
      sendPrintStr(argAsString(args[0]));
      return true;
    }
    if (name == "drawChar") {
      char buf[2] = { (char)args[0], 0 };
      sendSetTextColor(g_gfxState.r, g_gfxState.g, g_gfxState.b);
      sendSetCursor((uint16_t)args[1], (uint16_t)args[2]);
      sendPrintText(buf);
      return true;
    }
    if (name == "getColor") { outResult = (g_gfxState.r << 16) | (g_gfxState.g << 8) | g_gfxState.b; hasResult = true; return true; }
    if (name == "translate" || name == "setClip" || name == "clipRect" || name == "setFont" ||
        name == "fillArc" || name == "drawArc" || name == "drawImage" || name == "drawRegion") {
      return true; // подтверждённые, но пока не реализованные примитивы - тихий no-op, не ошибка
    }
    err = "Graphics." + name + " not implemented"; return false;
  }

  // --- java/lang/System ---
  if (cls == "java/lang/System") {
    if (name == "currentTimeMillis") { outResult = (JWord)millis(); hasResult = true; return true; }
    if (name == "arraycopy") {
      // (Ljava/lang/Object;ILjava/lang/Object;II)V - src,srcPos,dst,dstPos,len
      JWord *sf = jvmFields(args[0]); JWord *df = jvmFields(args[2]);
      if (!sf || !df) { err = "System.arraycopy: null array"; return false; }
      int srcPos = args[1], dstPos = args[3], len = args[4];
      for (int i = 0; i < len; i++) df[dstPos + i] = sf[srcPos + i];
      return true;
    }
    if (name == "exit") { g_wantsExit = true; return true; }
    if (name == "gc") return true; // нет GC - принимаем вызов молча
    err = "System." + name + " not implemented"; return false;
  }

  // --- java/io/PrintStream (System.out / System.err) ---
  if (cls == "java/io/PrintStream") {
    if (name == "println" || name == "print") {
      String line;
      if (desc.indexOf("Ljava/lang/String;") >= 0) line = argAsString(args[0]);
      else if (desc.indexOf('I') >= 0 || desc.indexOf('Z') >= 0 || desc.indexOf('C') >= 0) line = String((int)args[0]);
      else if (desc.indexOf('F') >= 0) line = String(jvmWordToFloat(args[0]));
      else if (argc == 0) line = "";
      else line = String((int)args[0]);
      if (name == "println") consolePush(line);
      else { g_console[g_consoleCount > 0 ? g_consoleCount - 1 : 0] += line; consolePush(g_console[g_consoleCount > 0 ? g_consoleCount - 1 : 0]); }
      return true;
    }
    err = "PrintStream." + name + " not implemented"; return false;
  }

  // --- java/lang/Math (только то, что реально бывает нужно на CLDC) ---
  if (cls == "java/lang/Math") {
    bool isFloat = desc.startsWith("(F") || desc == "(F)F";
    if (name == "abs") {
      if (isFloat) { outResult = jvmFloatToWord(fabsf(jvmWordToFloat(args[0]))); }
      else outResult = args[0] < 0 ? -args[0] : args[0];
      hasResult = true; return true;
    }
    if (name == "min") { outResult = isFloat ? jvmFloatToWord(fminf(jvmWordToFloat(args[0]), jvmWordToFloat(args[1]))) : (args[0] < args[1] ? args[0] : args[1]); hasResult = true; return true; }
    if (name == "max") { outResult = isFloat ? jvmFloatToWord(fmaxf(jvmWordToFloat(args[0]), jvmWordToFloat(args[1]))) : (args[0] > args[1] ? args[0] : args[1]); hasResult = true; return true; }
    if (name == "sqrt") { outResult = jvmFloatToWord(sqrtf(jvmWordToFloat(args[0]))); hasResult = true; return true; }
    err = "Math." + name + " not implemented (only abs/min/max/sqrt are - see HISTORY.md)"; return false;
  }

  // --- java/lang/String ---
  if (cls == "java/lang/String") {
    if (name == "<init>") return true; // упрощённо - пустая строка, если не через ldc
    if (name == "length") { outResult = argAsString(thisRef).length(); hasResult = true; return true; }
    if (name == "charAt") { String s = argAsString(thisRef); outResult = (args[0] >= 0 && args[0] < (int)s.length()) ? (uint8_t)s[args[0]] : 0; hasResult = true; return true; }
    if (name == "equals") { outResult = (argAsString(thisRef) == argAsString(args[0])) ? 1 : 0; hasResult = true; return true; }
    if (name == "concat" || (name == "valueOf")) {
      String s = (name == "concat") ? (argAsString(thisRef) + argAsString(args[0])) : String((int)args[0]);
      outResult = jvmAllocString(s); hasResult = true; return true;
    }
    if (name == "toString") { outResult = thisRef; hasResult = true; return true; }
    err = "String." + name + " not implemented"; return false;
  }

  // --- java/lang/StringBuffer / StringBuilder (упрощённо - как обычная String,
  //     конкатенация через ту же строковую таблицу, см. jvm_interp.cpp) ---
  if (cls == "java/lang/StringBuffer" || cls == "java/lang/StringBuilder") {
    if (name == "<init>") {
      JRef sref = jvmAllocString("");
      ObjHeader *o = jvmObj(thisRef);
      if (o) o->slotStart = jvmObj(sref)->slotStart; // делим строковый пул-слот
      if (o) o->kind = OBJ_STRING;                    // this отныне ведёт себя как OBJ_STRING
      return true;
    }
    if (name == "append") {
      String add;
      if (desc.indexOf("Ljava/lang/String;") >= 0) add = argAsString(args[0]);
      else if (desc.indexOf('F') >= 0) add = String(jvmWordToFloat(args[0]));
      else add = String((int)args[0]);
      String cur = argAsString(thisRef);
      ObjHeader *o = jvmObj(thisRef);
      if (o) o->slotStart = jvmInternString(cur + add);
      outResult = thisRef; hasResult = true;
      return true;
    }
    if (name == "toString") { outResult = thisRef; hasResult = true; return true; }
    err = "StringBuffer." + name + " not implemented"; return false;
  }

  err = cls + "." + name + desc + ": unknown native class/method";
  return false;
}
