#pragma once

// ================================================================
//  jvm_config.h — тюнинг движка Parus JavaME (CLDC 1.1 - подмножество
//  + минимальный javax.microedition.lcdui)
//
//  Все константы собраны в одном месте, т.к. RP2040 даёт всего
//  264KB SRAM на оба ядра, и это делится с FreeRTOS-стеками,
//  аудио-кольцевым буфером (audio.h, AUDIO_RING_SAMPLES) и самим
//  UI. Если что-то не помещается - тут первое место для правки.
// ================================================================

// Куча JVM (объекты, массивы) - фиксированный пул "ячеек" (Cell),
// без GC в первой версии (см. docs/HISTORY.md, раздел JavaME -
// "известные ограничения"). 6000 ячеек * ~12 байт/ячейку ~= 72KB.
#ifndef JVM_HEAP_CELLS
#define JVM_HEAP_CELLS        6000
#endif

// Максимальное число одновременно живых объектов/массивов (заголовков
// в g_objects[]). Каждый заголовок - несколько байт, отдельно от
// JVM_HEAP_CELLS (там - только *данные* полей/элементов).
#ifndef JVM_MAX_OBJECTS
#define JVM_MAX_OBJECTS       512
#endif

// Максимальная глубина стека вызовов (кадров интерпретатора).
// MIDlet-приложения редко рекурсируют глубоко.
#ifndef JVM_MAX_CALL_DEPTH
#define JVM_MAX_CALL_DEPTH    32
#endif

// Операндный стек и локальные переменные одного кадра (в 32-битных
// словах) - ограничение сверху на max_stack/max_locals из class-файла.
#ifndef JVM_MAX_OPSTACK
#define JVM_MAX_OPSTACK       64
#endif
#ifndef JVM_MAX_LOCALS
#define JVM_MAX_LOCALS        64
#endif

// Сколько классов может быть одновременно загружено (сам MIDlet +
// его суперклассы + вспомогательные классы). Нативные классы
// (java/lang/*, javax/microedition/lcdui/*) сюда не считаются -
// они не грузятся из .class, см. jvm_natives.cpp.
#ifndef JVM_MAX_CLASSES
#define JVM_MAX_CLASSES       24
#endif

// Куда терминал/explorer кладут .class файлы MIDlet-приложений.
// "run java" без аргумента открывает браузер по этому пути.
#ifndef JVM_APPS_DIR
#define JVM_APPS_DIR          "/sda/java"
#endif

// Пул для java/lang/String - строки живут отдельно от кучи объектов
// (это просто Arduino String с индексом-хендлом), т.к. хранить
// UTF-16-ish содержимое в 32-битных ячейках кучи бессмысленно.
#ifndef JVM_MAX_STRINGS
#define JVM_MAX_STRINGS       256
#endif
