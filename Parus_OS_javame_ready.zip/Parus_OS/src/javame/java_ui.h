// ============================================================
//  java_ui.h — интеграция JavaME (.jar/.jad) в UI Parus OS.
//  Подключается в Parus_OS.ino СРАЗУ ПОСЛЕ updateButtons()
//  (там же, где turbine_integration.h) — чтобы send*/DISPLAY_*/
//  b*-кнопки/currentState/STATE_* уже были объявлены.
//
//  Реализует три экрана:
//    STATE_JAVA_MENU     — пункт меню "Java": список установленных
//                          приложений + "Install from file...";
//    STATE_JAVA_INSTALL  — выбор носителя и Install/Run для выбранного
//                          в проводнике .jar/.jad;
//    STATE_JAVA_RUNNER   — работающий MIDlet (jvmTick()).
//
//  Тяжёлая логика (ZIP+inflate, JAD-парсер, установка/реестр) — в
//  src/javame/jar.*, jad.*, java_apps.* (компилируются как обычные
//  модули и ничего не знают о .ino).
// ============================================================
#pragma once
#include "jvm.h"
#include "java_apps.h"

// --- forward-декларации символов, определённых ниже в .ino ---
extern String browserPath;
extern std::vector<VfsEntry> browserEntries;
extern int browserSel, browserScroll;
void refreshBrowser();
void drawFileBrowser();
void drawMenu();

// ── фильтр файлов для проводника ─────────────────────────────
bool isJavaAppFile(const String &filename) { return javaIsAppFile(filename); }

// ── состояние Java-UI ────────────────────────────────────────
static std::vector<InstalledApp> gJavaApps;
static int gJavaMenuSel = 0, gJavaMenuScroll = 0;

static MidletInfo               gJavaInstMi;
static String                   gJavaInstJarPath;
static std::vector<JavaMedium>  gJavaMedia;
static int      gJavaInstMedium = 0;
static int      gJavaInstRow    = 0;   // 0=media 1=Install 2=Run 3=Cancel
static String   gJavaMsg;
static AppState gJavaReturnState = STATE_MENU;   // куда вернуться из раннера

#define JAVA_MENU_VISIBLE 5

// ── общий помощник: экран с крупной ошибкой ──────────────────
static void javaShowError(const String &title, const String &msg) {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 60, 0, 0);
  sendSetCursor(2, 2); sendSetTextColor(255, 220, 220);
  sendPrintStr(title);
  sendSetCursor(2, 30); sendSetTextColor(255, 150, 150);
  String e = msg;
  int maxc = DISPLAY_WIDTH / CHAR_W - 1;
  // разбиваем длинное сообщение на 3 строки
  for (int line = 0; line < 3 && e.length() > 0; line++) {
    String chunk = e.length() > (unsigned)maxc ? e.substring(0, maxc) : e;
    sendSetCursor(2, 30 + line * 12);
    sendPrintStr(chunk);
    e = e.length() > (unsigned)maxc ? e.substring(maxc) : "";
  }
  sendSetCursor(2, DISPLAY_HEIGHT - 12); sendSetTextColor(130, 130, 130);
  sendPrintText("HOME=back");
}

// ── запуск установленного приложения ─────────────────────────
static bool javaLaunchApp(const InstalledApp &app) {
  sendFillScreen(0, 0, 0);
  sendSetCursor(10, 55); sendSetTextColor(200, 200, 0);
  sendPrintText("Starting JavaME...");
  String err;
  if (!jvmRunMidletClass(app.dir, app.mainClass, err)) {
    javaShowError("JavaME error", err);
    delay(200);
    return false;
  }
  currentState = STATE_JAVA_RUNNER;
  return true;
}

// ── экран списка Java-приложений ─────────────────────────────
void drawJavaMenu() {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 14, 40, 0, 70);
  sendSetCursor(8, 3); sendSetTextColor(255, 255, 255);
  sendPrintText("Java Apps");

  int total = (int)gJavaApps.size() + 1;   // +1 — "Install from file..."
  for (int i = 0; i < JAVA_MENU_VISIBLE && (gJavaMenuScroll + i) < total; i++) {
    int idx = gJavaMenuScroll + i, y = 18 + i * 20;
    bool sel = (idx == gJavaMenuSel);
    bool isInstall = (idx == (int)gJavaApps.size());
    if (sel) { sendFillRect(3, y - 1, DISPLAY_WIDTH - 6, 18, 40, 0, 70); sendDrawRect(3, y - 1, DISPLAY_WIDTH - 6, 18, 160, 80, 200); sendSetTextColor(255, 200, 255); }
    else sendSetTextColor(isInstall ? 150 : 200, isInstall ? 200 : 180, isInstall ? 150 : 200);
    sendSetCursor(8, y + 3);
    if (isInstall) sendPrintText("+ Install from file...");
    else { String nm = gJavaApps[idx].name; if (utf8Len(nm) > 22) nm = utf8Substr(nm, 0, 21); sendPrintStr(nm); }
  }
  if (gJavaApps.empty()) {
    sendSetCursor(10, 90); sendSetTextColor(120, 120, 120);
    sendPrintText("No apps installed yet.");
  }
  sendFillRect(0, DISPLAY_HEIGHT - 11, DISPLAY_WIDTH, 11, 30, 0, 50);
  sendSetCursor(3, DISPLAY_HEIGHT - 9); sendSetTextColor(150, 120, 160);
  sendPrintText("OK=run/install  H=back");
}

void openJavaMenu() {
  javaListInstalled(gJavaApps);
  gJavaMenuSel = 0; gJavaMenuScroll = 0;
  currentState = STATE_JAVA_MENU;
  drawJavaMenu();
}

void handleJavaMenu(int encDelta) {
  int total = (int)gJavaApps.size() + 1;
  bool changed = false;
  if (bUp.pressed() || bUp.repeat()) { if (gJavaMenuSel > 0) { gJavaMenuSel--; changed = true; } }
  if (bDown.pressed() || bDown.repeat()) { if (gJavaMenuSel < total - 1) { gJavaMenuSel++; changed = true; } }
  if (encDelta != 0) { gJavaMenuSel = constrain(gJavaMenuSel + (encDelta > 0 ? 1 : -1), 0, total - 1); changed = true; }
  if (changed) {
    if (gJavaMenuSel < gJavaMenuScroll) gJavaMenuScroll = gJavaMenuSel;
    if (gJavaMenuSel >= gJavaMenuScroll + JAVA_MENU_VISIBLE) gJavaMenuScroll = gJavaMenuSel - JAVA_MENU_VISIBLE + 1;
    drawJavaMenu();
  }

  if (bOk.pressed()) {
    if (gJavaMenuSel < (int)gJavaApps.size()) {
      gJavaReturnState = STATE_JAVA_MENU;
      javaLaunchApp(gJavaApps[gJavaMenuSel]);   // при ошибке остаёмся, ждём HOME
    } else {
      // Install from file — открываем проводник для выбора .jar/.jad
      browserPath = "/"; browserSel = 0; refreshBrowser();
      currentState = STATE_FILE_BROWSER; drawFileBrowser();
    }
  }
  if (bHome.pressed() || bCancel.pressed()) { currentState = STATE_MENU; drawMenu(); }
}

// ── экран установки выбранного .jar/.jad ─────────────────────
void drawJavaInstall() {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 0, 40, 70);
  sendSetCursor(4, 2); sendSetTextColor(255, 255, 255);
  sendPrintText("Install JavaME");

  sendSetCursor(4, 17); sendSetTextColor(200, 255, 200);
  String nm = gJavaInstMi.name; if (utf8Len(nm) > 24) nm = utf8Substr(nm, 0, 23);
  sendPrintStr(nm);

  sendSetCursor(4, 29); sendSetTextColor(140, 140, 160);
  String mc = gJavaInstMi.mainClass; if (mc.length() > 25) mc = mc.substring(mc.length() - 25);
  sendPrintStr(mc);

  // строка выбора носителя
  const char *mediaLabel = gJavaMedia.empty() ? "?" : gJavaMedia[gJavaInstMedium].label.c_str();
  String mediaRoot = gJavaMedia.empty() ? "" : gJavaMedia[gJavaInstMedium].root;
  bool selMedia = (gJavaInstRow == 0);
  if (selMedia) sendFillRect(2, 43, DISPLAY_WIDTH - 4, 13, 0, 40, 60);
  sendSetCursor(4, 45); sendSetTextColor(selMedia ? 120 : 160, 200, selMedia ? 255 : 160);
  String mediaTxt = "Media: < " + mediaRoot + " >";
  sendPrintStr(mediaTxt);

  const char *rows[3] = { "Install & keep", "Run once", "Cancel" };
  for (int i = 0; i < 3; i++) {
    int y = 60 + i * 15;
    bool sel = (gJavaInstRow == i + 1);
    if (sel) { sendFillRect(2, y - 1, DISPLAY_WIDTH - 4, 14, 0, 60, 40); sendSetTextColor(120, 255, 160); }
    else sendSetTextColor(190, 190, 190);
    sendSetCursor(8, y + 2); sendPrintText(rows[i]);
  }

  if (gJavaMsg.length()) {
    sendFillRect(0, DISPLAY_HEIGHT - 23, DISPLAY_WIDTH, 11, 20, 20, 0);
    sendSetCursor(2, DISPLAY_HEIGHT - 22); sendSetTextColor(255, 210, 120);
    String m = gJavaMsg; int maxc = DISPLAY_WIDTH / CHAR_W - 1;
    if ((int)m.length() > maxc) m = m.substring(0, maxc);
    sendPrintStr(m);
  }
  sendFillRect(0, DISPLAY_HEIGHT - 11, DISPLAY_WIDTH, 11, 0, 30, 50);
  sendSetCursor(3, DISPLAY_HEIGHT - 9); sendSetTextColor(120, 120, 120);
  sendPrintText("UD=row LR=media OK=go H=back");
}

// Вызывается из проводника при открытии .jar/.jad.
void openJavaInstall(const String &path) {
  gJavaMsg = "";
  String err;
  if (!javaInspectFile(path, gJavaInstMi, gJavaInstJarPath, err)) {
    javaShowError("JavaME error", err);
    delay(1500);
    currentState = STATE_FILE_BROWSER; drawFileBrowser();
    return;
  }
  javaGetMedia(gJavaMedia);
  gJavaInstMedium = 0; gJavaInstRow = 1;
  gJavaReturnState = STATE_FILE_BROWSER;
  currentState = STATE_JAVA_INSTALL;
  drawJavaInstall();
}

void handleJavaInstall(int encDelta) {
  bool changed = false;
  if (bUp.pressed()) { if (gJavaInstRow > 0) { gJavaInstRow--; changed = true; } }
  if (bDown.pressed()) { if (gJavaInstRow < 3) { gJavaInstRow++; changed = true; } }
  if (encDelta != 0) { gJavaInstRow = constrain(gJavaInstRow + (encDelta > 0 ? 1 : -1), 0, 3); changed = true; }
  if ((bLeft.pressed() || bRight.pressed()) && !gJavaMedia.empty()) {
    int d = bRight.pressed() ? 1 : -1;
    gJavaInstMedium = (gJavaInstMedium + d + (int)gJavaMedia.size()) % (int)gJavaMedia.size();
    changed = true;
  }
  if (changed) drawJavaInstall();

  if (bOk.pressed()) {
    String root = gJavaMedia.empty() ? "/sda" : gJavaMedia[gJavaInstMedium].root;
    if (gJavaInstRow == 1 || gJavaInstRow == 2) {   // Install / Run
      InstalledApp app; String err;
      gJavaMsg = "Installing...";
      drawJavaInstall();
      if (!javaInstall(gJavaInstJarPath, gJavaInstMi, root, app, err)) {
        gJavaMsg = "Err: " + err;
        drawJavaInstall();
        return;
      }
      if (gJavaInstRow == 2) {                       // Run once
        gJavaReturnState = STATE_JAVA_MENU;
        javaLaunchApp(app);
      } else {                                       // Install & keep
        gJavaMsg = "Installed to " + root;
        drawJavaInstall();
      }
    } else if (gJavaInstRow == 3) {                  // Cancel
      currentState = STATE_FILE_BROWSER; drawFileBrowser();
    }
  }
  if (bHome.pressed() || bCancel.pressed()) { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
}

// ── работающий MIDlet ────────────────────────────────────────
void drawJavaRunner() { jvmTick(); }

void handleJavaRunner() {
  jvmTick();
  if (jvmWantsExit() || bHome.pressed() || bCancel.pressed()) {
    if (gJavaReturnState == STATE_JAVA_MENU) openJavaMenu();
    else { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
  }
}
