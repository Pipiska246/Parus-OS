#include "java_apps.h"
#include "jar.h"
#include "../vfs/vfs.h"

// ================================================================
//  java_apps.cpp — установка/реестр JavaME-приложений.
// ================================================================

namespace {

const char *APPS_SUB = "/java/apps";   // относительно корня носителя

String lower(const String &s) { String t = s; t.toLowerCase(); return t; }

String baseName(const String &path) {
  int slash = path.lastIndexOf('/');
  return slash >= 0 ? path.substring(slash + 1) : path;
}
String dirName(const String &path) {
  int slash = path.lastIndexOf('/');
  return slash > 0 ? path.substring(0, slash) : "/";
}
String stripExt(const String &name) {
  int dot = name.lastIndexOf('.');
  return dot > 0 ? name.substring(0, dot) : name;
}

// Безопасное имя каталога из имени приложения.
String sanitize(const String &s) {
  String out;
  for (size_t i = 0; i < s.length(); i++) {
    char c = s[i];
    if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') ||
        (c >= '0' && c <= '9') || c == '-' || c == '_') out += c;
    else if (c == ' ' || c == '.') out += '_';
  }
  if (out.length() == 0) out = "app";
  if (out.length() > 40) out = out.substring(0, 40);
  return out;
}

// Создаёт все промежуточные каталоги пути (mkdir -p).
bool mkdirp(const String &path) {
  if (path.length() == 0 || path == "/") return true;
  if (vfsExists(path)) return vfsIsDir(path);
  int from = 1;
  while (true) {
    int slash = path.indexOf('/', from);
    String part = (slash < 0) ? path : path.substring(0, slash);
    if (part.length() > 1 && !vfsExists(part)) {
      if (!vfsMkdir(part)) return false;
    }
    if (slash < 0) break;
    from = slash + 1;
  }
  return vfsExists(path) && vfsIsDir(path);
}

bool writeFile(const String &path, const uint8_t *data, size_t len) {
  VfsFile f;
  if (!f.openWrite(path, false)) return false;
  size_t w = len ? f.write(data, len) : 0;
  f.close();
  return w == len;
}
bool writeText(const String &path, const String &text) {
  return writeFile(path, (const uint8_t *)text.c_str(), text.length());
}

bool readText(const String &path, String &out) {
  VfsFile f;
  if (!f.openRead(path)) return false;
  uint32_t sz = f.size();
  std::vector<uint8_t> buf(sz);
  size_t got = sz ? f.read(buf.data(), sz) : 0;
  f.close();
  if (got != sz) return false;
  out = "";
  out.reserve(sz);
  for (uint32_t i = 0; i < sz; i++) out += (char)buf[i];
  return true;
}

// app.meta: простые "key=value" строки.
String metaGet(const String &meta, const String &key) {
  int from = 0;
  while (from < (int)meta.length()) {
    int nl = meta.indexOf('\n', from);
    String line = (nl < 0) ? meta.substring(from) : meta.substring(from, nl);
    int eq = line.indexOf('=');
    if (eq > 0) {
      String k = line.substring(0, eq); k.trim();
      if (k == key) { String v = line.substring(eq + 1); v.trim(); return v; }
    }
    if (nl < 0) break;
    from = nl + 1;
  }
  return "";
}

} // namespace

void javaGetMedia(std::vector<JavaMedium> &out) {
  out.clear();
  out.push_back({ "/sda", "Internal" });
  int parts = vfsExternalPartitionCount();
  for (int i = 1; i <= parts; i++) {
    out.push_back({ "/sdb" + String(i), "USB" + String(i) });
  }
}

void javaListInstalled(std::vector<InstalledApp> &out) {
  out.clear();
  std::vector<JavaMedium> media;
  javaGetMedia(media);
  for (auto &m : media) {
    String appsDir = m.root + APPS_SUB;
    if (!vfsExists(appsDir) || !vfsIsDir(appsDir)) continue;
    std::vector<VfsEntry> entries;
    if (!vfsListDir(appsDir, entries)) continue;
    for (auto &e : entries) {
      if (!e.isDir) continue;
      String dir = appsDir + "/" + e.name;
      String meta;
      if (!readText(dir + "/app.meta", meta)) continue;
      InstalledApp app;
      app.dir = dir;
      app.name = metaGet(meta, "name");
      app.mainClass = metaGet(meta, "main");
      if (app.name.length() == 0) app.name = e.name;
      if (app.mainClass.length() == 0) continue;
      out.push_back(app);
    }
  }
}

bool javaIsJarFile(const String &filename) { return lower(filename).endsWith(".jar"); }
bool javaIsJadFile(const String &filename) { return lower(filename).endsWith(".jad"); }
bool javaIsAppFile(const String &filename) { return javaIsJarFile(filename) || javaIsJadFile(filename); }

// Ищет .jar рядом с .jad (по MIDlet-Jar-URL basename, иначе - первый *.jar).
static String resolveJarNextTo(const String &jadPath, const String &jarUrl) {
  String dir = dirName(jadPath);
  if (jarUrl.length() > 0) {
    String want = baseName(jarUrl);
    // отрезаем возможные query-параметры "download.php?...=jar"
    int q = want.indexOf('?');
    if (q >= 0) want = want.substring(0, q);
    if (want.length() > 0) {
      String cand = dir + "/" + want;
      if (vfsExists(cand)) return cand;
    }
  }
  std::vector<VfsEntry> entries;
  if (vfsListDir(dir, entries)) {
    for (auto &e : entries) if (!e.isDir && javaIsJarFile(e.name)) return dir + "/" + e.name;
  }
  return "";
}

bool javaInspectFile(const String &path, MidletInfo &mi, String &jarPathOut, String &err) {
  mi = MidletInfo();
  jarPathOut = "";

  if (javaIsJadFile(path)) {
    String text;
    if (!readText(path, text)) { err = "cannot read " + path; return false; }
    JavaAttrs attrs;
    javaAttrsParse(text, attrs);
    javaMidletFromAttrs(attrs, mi);   // может не дать mainClass, если JAD неполный
    String jar = resolveJarNextTo(path, mi.jarUrl);
    if (jar.length() == 0) { err = "no .jar found next to " + baseName(path); return false; }
    jarPathOut = jar;
    // Если из JAD не вышло достать mainClass - добираем из манифеста JAR.
    if (!mi.valid()) {
      JarArchive ja;
      if (ja.open(jar, err)) {
        std::vector<uint8_t> man;
        String e2;
        if (ja.readByName("META-INF/MANIFEST.MF", man, e2)) {
          JavaAttrs mattrs;
          javaAttrsParse(man.data(), man.size(), mattrs);
          MidletInfo mmi;
          if (javaMidletFromAttrs(mattrs, mmi)) mi = mmi;
        }
      }
    }
    if (mi.name.length() == 0) mi.name = stripExt(baseName(path));
    if (!mi.valid()) { err = "MIDlet main class not found in JAD/manifest"; return false; }
    return true;
  }

  if (javaIsJarFile(path)) {
    JarArchive ja;
    if (!ja.open(path, err)) return false;
    std::vector<uint8_t> man;
    if (!ja.readByName("META-INF/MANIFEST.MF", man, err)) { err = "no MANIFEST.MF in " + baseName(path); return false; }
    JavaAttrs attrs;
    javaAttrsParse(man.data(), man.size(), attrs);
    javaMidletFromAttrs(attrs, mi);
    if (mi.name.length() == 0) mi.name = stripExt(baseName(path));
    jarPathOut = path;
    if (!mi.valid()) { err = "MIDlet-1 not found in manifest"; return false; }
    return true;
  }

  err = "not a .jar/.jad file";
  return false;
}

bool javaInstall(const String &jarPath, const MidletInfo &mi,
                 const String &mediumRoot, InstalledApp &outApp, String &err) {
  JarArchive ja;
  if (!ja.open(jarPath, err)) return false;

  String destDir = mediumRoot + APPS_SUB + "/" + sanitize(mi.name);
  if (!mkdirp(destDir)) { err = "cannot create " + destDir; return false; }

  int extracted = 0;
  for (const auto &e : ja.entries()) {
    if (e.isDir()) continue;
    // META-INF нам в рантайме не нужен - только .class и ресурсы.
    if (e.name.startsWith("META-INF/")) continue;

    std::vector<uint8_t> data;
    if (!ja.read(e, data, err)) return false;   // ошибка распаковки/CRC - прерываем

    String outPath = destDir + "/" + e.name;
    String parent = dirName(outPath);
    if (!mkdirp(parent)) { err = "cannot create " + parent; return false; }
    if (!writeFile(outPath, data.data(), data.size())) { err = "cannot write " + outPath; return false; }
    extracted++;
  }
  if (extracted == 0) { err = "empty archive (no classes extracted)"; return false; }

  String meta = "name=" + mi.name + "\n" +
                "main=" + mi.mainClass + "\n" +
                "vendor=" + mi.vendor + "\n" +
                "version=" + mi.version + "\n";
  if (!writeText(destDir + "/app.meta", meta)) { err = "cannot write app.meta"; return false; }

  outApp.name = mi.name;
  outApp.mainClass = mi.mainClass;
  outApp.dir = destDir;
  return true;
}
