#pragma once
#include <Arduino.h>
#include <vector>
#include <stdint.h>
#include "jvm_config.h"

// ================================================================
//  jvm_types.h — структуры, отражающие формат .class файла
//  (JVM Spec §4). Это подмножество: то, что реально встречается
//  в простых CLDC 1.1 - программах и MIDlet-ах, без module/nest/
//  record-атрибутов из современной Java - они этой VM не нужны,
//  т.к. javac для CLDC target 1.1/1.3 их и не генерирует.
// ================================================================

enum CpTag : uint8_t {
  CP_UTF8 = 1, CP_INTEGER = 3, CP_FLOAT = 4, CP_LONG = 5, CP_DOUBLE = 6,
  CP_CLASS = 7, CP_STRING = 8, CP_FIELDREF = 9, CP_METHODREF = 10,
  CP_INTERFACE_METHODREF = 11, CP_NAME_AND_TYPE = 12,
};

struct CpEntry {
  CpTag tag = CP_UTF8;
  // Для UTF8:
  String utf8;
  // Для CLASS/STRING: индекс на CP_UTF8 с именем/содержимым
  uint16_t nameIndex = 0;
  // Для FIELDREF/METHODREF/INTERFACE_METHODREF: класс + NameAndType
  uint16_t classIndex = 0;
  uint16_t nameAndTypeIndex = 0;
  // Для NAME_AND_TYPE
  uint16_t descriptorIndex = 0;
  // Для INTEGER/FLOAT (long/double не поддерживаются - см. HISTORY)
  int32_t intOrFloatBits = 0;
};

struct ExceptionHandler {
  uint16_t startPc, endPc, handlerPc;
  uint16_t catchType; // 0 = catch-all (finally)
};

struct MethodInfo {
  uint16_t accessFlags = 0;
  String   name;
  String   descriptor;
  // Code-атрибут (если это не native/abstract метод):
  uint16_t maxStack = 0;
  uint16_t maxLocals = 0;
  std::vector<uint8_t> code;
  std::vector<ExceptionHandler> handlers;
  bool isStatic() const { return accessFlags & 0x0008; }
  bool isNativeOrAbstract() const { return code.empty(); }
};

struct FieldInfo {
  uint16_t accessFlags = 0;
  String   name;
  String   descriptor;
  bool isStatic() const { return accessFlags & 0x0008; }
  // Слот в объекте (instance) либо в static-пуле класса - назначается
  // при линковке класса, см. jvm_interp.cpp::jvmResolveClass().
  int slot = -1;
};

// Полностью разобранный .class файл. Живёт в JvmClass::raw ниже -
// jvm_interp.cpp достраивает поверх него layout полей/vtable.
struct RawClassFile {
  uint16_t minorVersion = 0, majorVersion = 0;
  std::vector<CpEntry> cp; // индекс 0 не используется (как в спеке, cp[0] - фиктивный)
  uint16_t accessFlags = 0;
  uint16_t thisClassIdx = 0, superClassIdx = 0;
  std::vector<uint16_t> interfaces;
  std::vector<FieldInfo> fields;
  std::vector<MethodInfo> methods;

  String thisClassName() const;
  String superClassName() const;
  const String &utf8At(uint16_t idx) const;
};
