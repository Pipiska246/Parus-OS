#pragma once
#include <Arduino.h>
#include <vector>
#include "jad.h"

// ================================================================
//  java_apps.h — установка и реестр JavaME-приложений (.jar/.jad).
//
//  Установка = распаковка .jar (ZIP+inflate, см. jar.cpp) в
//  <носитель>/java/apps/<Имя>/ с сохранением структуры пакетов и
//  запись app.meta (имя + главный класс MIDlet-а). Реестр просто
//  сканирует эти каталоги на всех носителях (/sda + /sdbN).
// ================================================================

struct JavaMedium {
  String root;    // "/sda", "/sdb1", ...
  String label;   // "Internal", "USB1", ...
};

// Носители, доступные для установки (всегда есть внутренняя флешка
// /sda; /sdbN добавляются, если смонтирована USB-флешка).
void javaGetMedia(std::vector<JavaMedium> &out);

struct InstalledApp {
  String name;        // человекочитаемое имя
  String mainClass;   // "com/foo/Bar"
  String dir;         // каталог установки (searchDir для загрузчика классов)
};

// Сканирует все носители и собирает установленные приложения.
void javaListInstalled(std::vector<InstalledApp> &out);

// Разбирает выбранный в проводнике .jar или .jad:
//  - .jad: читает дескриптор, ищет рядом .jar (по MIDlet-Jar-URL или
//    первый *.jar в той же папке);
//  - .jar: читает META-INF/MANIFEST.MF.
// Возвращает MidletInfo (имя + главный класс) и путь к .jar.
bool javaInspectFile(const String &path, MidletInfo &mi, String &jarPathOut, String &err);

// Устанавливает jar (с уже разобранным mi) на носитель mediumRoot.
// Заполняет outApp (готов к запуску через jvmRunMidletClass).
bool javaInstall(const String &jarPath, const MidletInfo &mi,
                 const String &mediumRoot, InstalledApp &outApp, String &err);

// true, если имя файла - JavaME-приложение (для проводника).
bool javaIsJarFile(const String &filename);
bool javaIsJadFile(const String &filename);
bool javaIsAppFile(const String &filename);   // jar или jad
