#pragma once
#include <Arduino.h>
#include "jvm_object.h"

// ================================================================
//  jvm_interp.h — линковка классов (layout полей, static-хранилище)
//  и сам интерпретатор байткода.
// ================================================================

struct JvmClass {
  bool     used = false;
  RawClassFile raw;
  String   name;               // "com/example/Hello" (как в class-файле, со слэшами)
  int      superId = -1;       // индекс в g_classes[], если суперкласс тоже загружен из .class
  String   rootNativeBase;     // "javax/microedition/midlet/MIDlet" / "...lcdui/Canvas" / "java/lang/Object"
  String   searchDir;          // директория, где искать соседние .class при резолве зависимостей
  int      ownFieldCount = 0;
  int      totalFieldCount = 0;   // включая унаследованные - это и есть jvmAllocInstance(len)
  std::vector<JWord> staticStorage;
};

extern JvmClass g_classes[JVM_MAX_CLASSES];
extern int      g_classCount;

// Сбрасывает всё состояние VM (классы + куча) - вызывается перед
// каждым "run java <file>", т.к. GC-а нет (см. jvm_object.h).
void jvmResetRuntime();

// Загружает (если ещё не загружен) и линкует класс по имени
// ("com/example/Hello", без ".class"), ища .class-файл в searchDir.
// Возвращает индекс в g_classes[], либо -1 при ошибке (см. err).
int jvmResolveClass(const String &searchDir, const String &className, String &err);

// Вызов метода: если className совпадает с одним из имён, которые
// jvm_natives.cpp считает "своими" (см. jvmIsNativeClassName),
// вызов уходит в jvmNativeInvoke напрямую, минуя загрузку .class.
// invokeKind: 0=static, 1=special (constructor/super/private), 2=virtual
bool jvmInvokeByName(const String &className, const String &methodName,
                     const String &descriptor, int invokeKind,
                     JRef thisRef, JWord *args, int argCount,
                     JWord &outResult, bool &hasResult, String &err);

// Разбор дескриптора метода "(IFLjava/lang/String;)I": сколько слов
// занимают аргументы (каждый параметр - 1 слово, см. jvm_object.h -
// long/double не поддерживаются) и есть ли возвращаемое значение.
bool jvmParseMethodDescriptor(const String &desc, int &argWordCount, bool &hasReturn, String &err);

// --- используются только внутри javame/ (jvm_interp.cpp / jvm_interp_exec.cpp) ---
bool jvmFindField(int classId, const String &name, bool isStaticLookup, int &slotOut, int &ownerClassIdOut);
bool jvmFindMethod(int classId, const String &name, const String &desc, int &ownerClassIdOut, MethodInfo *&methodOut);
const String &jvmStringAt(int idx);
int  jvmInternString(const String &s);

// Выполняет уже найденный метод (с Code-атрибутом) в новом кадре
// интерпретатора. thisRef==0 для static-методов. args - argWordCount
// слов (см. jvmParseMethodDescriptor), уже включает "this" отдельно
// (this в args не кладётся - он передаётся через thisRef).
bool jvmExecMethod(int classId, MethodInfo *m, JRef thisRef,
                   JWord *args, int argCount, JWord &outResult, String &err);
