#pragma once
#include <Arduino.h>
#include <vector>
#include <stdint.h>

// ================================================================
//  jar.h — минимальный ридер ZIP-архивов (а .jar/.jad-приложения -
//  это обычные ZIP). Разбирает центральный каталог и умеет
//  распаковывать отдельные записи: метод 0 (stored) копированием,
//  метод 8 (deflate) - через puff.c (компактный inflate Марка Адлера).
//
//  Весь архив читается в RAM целиком (как и .class в jvm_classfile) -
//  MIDlet-джарники это единицы-десятки КБ. Ограничение осознанное,
//  см. docs/HISTORY.md (раздел JavaME - JAR/JAD).
// ================================================================

struct JarEntry {
  String   name;               // "com/foo/Bar.class", "img.png", ...
  uint16_t method = 0;         // 0 = stored, 8 = deflate
  uint32_t compSize = 0;       // размер сжатых данных
  uint32_t uncompSize = 0;     // размер после распаковки
  uint32_t crc32 = 0;          // CRC-32 из каталога (для проверки)
  uint32_t localHeaderOffset = 0;
  bool isDir() const { return name.length() > 0 && name[name.length() - 1] == '/'; }
};

class JarArchive {
public:
  // Читает файл целиком в RAM и разбирает центральный каталог.
  bool open(const String &vfsPath, String &err);
  bool isOpen() const { return _ok; }

  const std::vector<JarEntry> &entries() const { return _entries; }
  const JarEntry *find(const String &name) const;   // точное совпадение имени

  // Распаковывает одну запись в out (out очищается). Проверяет CRC-32.
  bool read(const JarEntry &e, std::vector<uint8_t> &out, String &err) const;
  bool readByName(const String &name, std::vector<uint8_t> &out, String &err) const;

private:
  std::vector<uint8_t>  _buf;      // весь .jar в RAM
  std::vector<JarEntry> _entries;
  bool _ok = false;
};

// CRC-32 (полином ZIP/PKZIP, 0xEDB88320) - используется для проверки
// корректности распаковки. Вынесена наружу: пригодна и для отладки.
uint32_t jarCrc32(const uint8_t *data, size_t len);
