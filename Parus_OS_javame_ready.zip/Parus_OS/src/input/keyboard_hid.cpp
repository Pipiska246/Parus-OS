#include "keyboard_hid.h"
#include "../core/ui_common.h"
#include "Adafruit_TinyUSB.h"

// ================================================================
//  Таблица ASCII для USB HID keycodes (US Keyboard Layout)
//  Индексы соответствуют HID keycode - 0x04
// ================================================================
static const uint8_t KEYCODE_TO_ASCII[][2] = {
  // 0x04-0x1D: a-z (индексы 0-25)
  {'a','A'}, {'b','B'}, {'c','C'}, {'d','D'}, {'e','E'}, 
  {'f','F'}, {'g','G'}, {'h','H'}, {'i','I'}, {'j','J'},
  {'k','K'}, {'l','L'}, {'m','M'}, {'n','N'}, {'o','O'},
  {'p','P'}, {'q','Q'}, {'r','R'}, {'s','S'}, {'t','T'},
  {'u','U'}, {'v','V'}, {'w','W'}, {'x','X'}, {'y','Y'}, {'z','Z'},
  // 0x1E-0x27: 1-0 (индексы 26-35)
  {'1','!'}, {'2','@'}, {'3','#'}, {'4','$'}, {'5','%'},
  {'6','^'}, {'7','&'}, {'8','*'}, {'9','('}, {'0',')'},
  // 0x28-0x2C: Enter, Escape, Backspace, Tab, Space (индексы 36-40)
  {'\r','\r'}, {'\x1b','\x1b'}, {'\b','\b'}, {'\t','\t'}, {' ',' '},
  // 0x2D-0x38: - = [ ] \ ; ' ` , . / (индексы 41-51)
  {'-','_'}, {'=','+'}, {'[','{'}, {']','}'}, {'\\','|'},
  {';',':'}, {'\'',';'}, {':','~'}, {',','<'}, {'.','>'}, {'/','?'},
  // 0x39-0x3F: CapsLock, F1-F4 (не используются) (индексы 52-58)
  {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0},
  // 0x40-0x45: F5-F8 (не используются) (индексы 59-64)
  {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0},
  // 0x46-0x4F: PrintScreen, ScrollLock, Pause, Insert, Home, PageUp, Delete, End, PageDown, Right (индексы 65-74)
  {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0},
  // 0x50-0x53: Left, Down, Up, Right (индексы 75-78)
  {0,0}, {0,0}, {0,0}, {0,0},
  // 0x54-0x57: Keypad / * - + (индексы 79-82)
  {'/','/'}, {'*','*'}, {'-','-'}, {'+','+'},
  // 0x58-0x5F: Keypad Enter, 1-9 (индексы 83-90)
  {'\r','\r'}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0},
  // 0x60-0x63: Keypad 0, ., 00, 000 (индексы 91-94)
  {'0','0'}, {'.','.'}, {0,0}, {0,0},
  // 0x64-0x67: Keypad =, ,, (, ) (индексы 95-98)
  {'=','='}, {0,0}, {0,0}, {0,0},
  // 0x68-0x6F: F13-F16 (не используются)
  {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}, {0,0}
};
#define KEYCODE_TABLE_SIZE (sizeof(KEYCODE_TO_ASCII) / sizeof(KEYCODE_TO_ASCII[0]))

// ================================================================
//  Small ring buffer of decoded key events
// ================================================================
#define HK_QUEUE_SIZE 32
static HidKeyEvent s_queue[HK_QUEUE_SIZE];
static volatile uint8_t s_qHead = 0, s_qTail = 0;

// Mirror of the most recently *decoded* event, kept around only so
// /dev/input/keyboard (input_vfs.h/.cpp) has something to read - it
// does not consume from s_queue, so it never steals a keystroke from
// the real terminal/editor input path.
static HidKeyEvent s_lastEvent = {HK_NONE, 0};

static inline void pushEvent(HidKeyKind kind, char ch = 0) {
  s_lastEvent.kind = kind;
  s_lastEvent.ch   = ch;
  uint8_t next = (s_qHead + 1) % HK_QUEUE_SIZE;
  if (next == s_qTail) return;
  s_queue[s_qHead].kind = kind;
  s_queue[s_qHead].ch   = ch;
  s_qHead = next;
}

bool hidKeyboardPopEvent(HidKeyEvent &ev) {
  if (s_qHead == s_qTail) return false;
  ev = s_queue[s_qTail];
  s_qTail = (s_qTail + 1) % HK_QUEUE_SIZE;
  return true;
}

bool hidKeyboardLastEvent(HidKeyEvent &ev) {
  if (s_lastEvent.kind == HK_NONE) return false;
  ev = s_lastEvent;
  return true;
}

// ---- connection state ----
static bool    s_kbdConnected = false;
static uint8_t s_kbdDevAddr = 0, s_kbdInstance = 0;

bool hidKeyboardConnected() { return s_kbdConnected; }

// ---- key-repeat ----
static hid_keyboard_report_t s_lastReport;
static bool     s_haveLastReport = false;
static unsigned long s_repeatAt = 0;
#define HK_REPEAT_DELAY_MS    500
#define HK_REPEAT_INTERVAL_MS 60

static HidKeyKind specialFromKeycode(uint8_t kc) {
  switch (kc) {
    case HID_KEY_ENTER:
    case HID_KEY_KEYPAD_ENTER: return HK_ENTER;
    case HID_KEY_BACKSPACE:    return HK_BACKSPACE;
    case HID_KEY_TAB:          return HK_TAB;
    case HID_KEY_ESCAPE:       return HK_ESC;
    case HID_KEY_ARROW_UP:     return HK_UP;
    case HID_KEY_ARROW_DOWN:   return HK_DOWN;
    case HID_KEY_ARROW_LEFT:   return HK_LEFT;
    case HID_KEY_ARROW_RIGHT:  return HK_RIGHT;
    case HID_KEY_DELETE:       return HK_DELETE;
    case HID_KEY_HOME:         return HK_HOME;
    case HID_KEY_END:          return HK_END;
    default: return HK_NONE;
  }
}

static void emitKeycode(uint8_t kc, bool shift) {
  if (kc == 0) return;

  // Сначала проверяем специальные клавиши
  HidKeyKind special = specialFromKeycode(kc);
  if (special != HK_NONE) { 
    pushEvent(special); 
    return; 
  }
  
  // Для печатных символов используем таблицу
  int idx = kc - 0x04;
  
  if (idx >= 0 && idx < (int)KEYCODE_TABLE_SIZE) {
    uint8_t ch = shift ? KEYCODE_TO_ASCII[idx][1] : KEYCODE_TO_ASCII[idx][0];
    if (ch != 0) {
      pushEvent(HK_CHAR, (char)ch);
    }
  }
}

static void processReport(const hid_keyboard_report_t *report) {
  bool shift = (report->modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT)) != 0;
  
  for (int i = 0; i < 6; i++) {
    uint8_t kc = report->keycode[i];
    if (kc == 0) continue;
    
    // Проверяем, была ли клавиша уже нажата
    bool wasHeld = false;
    if (s_haveLastReport) {
      for (int j = 0; j < 6; j++) {
        if (s_lastReport.keycode[j] == kc) { 
          wasHeld = true; 
          break; 
        }
      }
    }
    
    if (!wasHeld) {
      emitKeycode(kc, shift);
    }
  }
  
  s_lastReport = *report;
  s_haveLastReport = true;
  s_repeatAt = millis() + HK_REPEAT_DELAY_MS;
}

void hidKeyboardPoll() {
  if (!s_kbdConnected || !s_haveLastReport) return;
  
  uint8_t kc = 0;
  for (int i = 0; i < 6; i++) {
    if (s_lastReport.keycode[i] != 0) { 
      kc = s_lastReport.keycode[i]; 
      break; 
    }
  }
  if (kc == 0) return;
  
  unsigned long now = millis();
  if ((long)(now - s_repeatAt) >= 0) {
    bool shift = (s_lastReport.modifier & (KEYBOARD_MODIFIER_LEFTSHIFT | KEYBOARD_MODIFIER_RIGHTSHIFT)) != 0;
    emitKeycode(kc, shift);
    s_repeatAt = now + HK_REPEAT_INTERVAL_MS;
  }
}

void hidKeyboardInit() {
  s_kbdConnected = false;
  s_haveLastReport = false;
}

// ================================================================
//  TinyUSB HID host callbacks
// ================================================================
extern "C" {

void tuh_hid_mount_cb(uint8_t dev_addr, uint8_t instance, uint8_t const *desc_report, uint16_t desc_len) {
  (void) desc_report; (void) desc_len;
  uint8_t protocol = tuh_hid_interface_protocol(dev_addr, instance);
  if (protocol == HID_ITF_PROTOCOL_KEYBOARD) {
    s_kbdConnected   = true;
    s_kbdDevAddr     = dev_addr;
    s_kbdInstance    = instance;
    s_haveLastReport = false;
    tuh_hid_set_protocol(dev_addr, instance, HID_PROTOCOL_BOOT);
  }
  tuh_hid_receive_report(dev_addr, instance);
}

void tuh_hid_umount_cb(uint8_t dev_addr, uint8_t instance) {
  if (s_kbdConnected && dev_addr == s_kbdDevAddr && instance == s_kbdInstance) {
    s_kbdConnected   = false;
    s_haveLastReport = false;
  }
}

void tuh_hid_report_received_cb(uint8_t dev_addr, uint8_t instance, uint8_t const *report, uint16_t len) {
  if (s_kbdConnected && dev_addr == s_kbdDevAddr && instance == s_kbdInstance &&
      len >= sizeof(hid_keyboard_report_t)) {
    processReport((const hid_keyboard_report_t *)report);
  }
  tuh_hid_receive_report(dev_addr, instance);
}

}  // extern "C"