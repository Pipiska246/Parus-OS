#pragma once
#include <Arduino.h>

// ================================================================
//  keyboard_hid.h — USB HID boot-keyboard support
//
//  The board has exactly one USB-host port (pio-usb, see config.h
//  USB_HOST_DP_PIN). Normally that's where you plug a USB flash
//  drive (handled by vfs.cpp / tuh_msc_*). This adds the other
//  common thing people plug into that port: a USB keyboard.
//
//  Only one device at a time (same as a real PC USB port without a
//  hub) - plug in a keyboard instead of a flash drive when you want
//  to type into the terminal/editor with real keys instead of the
//  button-driven on-screen keyboard.
//
//  Uses the USB HID "boot keyboard" protocol (8-byte report:
//  modifiers, reserved, 6 keycodes), which is what essentially every
//  USB keyboard supports regardless of brand.
// ================================================================

enum HidKeyKind {
  HK_NONE,
  HK_CHAR,        // printable ASCII character, see HidKeyEvent::ch
  HK_ENTER,
  HK_BACKSPACE,
  HK_TAB,
  HK_ESC,
  HK_UP, HK_DOWN, HK_LEFT, HK_RIGHT,
  HK_DELETE,
  HK_HOME, HK_END
};

struct HidKeyEvent {
  HidKeyKind kind;
  char       ch;   // valid when kind == HK_CHAR
};

// Call once from setup(), after USBHost.begin(...).
void hidKeyboardInit();

// True if a USB keyboard is currently enumerated on the host port.
bool hidKeyboardConnected();

// Pops one decoded key event (with simple key-repeat) from the
// internal queue. Returns false if there's nothing new.
bool hidKeyboardPopEvent(HidKeyEvent &ev);

// Non-consuming peek at the last decoded event (does not touch the
// queue above). Used by /dev/input/keyboard so it can be read as a
// file without stealing input from whatever app is actually reading
// hidKeyboardPopEvent(). Returns false if no key has ever been decoded.
bool hidKeyboardLastEvent(HidKeyEvent &ev);

// Must be called every loop() iteration (cheap - just checks a timer
// for key-repeat; the actual report parsing happens in the TinyUSB
// HID host callbacks, which fire from inside USBHost.task()).
void hidKeyboardPoll();
