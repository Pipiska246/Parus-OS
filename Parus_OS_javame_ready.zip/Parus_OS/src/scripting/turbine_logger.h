// ============================================================
//  turbine_logger.h — упрощённое логирование (безопасная версия)
//
//  Почему было важно переписать:
//  - SerialPC.print()/println() на стеке Adafruit TinyUSB блокируется
//    НАВСЕГДА, если буфер CDC заполнен и никто не читает порт (нет
//    открытого монитора порта). Старая версия логгера писала в Serial
//    на КАЖДЫЙ вызов (gpio.read/write, print, begin/end) - это и было
//    причиной зависания .tu скриптов сразу при запуске.
//  - Открытие/запись/закрытие файла на флешку на каждый вызов gpio -
//    очень медленно и дополнительно усиливает проблему.
//
//  Эта версия:
//  - В Serial пишет ТОЛЬКО если порт реально открыт (`if (SerialPC)`),
//    и то не каждую строку — это просто диагностика, а не основной канал.
//  - В файл пишет накопленным буфером, с ограничением частоты сбросов.
//  - GPIO-операции не логируются построчно (это было лишним и медленным);
//    есть отдельный режим verbose, если он правда нужен - см. setVerbose().
// ============================================================
#pragma once
#include "../vfs/vfs.h"

class TurbineLogger {
private:
    String _logPath;
    bool   _enabled     = false;
    bool   _initialized = false;
    bool   _verbose     = false;
    String _buffer;
    unsigned long _lastFlush = 0;
    static const size_t FLUSH_BYTES = 512;
    static const unsigned long FLUSH_INTERVAL_MS = 2000;

    // Печатает в Serial ТОЛЬКО если порт реально открыт (DTR), иначе
    // тихо игнорирует строку - никогда не блокирует выполнение скрипта.
    void safePrintln(const String& s) {
        if (SerialPC) SerialPC.println(s);
    }

public:
    TurbineLogger() {}

    void setVerbose(bool v) { _verbose = v; }
    bool isVerbose() const { return _verbose; }

    bool begin(const String& tuPath) {
        _logPath = tuPath;
        int dot = _logPath.lastIndexOf('.');
        if (dot > 0) _logPath = _logPath.substring(0, dot) + ".log";
        else         _logPath = _logPath + ".log";

        VfsFile test;
        if (test.openWrite(_logPath, false)) {
            test.close();
            _initialized = true;
        } else {
            _initialized = false;
            safePrintln("LOG: ERROR - cannot create log file: " + _logPath);
            return false;
        }

        _enabled = true;
        _buffer = "";
        _lastFlush = millis();

        log("======================================");
        log("Turbine Script Log");
        log("File: " + tuPath);
        log("Started: " + getTimestamp());
        log("======================================");
        return true;
    }

    void end() {
        if (!_enabled) return;
        log("Finished: " + getTimestamp());
        flush();
        _enabled = false;
        _initialized = false;
    }

    void log(const String& msg) {
        if (!_enabled || !_initialized) return; // тихо - без Serial-спама
        _buffer += getTimestamp() + " " + msg + "\n";
        unsigned long now = millis();
        if (_buffer.length() > FLUSH_BYTES || (now - _lastFlush) > FLUSH_INTERVAL_MS) {
            flush();
        }
    }

    // verbose-лог для шумных событий (gpio и т.п.) - пишется только если
    // включён setVerbose(true), чтобы не плодить лишний I/O по умолчанию.
    void logVerbose(const String& msg) {
        if (_verbose) log(msg);
    }

    void error(const String& msg) { log("[ERROR] " + msg); }
    void info(const String& msg)  { log("[INFO] " + msg); }
    void funcCall(const String& name) { log("[CALL] " + name + "()"); }

    void flush() {
        if (!_enabled || !_initialized || _buffer.length() == 0) { _lastFlush = millis(); return; }
        VfsFile f;
        if (f.openWrite(_logPath, true)) {
            f.write((const uint8_t*)_buffer.c_str(), _buffer.length());
            f.close();
        }
        _buffer = "";
        _lastFlush = millis();
    }

    bool isEnabled() const { return _enabled; }
    String getLogPath() const { return _logPath; }

private:
    String getTimestamp() {
        unsigned long ms = millis();
        unsigned long seconds = ms / 1000;
        unsigned long minutes = seconds / 60;
        unsigned long hours = minutes / 60;
        seconds %= 60; minutes %= 60;
        char buf[16];
        snprintf(buf, sizeof(buf), "[%02lu:%02lu:%02lu.%03lu]",
                 hours, minutes, seconds, ms % 1000);
        return String(buf);
    }
};

// Глобальный экземпляр
extern TurbineLogger gTurbineLogger;
