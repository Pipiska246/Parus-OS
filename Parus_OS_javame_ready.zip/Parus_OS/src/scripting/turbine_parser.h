#pragma once
#include "turbine_lexer.h"
#include "turbine_interp.h"

// ============================================================
//  Turbine Parser  →  builds AST
// ============================================================

struct Parser {
  Lexer*    lx    = nullptr;
  TInterp*  interp = nullptr;
  bool      hasError = false;
  String    errMsg;

  void init(Lexer* l, TInterp* ti) { lx=l; interp=ti; }

  Token peek(int off=0)  { return lx->peek2(off); }
  Token next()           { return lx->next(); }
  void  skipNL()         { lx->skipNewlines(); }

  bool check(TokKind k)  { return peek().kind==k; }
  bool eat(TokKind k)    { if(check(k)){next();return true;} return false; }

  void expect(TokKind k, const char* msg) {
    if(!eat(k)) error(String(msg)+" got "+peek().sval+"("+String((int)peek().kind)+")");
  }
  void error(const String& m) {
    if(!hasError){ hasError=true; errMsg=m;
      interp->error("Parse: "+m); }
  }

  // ── allocate AST node ─────────────────────────────────────
  ASTNode* newNode(ASTKind k) {
    ASTNode* n = new ASTNode();
    n->kind = k;
    return n;
  }
  ASTNode* litInt(long v)    { auto*n=newNode(AST_INT_LIT);   n->ival=v; return n; }
  ASTNode* litFlt(double v)  { auto*n=newNode(AST_FLOAT_LIT); n->fval=v; return n; }
  ASTNode* litBool(bool v)   { auto*n=newNode(AST_BOOL_LIT);  n->bval=v; return n; }
  ASTNode* litStr(String v)  { auto*n=newNode(AST_STRING_LIT);n->sval=v; return n; }

  // ── parse whole source ────────────────────────────────────
  void parseAll() {
    skipNL();
    while(!check(TOK_EOF) && !hasError) {
      Token t = peek();
      if(t.kind==TOK_ARROW) {
        parseImport();
      } else if(t.kind==TOK_DBLHASH) {
        parseEnumOrStruct();
      } else if(t.kind==TOK_HASH) {
        parseFuncDef();
      } else if(t.kind==TOK_NEWLINE) {
        next();
      } else {
        error("Unexpected top-level token: "+t.sval);
        next();
      }
    }
  }

  void parseImport() {
    next(); // '>'
    skipNL();
    Token t = next();
    if(t.kind!=TOK_IDENT){ error("Expected module name"); return; }
    if(interp->nImports < TI_MAX_MODS)
      interp->imports[interp->nImports++] = t.sval;
    skipNL();
  }

  // ── enum / struct ─────────────────────────────────────────
  void parseEnumOrStruct() {
    next(); // '##'
    skipNL();
    Token nameTok = next();
    if(nameTok.kind!=TOK_IDENT){ error("Expected type name"); return; }
    skipNL();
    Token kindTok = next(); // 'enum' or 'struct'
    skipNL();

    if(kindTok.sval=="enum") {
      parseEnumBody(nameTok.sval);
    } else if(kindTok.sval=="struct") {
      parseStructBody(nameTok.sval);
    } else {
      error("Expected 'enum' or 'struct' after ##");
    }
  }

  void parseEnumBody(const String& name) {
    if(interp->nEnums>=TI_MAX_ENUMS){ error("Too many enums"); return; }
    TEnumDef& ed = interp->enums[interp->nEnums++];
    ed.name = name;

    // parse column header: ': tag , col1 , col2 ...'
    skipNL();
    // skip INDENT
    eat(TOK_INDENT);
    skipNL();

    if(!check(TOK_COLON)) { error("Expected ':' for enum columns"); return; }
    next(); // ':'
    // read column names
    int ncols = 0;
    TEnumCol tempCols[8];
    while(check(TOK_IDENT)||check(TOK_COMMA)) {
      if(check(TOK_COMMA)){ next(); continue; }
      tempCols[ncols++].name = next().sval;
      if(ncols>=8) break;
    }
    ed.nCols = ncols;
    ed.cols  = new TEnumCol[ncols];
    for(int i=0;i<ncols;i++) ed.cols[i]=tempCols[i];
    skipNL();

    // parse rows: '- tag , val1 , val2 ...'
    int nrows=0;
    TEnumRow tempRows[32];
    while((check(TOK_DASH)||check(TOK_NEWLINE))&&nrows<32) {
      if(check(TOK_NEWLINE)){next();continue;}
      next(); // '-'
      skipNL();
      Token tagTok = next();
      if(tagTok.kind!=TOK_IDENT) break;
      tempRows[nrows].tag = tagTok.sval;
      tempRows[nrows].vals = new TValue[ncols];
      for(int ci=1;ci<ncols;ci++) {
        skipNL();
        if(check(TOK_COMMA)) next();
        skipNL();
        TValue v;
        if(check(TOK_STRING)) { Token t=next(); v=TValue(t.sval); }
        else if(check(TOK_INT)){ Token t=next(); v=TValue((long)t.ival); }
        else if(check(TOK_FLOAT)){Token t=next(); v=TValue(t.fval); }
        else if(check(TOK_BOOL)){Token t=next(); v=TValue(t.bval); }
        tempRows[nrows].vals[ci] = v;
      }
      nrows++;
      skipNL();
    }
    ed.nRows = nrows;
    ed.rows  = new TEnumRow[nrows];
    for(int i=0;i<nrows;i++) ed.rows[i]=tempRows[i];
    eat(TOK_DEDENT);
  }

  void parseStructBody(const String& name) {
    if(interp->nStructs>=TI_MAX_STRUCTS){ error("Too many structs"); return; }
    TStructDef& sd = interp->structs[interp->nStructs++];
    sd.name = name;
    skipNL();
    eat(TOK_INDENT);
    int nf=0;
    TStructField tempF[16];
    while((check(TOK_DASH)||check(TOK_NEWLINE))&&nf<16) {
      if(check(TOK_NEWLINE)){next();continue;}
      next(); // '-'
      skipNL();
      Token fn = next(); if(fn.kind!=TOK_IDENT) break;
      tempF[nf].name = fn.sval;
      skipNL();
      if(check(TOK_IDENT)) tempF[nf].typeName = next().sval;
      if(eat(TOK_EQ)) {
        // parse default value expression
        tempF[nf].defVal = TValue(); // TODO: simple literals
      }
      nf++;
      skipNL();
    }
    sd.nFields = nf;
    sd.fields  = new TStructField[nf];
    for(int i=0;i<nf;i++) sd.fields[i]=tempF[i];
    eat(TOK_DEDENT);
  }

  // ── function definition ───────────────────────────────────
  void parseFuncDef() {
    next(); // '#'
    skipNL();
    Token nameTok = next();
    if(nameTok.kind!=TOK_IDENT){ error("Expected function name"); return; }
    if(interp->nFuncs>=TI_MAX_FUNCS){ error("Too many functions"); return; }
    TFuncDef& fd = interp->funcs[interp->nFuncs++];
    fd.name = nameTok.sval;

    // params: (name type, ...)
    expect(TOK_LPAREN,"Expected '('");
    int np=0;
    TParam tempP[8];
    while(!check(TOK_RPAREN)&&!check(TOK_EOF)) {
      bool isOut=false;
      if(check(TOK_IDENT)&&peek().sval=="out"){ next(); isOut=true; }
      if(!check(TOK_IDENT)) break;
      tempP[np].name = next().sval;
      skipNL();
      if(check(TOK_IDENT)||check(TOK_LBRACE)) {
        tempP[np].typeName = parseTypeName();
      }
      if(np<4) fd.isOut[np]=isOut;
      np++;
      eat(TOK_COMMA);
    }
    expect(TOK_RPAREN,"Expected ')'");
    fd.nParams = np;
    fd.params  = new TParam[np];
    for(int i=0;i<np;i++) fd.params[i]=tempP[i];
    // return type
    skipNL();
    if(check(TOK_IDENT)) fd.retType = next().sval;
    skipNL();
    // body
    fd.body = parseBlock();
  }

  String parseTypeName() {
    String tn = "";
    if(check(TOK_IDENT)) { tn=next().sval; }
    if(check(TOK_LBRACE)) {
      next(); tn+="{";
      if(check(TOK_IDENT)) tn+=next().sval;
      if(check(TOK_RBRACE)){ next(); tn+="}"; }
    }
    return tn;
  }

  // ── block (indented statements) ───────────────────────────
  ASTNode* parseBlock() {
    ASTNode* blk = newNode(AST_BLOCK);
    skipNL();
    if(!eat(TOK_INDENT)) return blk; // empty block
    skipNL();
    while(!check(TOK_DEDENT)&&!check(TOK_EOF)&&!hasError) {
      if(check(TOK_NEWLINE)){next();continue;}
      ASTNode* s = parseStmt();
      if(s) blk->addChild(s);
    }
    eat(TOK_DEDENT);
    return blk;
  }

  // ── statement ─────────────────────────────────────────────
  ASTNode* parseStmt() {
    Token t = peek();
    ASTNode* n = nullptr;

    if(t.kind==TOK_DASH) {
      n = parseVarDecl();
    } else if(t.kind==TOK_IF) {
      n = parseIf();
    } else if(t.kind==TOK_WHILE) {
      n = parseWhile();
    } else if(t.kind==TOK_FOR) {
      n = parseFor();
    } else if(t.kind==TOK_SWITCH) {
      n = parseSwitch();
    } else if(t.kind==TOK_RETURN) {
      next();
      n = newNode(AST_RETURN);
      if(!check(TOK_NEWLINE)&&!check(TOK_EOF)&&!check(TOK_DEDENT))
        n->addChild(parseExpr());
    } else if(t.kind==TOK_BREAK) {
      next(); n=newNode(AST_BREAK);
    } else if(t.kind==TOK_CONTINUE) {
      next(); n=newNode(AST_CONTINUE);
    } else {
      // assignment or expression
      n = parseExprOrAssign();
    }
    skipNL();
    return n;
  }

  // '- name [type] [= expr]'
  ASTNode* parseVarDecl() {
    next(); // '-'
    skipNL();
    Token nameTok = next();
    if(nameTok.kind!=TOK_IDENT){ error("Expected variable name"); return nullptr; }
    ASTNode* n = newNode(AST_VAR_DECL);
    n->sval = nameTok.sval;
    // optional type
    if(check(TOK_IDENT)||check(TOK_LBRACE)) {
      n->sval += "|" + parseTypeName(); // encode type in sval after '|'
    }
    // optional initializer
    if(eat(TOK_EQ)) {
      n->addChild(parseExpr());
    }
    return n;
  }

  ASTNode* parseIf() {
    next(); // 'if'
    ASTNode* n = newNode(AST_IF);
    n->addChild(parseExpr());   // condition
    n->addChild(parseBlock());  // then block
    // elif / else
    while(check(TOK_ELIF)||check(TOK_ELSE)) {
      if(eat(TOK_ELIF)) {
        n->addChild(parseExpr());
        n->addChild(parseBlock());
      } else {
        next(); // 'else'
        n->addChild(newNode(AST_NIL_LIT)); // placeholder condition = true
        n->addChild(parseBlock());
        break;
      }
    }
    return n;
  }

  ASTNode* parseWhile() {
    next();
    ASTNode* n = newNode(AST_WHILE);
    n->addChild(parseExpr());
    n->addChild(parseBlock());
    return n;
  }

  ASTNode* parseFor() {
    next(); // 'for'
    skipNL();
    // 'for i, val in container' or 'for val in container'
    ASTNode* n = newNode(AST_FOR_IN);
    Token t1 = next();
    if(t1.kind!=TOK_IDENT){ error("Expected loop var"); return nullptr; }
    n->sval = t1.sval;
    if(eat(TOK_COMMA)) {
      // two vars: i, val
      Token t2=next();
      n->sval += ","+t2.sval; // encode both names
    }
    expect(TOK_IN,"Expected 'in'");
    n->addChild(parseExpr()); // iterable
    n->addChild(parseBlock());
    return n;
  }

  ASTNode* parseSwitch() {
    next(); // 'switch'
    ASTNode* n = newNode(AST_SWITCH);
    n->addChild(parseExpr()); // value
    skipNL();
    eat(TOK_INDENT);
    skipNL();
    // cases: '* Tag\n  block'
    while((check(TOK_STAR)||check(TOK_NEWLINE))&&!check(TOK_EOF)) {
      if(check(TOK_NEWLINE)){next();continue;}
      next(); // '*'
      skipNL();
      ASTNode* caseLabel = newNode(AST_IDENT);
      // case can be a dotted ident like Shape.Line
      Token ct = next();
      caseLabel->sval = ct.sval;
      if(eat(TOK_DOT)) { caseLabel->sval += "."+next().sval; }
      n->addChild(caseLabel);
      n->addChild(parseBlock());
      skipNL();
    }
    eat(TOK_DEDENT);
    return n;
  }

  // assignment or expr statement
  ASTNode* parseExprOrAssign() {
    ASTNode* lhs = parseExpr();
    TokKind k = peek().kind;
    if(k==TOK_EQ||k==TOK_PLUSEQ||k==TOK_MINUSEQ||k==TOK_STAREQ||k==TOK_SLASHEQ) {
      next();
      ASTNode* rhs = parseExpr();
      ASTNode* n = newNode(AST_ASSIGN);
      const char* ops[]={"=","+=","-=","*=","/="};
      TokKind ks[]={TOK_EQ,TOK_PLUSEQ,TOK_MINUSEQ,TOK_STAREQ,TOK_SLASHEQ};
      for(int i=0;i<5;i++) if(ks[i]==k){ n->sval=ops[i]; break; }
      n->addChild(lhs);
      n->addChild(rhs);
      return n;
    }
    ASTNode* n = newNode(AST_EXPR_STMT);
    n->addChild(lhs);
    return n;
  }

  // ── expressions ───────────────────────────────────────────
  ASTNode* parseExpr()   { return parseOr(); }

  ASTNode* parseOr() {
    ASTNode* n = parseAnd();
    while(check(TOK_OR)) {
      next();
      ASTNode* b = newNode(AST_BINARY); b->sval="or";
      b->addChild(n); b->addChild(parseAnd()); n=b;
    }
    return n;
  }
  ASTNode* parseAnd() {
    ASTNode* n = parseNot();
    while(check(TOK_AND)) {
      next();
      ASTNode* b = newNode(AST_BINARY); b->sval="and";
      b->addChild(n); b->addChild(parseNot()); n=b;
    }
    return n;
  }
  ASTNode* parseNot() {
    if(check(TOK_NOT)){ next(); ASTNode* u=newNode(AST_UNARY); u->sval="not"; u->addChild(parseCmp()); return u; }
    return parseCmp();
  }
  ASTNode* parseCmp() {
    ASTNode* n = parseAdd();
    while(true) {
      TokKind k=peek().kind;
      if(k!=TOK_EQEQ&&k!=TOK_NEQ&&k!=TOK_LT&&k!=TOK_LE&&k!=TOK_GT&&k!=TOK_GE) break;
      const char* ops[]={"==","!=","<","<=",">",">="};
      TokKind   ks []={TOK_EQEQ,TOK_NEQ,TOK_LT,TOK_LE,TOK_GT,TOK_GE};
      String op;
      for(int i=0;i<6;i++) if(ks[i]==k){op=ops[i];break;}
      next();
      ASTNode* b=newNode(AST_BINARY); b->sval=op;
      b->addChild(n); b->addChild(parseAdd()); n=b;
    }
    return n;
  }
  ASTNode* parseAdd() {
    ASTNode* n = parseMul();
    while(check(TOK_PLUS)||check(TOK_MINUS2)) {
      String op=check(TOK_PLUS)?"+":"-"; next();
      ASTNode* b=newNode(AST_BINARY); b->sval=op;
      b->addChild(n); b->addChild(parseMul()); n=b;
    }
    return n;
  }
  ASTNode* parseMul() {
    ASTNode* n = parsePow();
    while(check(TOK_STAR)||check(TOK_SLASH)||check(TOK_PERCENT)) {
      String op = check(TOK_STAR)?"*":(check(TOK_SLASH)?"/":"%"); next();
      ASTNode* b=newNode(AST_BINARY); b->sval=op;
      b->addChild(n); b->addChild(parsePow()); n=b;
    }
    return n;
  }
  ASTNode* parsePow() {
    ASTNode* n = parseUnary();
    if(check(TOK_CARET)){ next();
      ASTNode* b=newNode(AST_BINARY);b->sval="^";
      b->addChild(n);b->addChild(parsePow());return b;
    }
    return n;
  }
  ASTNode* parseUnary() {
    if(check(TOK_MINUS2)){ next(); ASTNode* u=newNode(AST_UNARY);u->sval="-";u->addChild(parsePostfix());return u; }
    return parsePostfix();
  }
  ASTNode* parsePostfix() {
    ASTNode* n = parsePrimary();
    while(true) {
      if(check(TOK_DOT)) {
        next();
        Token m=next();
        if(check(TOK_LPAREN)) {
          // method call
          ASTNode* c=newNode(AST_CALL);
          c->sval="."+m.sval;
          c->addChild(n);
          next(); // '('
          parseArgList(c);
          expect(TOK_RPAREN,"Expected ')'");
          n=c;
        } else {
          ASTNode* mem=newNode(AST_MEMBER);
          mem->sval=m.sval;
          mem->addChild(n);
          n=mem;
        }
      } else if(check(TOK_LBRACKET)) {
        next();
        ASTNode* idx=newNode(AST_INDEX);
        idx->addChild(n);
        idx->addChild(parseExpr());
        expect(TOK_RBRACKET,"Expected ']'");
        n=idx;
      } else if(check(TOK_LPAREN)) {
        // bare function call on expr result
        ASTNode* c=newNode(AST_CALL);
        c->addChild(n);
        next(); // '('
        parseArgList(c);
        expect(TOK_RPAREN,"Expected ')'");
        n=c;
      } else break;
    }
    return n;
  }

  void parseArgList(ASTNode* callNode) {
    while(!check(TOK_RPAREN)&&!check(TOK_EOF)) {
      callNode->addChild(parseExpr());
      eat(TOK_COMMA);
    }
  }

  ASTNode* parsePrimary() {
    Token t = peek();
    if(t.kind==TOK_INT)    { next(); return litInt(t.ival); }
    if(t.kind==TOK_FLOAT)  { next(); return litFlt(t.fval); }
    if(t.kind==TOK_BOOL)   { next(); return litBool(t.bval); }
    if(t.kind==TOK_STRING) { next(); return litStr(t.sval); }
    if(t.kind==TOK_NIL)    { next(); return newNode(AST_NIL_LIT); }

    if(t.kind==TOK_LPAREN) {
      next();
      ASTNode* e=parseExpr();
      expect(TOK_RPAREN,"Expected ')'");
      return e;
    }

    if(t.kind==TOK_IDENT) {
      next();
      String name=t.sval;
      // type cast: int(...), float(...), bool(...), string(...)
      if((name=="int"||name=="float"||name=="bool"||name=="string")&&check(TOK_LPAREN)) {
        next();
        ASTNode* c=newNode(AST_CAST); c->sval=name;
        c->addChild(parseExpr());
        expect(TOK_RPAREN,"Expected ')'");
        return c;
      }
      // collection literal: vec{...}, map{...}, set{...}, stack{T}, queue{T}
      if((name=="vec"||name=="map"||name=="set"||name=="stack"||name=="queue")&&check(TOK_LBRACE)) {
        return parseCollectionLit(name);
      }
      // struct literal: Name{...}
      if(check(TOK_LBRACE)&&interp->findStruct(name)) {
        return parseStructLit(name);
      }
      // function call: name(...)
      if(check(TOK_LPAREN)) {
        ASTNode* c=newNode(AST_CALL); c->sval=name;
        next();
        parseArgList(c);
        expect(TOK_RPAREN,"Expected ')'");
        return c;
      }
      // dotted: module.func(...) or Enum.Tag
      if(check(TOK_DOT)) {
        next();
        Token m=next();
        if(check(TOK_LPAREN)) {
          ASTNode* c=newNode(AST_CALL); c->sval=name+"."+m.sval;
          next();
          parseArgList(c);
          expect(TOK_RPAREN,"Expected ')'");
          return c;
        }
        // enum value or module constant
        ASTNode* n=newNode(AST_MEMBER); n->sval=m.sval;
        ASTNode* base=newNode(AST_IDENT); base->sval=name;
        n->addChild(base);
        return n;
      }
      // plain identifier
      ASTNode* n=newNode(AST_IDENT); n->sval=name;
      return n;
    }

    // empty / unknown
    error("Unexpected token in expression: "+t.sval+"("+String((int)t.kind)+")");
    next();
    return newNode(AST_NIL_LIT);
  }

  ASTNode* parseCollectionLit(const String& ctype) {
    next(); // '{'
    ASTNode* n;
    if(ctype=="stack"||ctype=="queue") {
      // stack{Type} or queue{Type} — just a type instantiation, no elements
      n=newNode(AST_TYPE_INST); n->sval=ctype;
      if(check(TOK_IDENT)) {
        ASTNode* hint = newNode(AST_IDENT);
        hint->sval = next().sval; // type hint ignored at runtime
        n->addChild(hint);
      }
      expect(TOK_RBRACE,"Expected '}'");
      return n;
    }
    if(ctype=="vec"||ctype=="set") {
      n=newNode(ctype=="vec"?AST_VEC_LIT:AST_SET_LIT);
      while(!check(TOK_RBRACE)&&!check(TOK_EOF)) {
        n->addChild(parseExpr());
        eat(TOK_COMMA);
      }
    } else { // map
      n=newNode(AST_MAP_LIT);
      while(!check(TOK_RBRACE)&&!check(TOK_EOF)) {
        n->addChild(parseExpr()); // key
        expect(TOK_COLON,"Expected ':'");
        n->addChild(parseExpr()); // value
        eat(TOK_COMMA);
      }
    }
    expect(TOK_RBRACE,"Expected '}'");
    return n;
  }

  ASTNode* parseStructLit(const String& tname) {
    next(); // '{'
    ASTNode* n=newNode(AST_STRUCT_LIT); n->sval=tname;
    while(!check(TOK_RBRACE)&&!check(TOK_EOF)) {
      Token fn=next();
      expect(TOK_EQ,"Expected '='");
      ASTNode* field=newNode(AST_ASSIGN); field->sval=fn.sval;
      field->addChild(parseExpr());
      n->addChild(field);
      eat(TOK_COMMA);
    }
    expect(TOK_RBRACE,"Expected '}'");
    return n;
  }
};
