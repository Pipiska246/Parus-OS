#pragma once
// ============================================================
//  Turbine Interpreter for RP2040
//  Supports: variables, types, if/elif/else, while, for,
//  functions, enum, struct, switch, modules (display, gpio,
//  audio, file, serial), vec/map/set/stack/queue, format()
// ============================================================
#include <Arduino.h>
#include <LittleFS.h>
#include <math.h>

// ── forward declarations ────────────────────────────────────
struct TValue;
struct TFunc;
struct TEnumDef;
struct TStructDef;
struct TModule;
struct TInterp;

// ── value kinds ────────────────────────────────────────────
enum TKind {
  TK_NIL=0, TK_BOOL, TK_INT, TK_FLOAT, TK_STRING,
  TK_VEC, TK_MAP, TK_SET, TK_STACK, TK_QUEUE,
  TK_STRUCT_INST, TK_ENUM_VAL, TK_FUNC_REF,
  TK_MODULE_REF
};

// ── dynamic vector of TValue ────────────────────────────────
struct TVec {
  TValue* data = nullptr;
  int     size = 0;
  int     cap  = 0;
  void push(const TValue& v);
  TValue& at(int i);
  void clear();
  ~TVec();
};

// ── map entry ───────────────────────────────────────────────
struct TMapEntry {
  String  key;
  TValue* val = nullptr;
};
struct TMap {
  TMapEntry* entries = nullptr;
  int        size    = 0;
  int        cap     = 0;
  void  set(const String& k, const TValue& v);
  TValue* get(const String& k);
  void clear();
  ~TMap();
};

// ── struct instance ─────────────────────────────────────────
struct TStructInst {
  String     typeName;
  TMap       fields;
};

// ── enum value ──────────────────────────────────────────────
struct TEnumVal {
  String typeName;
  String tag;
  TMap   attrs;   // name -> TValue for each column
};

// ── the universal value ─────────────────────────────────────
struct TValue {
  TKind kind = TK_NIL;
  union {
    bool   b;
    long   i;
    double f;
  };
  String          s;
  TVec*           vec    = nullptr;
  TMap*           map    = nullptr;
  TStructInst*    sinst  = nullptr;
  TEnumVal*       eval   = nullptr;
  int             funcIdx = -1;   // index into interp func table
  String          modName;

  TValue()                     : kind(TK_NIL),  i(0)    {}
  explicit TValue(bool b_)     : kind(TK_BOOL), b(b_)   {}
  explicit TValue(long i_)     : kind(TK_INT),  i(i_)   {}
  explicit TValue(double f_)   : kind(TK_FLOAT),f(f_)   {}
  explicit TValue(const String& s_) : kind(TK_STRING), i(0), s(s_) {}

  String toString() const;
  bool   toBool()   const;
  long   toInt()    const;
  double toFloat()  const;
};

// ── AST node types ──────────────────────────────────────────
enum ASTKind {
  AST_NONE=0,
  AST_PROGRAM,
  AST_FUNC_DEF,
  AST_ENUM_DEF,
  AST_STRUCT_DEF,
  AST_IMPORT,
  AST_BLOCK,
  AST_VAR_DECL,
  AST_ASSIGN,
  AST_IF,
  AST_WHILE,
  AST_FOR_IN,
  AST_FOR_ENUM_IN,
  AST_SWITCH,
  AST_RETURN,
  AST_BREAK,
  AST_CONTINUE,
  AST_EXPR_STMT,
  // expressions
  AST_INT_LIT,
  AST_FLOAT_LIT,
  AST_BOOL_LIT,
  AST_STRING_LIT,
  AST_NIL_LIT,
  AST_IDENT,
  AST_BINARY,
  AST_UNARY,
  AST_CALL,
  AST_INDEX,
  AST_MEMBER,
  AST_VEC_LIT,
  AST_MAP_LIT,
  AST_SET_LIT,
  AST_STRUCT_LIT,
  AST_CAST,
  AST_TYPE_INST,   // stack{int}, queue{string} etc.
};

struct ASTNode {
  ASTKind kind = AST_NONE;
  // literals
  long    ival  = 0;
  double  fval  = 0;
  bool    bval  = false;
  String  sval;           // string lit / ident name / op / type name
  // children
  ASTNode** children = nullptr;
  int       nchildren = 0;

  ASTNode() {}
  ~ASTNode();
  void addChild(ASTNode* n);
  ASTNode* child(int i) const { return (i>=0&&i<nchildren)?children[i]:nullptr; }
};

// ── enum definition ─────────────────────────────────────────
struct TEnumCol {
  String name;
};
struct TEnumRow {
  String    tag;
  TValue*   vals = nullptr;
};
struct TEnumDef {
  String     name;
  TEnumCol*  cols    = nullptr;
  int        nCols   = 0;
  TEnumRow*  rows    = nullptr;
  int        nRows   = 0;
  ~TEnumDef();
};

// ── struct definition ───────────────────────────────────────
struct TStructField {
  String name;
  String typeName;
  TValue defVal;
};
struct TStructDef {
  String        name;
  TStructField* fields  = nullptr;
  int           nFields = 0;
  ~TStructDef();
};

// ── user-defined function ───────────────────────────────────
struct TParam { String name; String typeName; };
struct TFuncDef {
  String    name;
  TParam*   params  = nullptr;
  int       nParams = 0;
  String    retType;
  ASTNode*  body    = nullptr;   // AST_BLOCK
  bool      isOut[4] = {false};  // out-params (up to 4)
};

// ── scope (variable environment) ────────────────────────────
struct TScope {
  TScope*  parent = nullptr;
  String   names[32];
  TValue   vals[32];
  int      n = 0;

  TValue* lookup(const String& name);
  void    set(const String& name, const TValue& v);
  void    defVar(const String& name, const TValue& v);
};

// ── interpreter state ────────────────────────────────────────
#define TI_MAX_FUNCS   64
#define TI_MAX_ENUMS   32
#define TI_MAX_STRUCTS 32
#define TI_MAX_MODS    16

enum TSignal { SIG_NONE=0, SIG_RETURN, SIG_BREAK, SIG_CONTINUE, SIG_ERROR };

struct TInterp {
  TFuncDef    funcs[TI_MAX_FUNCS];
  int         nFuncs = 0;
  TEnumDef    enums[TI_MAX_ENUMS];
  int         nEnums = 0;
  TStructDef  structs[TI_MAX_STRUCTS];
  int         nStructs = 0;
  String      imports[TI_MAX_MODS];
  int         nImports = 0;

  TSignal     signal   = SIG_NONE;
  TValue      retVal;
  String      errMsg;
  bool        hasError = false;

  // защита от зависания: любой пользовательский while/for получает
  // ограниченный бюджет по времени (см. runSource()/runFile()).
  unsigned long deadlineMs = 0;
  bool timedOut() { return deadlineMs!=0 && millis() > deadlineMs; }

  // external callbacks for hardware access
  // set these from your .ino before calling run()
  void (*cbPrint)(const char* s)            = nullptr;
  void (*cbFillScreen)(uint8_t r,uint8_t g,uint8_t b) = nullptr;
  void (*cbSetCursor)(uint16_t x,uint16_t y)           = nullptr;
  void (*cbSetColor)(uint8_t r,uint8_t g,uint8_t b)    = nullptr;
  void (*cbPrintText)(const char* t)                    = nullptr;
  void (*cbFillRect)(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b) = nullptr;
  void (*cbDrawRect)(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b) = nullptr;
  void (*cbDrawLine)(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint8_t r,uint8_t g,uint8_t b) = nullptr;
  void (*cbDrawPixel)(uint16_t x,uint16_t y,uint8_t r,uint8_t g,uint8_t b) = nullptr;
  bool (*cbStartMusic)(const char* path)    = nullptr;
  void (*cbStopMusic)()                     = nullptr;
  void (*cbPauseMusic)()                    = nullptr;
  void (*cbResumeMusic)()                   = nullptr;
  void (*cbSetVolume)(uint8_t v)            = nullptr;
  int  (*cbReadPin)(int pin)                = nullptr;
  void (*cbWritePin)(int pin, int val)      = nullptr;
  void (*cbPinMode2)(int pin, int mode)     = nullptr;
  int  (*cbEncDelta)()                      = nullptr;   // read encoder delta
  bool (*cbBtnPressed)(int btnId)           = nullptr;   // 0=UP 1=DN 2=LF 3=RT 4=OK 5=HM 6=CAN 7=ENC
  void (*cbSerialPCPrint)(const char* s)    = nullptr;
  void (*cbSerialESPSend)(const uint8_t* d,int len) = nullptr;

  // run a .tu source from LittleFS
  bool runFile(const String& path);
  // run source string directly
  bool runSource(const char* src, int len=-1);

  // internal
  TValue evalNode(ASTNode* n, TScope* sc);
  TValue evalBlock(ASTNode* blk, TScope* sc);
  TValue callFunc(const String& name, TValue* argv, int argc, TScope* caller);
  TValue callBuiltin(const String& name, TValue* argv, int argc, TScope* sc);
  TValue callModFunc(const String& mod, const String& fn, TValue* argv, int argc);
  void   error(const String& msg);

  TEnumDef*   findEnum(const String& name);
  TStructDef* findStruct(const String& name);
  TFuncDef*   findFunc(const String& name);
};
