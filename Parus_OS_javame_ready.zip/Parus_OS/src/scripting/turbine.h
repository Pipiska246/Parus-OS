#pragma once
// ============================================================
//  turbine.h  —  single include для проекта
//  Подключи ТОЛЬКО этот файл в своём .ino
//  #include "turbine.h"
// ============================================================
#include "turbine_interp.h"
#include "turbine_lexer.h"
#include "turbine_parser.h"
#include "turbine_eval.h"
