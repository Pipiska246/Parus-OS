#pragma once
#include "turbine_interp.h"
#include "turbine_lexer.h"
#include "turbine_parser.h"
#include "../vfs/vfs.h"   // адресуем /sda и /sdb1.. как весь остальной проект, а не голый LittleFS

// Превращает имя файла из .tu-скрипта в полный VFS-путь:
//   "data.txt"        -> "/sda/data.txt"   (по умолчанию - внутренняя память)
//   "/sda/data.txt"    -> без изменений (уже полный VFS-путь)
//   "/sdb1/data.txt"   -> без изменений (USB-флешка)
static String tuResolvePath(const String& raw) {
  String p = raw;
  if (!p.startsWith("/")) p = "/" + p;
  if (p.startsWith("/sda") || p.startsWith("/sdb") || p.startsWith("/dev")) return p;
  return "/sda" + p;
}

// ============================================================
//  TValue helpers
// ============================================================
void TVec::push(const TValue& v) {
  if(size>=cap) {
    int nc=cap?cap*2:4;
    TValue* nd=new TValue[nc];
    for(int i=0;i<size;i++) nd[i]=data[i];
    delete[] data; data=nd; cap=nc;
  }
  data[size++]=v;
}
TValue& TVec::at(int i) { static TValue nil; if(i<0||i>=size)return nil; return data[i]; }
void TVec::clear() { delete[] data; data=nullptr; size=cap=0; }
TVec::~TVec() { clear(); }

void TMap::set(const String& k, const TValue& v) {
  for(int i=0;i<size;i++) if(entries[i].key==k){ *entries[i].val=v; return; }
  if(size>=cap) {
    int nc=cap?cap*2:4;
    TMapEntry* ne=new TMapEntry[nc];
    for(int i=0;i<size;i++) ne[i]=entries[i];
    delete[] entries; entries=ne; cap=nc;
  }
  entries[size].key=k;
  entries[size].val=new TValue(v);
  size++;
}
TValue* TMap::get(const String& k) {
  for(int i=0;i<size;i++) if(entries[i].key==k) return entries[i].val;
  return nullptr;
}
void TMap::clear() {
  for(int i=0;i<size;i++) delete entries[i].val;
  delete[] entries; entries=nullptr; size=cap=0;
}
TMap::~TMap() { clear(); }

// TValue converters
String TValue::toString() const {
  switch(kind) {
    case TK_NIL:    return "nil";
    case TK_BOOL:   return b?"true":"false";
    case TK_INT:    return String(i);
    case TK_FLOAT: {
      char buf[32]; dtostrf(f,1,6,buf);
      // strip trailing zeros
      String s=buf; int dot=s.indexOf('.');
      if(dot>=0){int e=s.length()-1;while(e>dot&&s[e]=='0')e--;if(s[e]=='.')e--;s=s.substring(0,e+1);}
      return s;
    }
    case TK_STRING: return s;
    case TK_VEC: {
      String r="{";
      if(vec) for(int i=0;i<vec->size;i++){if(i)r+=", ";r+=vec->at(i).toString();}
      return r+"}";
    }
    case TK_MAP: {
      String r="{";
      if(map){for(int i=0;i<map->size;i++){if(i)r+=", ";r+=map->entries[i].key+":"+map->entries[i].val->toString();}}
      return r+"}";
    }
    case TK_SET: return vec?vec->at(0).toString():"{}"; // simplified
    case TK_STACK: case TK_QUEUE: return "{}";
    case TK_STRUCT_INST: {
      if(!sinst) return "{}";
      String r="{";
      for(int i=0;i<sinst->fields.size;i++){
        if(i)r+=", ";
        r+=sinst->fields.entries[i].val->toString();
      }
      return r+"}";
    }
    case TK_ENUM_VAL:
      return eval?eval->tag:"nil";
    default: return "";
  }
}
bool   TValue::toBool()  const { if(kind==TK_BOOL)return b; if(kind==TK_INT)return i!=0; if(kind==TK_FLOAT)return f!=0; if(kind==TK_NIL)return false; return true; }
long   TValue::toInt()   const { if(kind==TK_INT)return i; if(kind==TK_FLOAT)return (long)f; if(kind==TK_BOOL)return b?1:0; if(kind==TK_STRING)return atol(s.c_str()); return 0; }
double TValue::toFloat() const { if(kind==TK_FLOAT)return f; if(kind==TK_INT)return (double)i; if(kind==TK_BOOL)return b?1.0:0.0; if(kind==TK_STRING)return atof(s.c_str()); return 0; }

// ── ASTNode destructor ──────────────────────────────────────
ASTNode::~ASTNode() {
  for(int i=0;i<nchildren;i++) delete children[i];
  delete[] children;
}
void ASTNode::addChild(ASTNode* n) {
  ASTNode** nc=new ASTNode*[nchildren+1];
  for(int i=0;i<nchildren;i++) nc[i]=children[i];
  nc[nchildren++]=n;
  delete[] children; children=nc;
}

// ── TEnumDef / TStructDef destructors ──────────────────────
TEnumDef::~TEnumDef() {
  for(int i=0;i<nRows;i++) delete[] rows[i].vals;
  delete[] rows; delete[] cols;
}
TStructDef::~TStructDef() { delete[] fields; }

// ── TScope ──────────────────────────────────────────────────
TValue* TScope::lookup(const String& name) {
  for(int i=0;i<n;i++) if(names[i]==name) return &vals[i];
  if(parent) return parent->lookup(name);
  return nullptr;
}
void TScope::defVar(const String& name, const TValue& v) {
  if(n<32){ names[n]=name; vals[n]=v; n++; }
}
void TScope::set(const String& name, const TValue& v) {
  for(int i=0;i<n;i++) if(names[i]==name){ vals[i]=v; return; }
  if(parent){ parent->set(name,v); return; }
  defVar(name,v); // define at top if not found
}

// ============================================================
//  TInterp helpers
// ============================================================
TEnumDef*   TInterp::findEnum(const String& name) {
  for(int i=0;i<nEnums;i++) if(enums[i].name==name) return &enums[i];
  return nullptr;
}
TStructDef* TInterp::findStruct(const String& name) {
  for(int i=0;i<nStructs;i++) if(structs[i].name==name) return &structs[i];
  return nullptr;
}
TFuncDef*   TInterp::findFunc(const String& name) {
  for(int i=0;i<nFuncs;i++) if(funcs[i].name==name) return &funcs[i];
  return nullptr;
}
void TInterp::error(const String& msg) {
  if(!hasError){ hasError=true; errMsg=msg; signal=SIG_ERROR; }
  if(cbSerialPCPrint){ cbSerialPCPrint("TU ERR: "); cbSerialPCPrint(msg.c_str()); cbSerialPCPrint("\n"); }
}

// ── format() helper (printf-like) ───────────────────────────
static String turbineFormat(const String& fmt, TValue* argv, int argc) {
  String out="";
  int ai=1; // argv[0] is the format string
  for(int i=0;i<(int)fmt.length();i++) {
    if(fmt[i]!='%'){ out+=fmt[i]; continue; }
    i++;
    if(i>=(int)fmt.length()) break;
    if(fmt[i]=='%'){ out+='%'; continue; }
    // flags
    bool leftAlign=false,forceSign=false,spaceSign=false,altForm=false,zeroPad=false;
    bool grouping=false, underscore=false;
    while(i<(int)fmt.length()) {
      char f=fmt[i];
      if(f=='-'){leftAlign=true;i++;}
      else if(f=='+'){forceSign=true;i++;}
      else if(f==' '){spaceSign=true;i++;}
      else if(f=='#'){altForm=true;i++;}
      else if(f=='0'){zeroPad=true;i++;}
      else if(f==','){grouping=true;i++;}
      else if(f=='_'){underscore=true;i++;}
      else break;
    }
    // width
    int width=0;
    while(i<(int)fmt.length()&&isdigit(fmt[i])) width=width*10+(fmt[i++]-'0');
    // precision
    int prec=-1;
    if(i<(int)fmt.length()&&fmt[i]=='.'){i++;prec=0;while(i<(int)fmt.length()&&isdigit(fmt[i]))prec=prec*10+(fmt[i++]-'0');}
    // specifier
    char spec=fmt[i];
    TValue av; if(ai<argc) av=argv[ai++];
    char buf[64]="";
    String part="";
    switch(spec) {
      case 'd': case 'i': {
        long v=av.toInt();
        snprintf(buf,sizeof(buf),"%ld",v);
        part=String(buf);
        if(forceSign&&v>=0) part="+"+part;
        else if(spaceSign&&v>=0) part=" "+part;
        break;}
      case 'f': {
        double v=av.toFloat();
        char fmt2[16]; snprintf(fmt2,sizeof(fmt2),"%%.%df",prec<0?6:prec);
        snprintf(buf,sizeof(buf),fmt2,v);
        part=String(buf);
        if(forceSign&&v>=0) part="+"+part;
        break;}
      case 'g': {
        double v=av.toFloat();
        char fmt2[16]; snprintf(fmt2,sizeof(fmt2),"%%.%dg",prec<0?6:prec);
        snprintf(buf,sizeof(buf),fmt2,v);
        part=String(buf);
        if(prec==0&&part.indexOf('.')<0) part+=".0";
        if(forceSign&&v>=0) part="+"+part;
        break;}
      case 'e': { double v=av.toFloat(); char f2[16]; snprintf(f2,sizeof(f2),"%%.%de",prec<0?6:prec); snprintf(buf,sizeof(buf),f2,v); part=String(buf); break;}
      case 'x': { snprintf(buf,sizeof(buf),"%lx",av.toInt()); part=String(buf); if(altForm)part="0x"+part; break;}
      case 'X': { snprintf(buf,sizeof(buf),"%lX",av.toInt()); part=String(buf); if(altForm)part="0X"+part; break;}
      case 'o': { snprintf(buf,sizeof(buf),"%lo",av.toInt()); part=String(buf); if(altForm)part="0"+part; break;}
      case 'c': { char cc=(char)av.toInt(); part=String(cc); break;}
      case 's': {
        part=av.toString();
        if(prec>=0&&(int)part.length()>prec) part=part.substring(0,prec);
        break;}
      case '%': part="%"; ai--; break;
      default:  part="?"; break;
    }
    // padding
    while((int)part.length()<width) {
      if(leftAlign) part+=' ';
      else if(zeroPad) part="0"+part;
      else part=" "+part;
    }
    out+=part;
  }
  return out;
}

// ── built-in container functions ────────────────────────────
static TValue builtinContainerFunc(const String& fn, TValue* argv, int argc) {
  TValue res;
  if(fn=="vecpush"||fn=="stackpush"||fn=="queuepush") {
    if(argc>=2&&argv[0].vec) { argv[0].vec->push(argv[1]); }
    return res;
  }
  if(fn=="vecpop"||fn=="stackpop") {
    if(argc>=1&&argv[0].vec&&argv[0].vec->size>0) {
      res=argv[0].vec->data[--argv[0].vec->size]; }
    return res;
  }
  if(fn=="stacktop") {
    if(argc>=1&&argv[0].vec&&argv[0].vec->size>0)
      res=argv[0].vec->data[argv[0].vec->size-1];
    return res;
  }
  if(fn=="queuepop"||fn=="dequeue") {
    if(argc>=1&&argv[0].vec&&argv[0].vec->size>0) {
      res=argv[0].vec->data[0];
      for(int i=0;i<argv[0].vec->size-1;i++) argv[0].vec->data[i]=argv[0].vec->data[i+1];
      argv[0].vec->size--;
    }
    return res;
  }
  if(fn=="len"||fn=="veclen") {
    if(argc>=1){
      if(argv[0].kind==TK_STRING) res=TValue((long)argv[0].s.length());
      else if(argv[0].vec)        res=TValue((long)argv[0].vec->size);
      else if(argv[0].map)        res=TValue((long)argv[0].map->size);
      else res=TValue(0L);
    }
    return res;
  }
  if(fn=="strlen") {
    if(argc>=1) res=TValue((long)(argv[0].kind==TK_STRING?argv[0].s.length():0));
    return res;
  }
  return res;
}

// ── evaluator ───────────────────────────────────────────────
TValue TInterp::evalBlock(ASTNode* blk, TScope* sc) {
  if(!blk) return TValue();
  TValue last;
  for(int i=0;i<blk->nchildren;i++) {
    if(signal!=SIG_NONE) break;
    last = evalNode(blk->children[i], sc);
  }
  return last;
}

TValue TInterp::evalNode(ASTNode* n, TScope* sc) {
  if(!n||hasError) return TValue();

  switch(n->kind) {
    // ── literals ─────────────────────────────────────────
    case AST_INT_LIT:    return TValue((long)n->ival);
    case AST_FLOAT_LIT:  return TValue(n->fval);
    case AST_BOOL_LIT:   return TValue(n->bval);
    case AST_STRING_LIT: return TValue(n->sval);
    case AST_NIL_LIT:    return TValue();

    // ── identifier ────────────────────────────────────────
    case AST_IDENT: {
      // check enum name (returns module-like reference)
      if(findEnum(n->sval)) { TValue v; v.kind=TK_MODULE_REF; v.modName=n->sval; return v; }
      TValue* vp = sc->lookup(n->sval);
      if(!vp) { error("Undefined variable: "+n->sval); return TValue(); }
      return *vp;
    }

    // ── member access ─────────────────────────────────────
    case AST_MEMBER: {
      TValue obj = evalNode(n->child(0), sc);
      String field = n->sval;
      // enum value attributes
      if(obj.kind==TK_ENUM_VAL && obj.eval) {
        if(field=="tag"||field=="symbol") return TValue(obj.eval->tag);
        TValue* fv = obj.eval->attrs.get(field);
        if(fv) return *fv;
        return TValue();
      }
      // enum type.Tag
      if(obj.kind==TK_MODULE_REF) {
        TEnumDef* ed = findEnum(obj.modName);
        if(ed) {
          for(int i=0;i<ed->nRows;i++) {
            if(ed->rows[i].tag==field) {
              TValue v; v.kind=TK_ENUM_VAL;
              v.eval=new TEnumVal();
              v.eval->typeName=ed->name;
              v.eval->tag=field;
              for(int c=0;c<ed->nCols;c++)
                v.eval->attrs.set(ed->cols[c].name, ed->rows[i].vals[c]);
              return v;
            }
          }
          error("Unknown enum tag: "+field);
          return TValue();
        }
        // module constant access like math._PI_
        return callModFunc(obj.modName,"_"+field, nullptr,0);
      }
      // struct instance field
      if(obj.kind==TK_STRUCT_INST && obj.sinst) {
        TValue* fv=obj.sinst->fields.get(field);
        if(fv) return *fv;
        return TValue();
      }
      // _test_count_ etc
      if(obj.kind==TK_MODULE_REF) return TValue(0L);
      return TValue();
    }

    // ── index ─────────────────────────────────────────────
    case AST_INDEX: {
      TValue obj = evalNode(n->child(0),sc);
      TValue idx = evalNode(n->child(1),sc);
      if(obj.kind==TK_STRING) {
        int i=(int)idx.toInt();
        if(i>=0&&i<(int)obj.s.length()) return TValue(String(obj.s[i]));
        return TValue();
      }
      if(obj.vec) {
        int i=(int)idx.toInt();
        if(i>=0&&i<obj.vec->size) return obj.vec->at(i);
        return TValue();
      }
      if(obj.map) {
        TValue* v=obj.map->get(idx.toString());
        if(v) return *v;
        return TValue();
      }
      return TValue();
    }

    // ── binary ops ────────────────────────────────────────
    case AST_BINARY: {
      if(n->sval=="and"){ TValue l=evalNode(n->child(0),sc); if(!l.toBool())return TValue(false); return evalNode(n->child(1),sc); }
      if(n->sval=="or") { TValue l=evalNode(n->child(0),sc); if(l.toBool())return l; return evalNode(n->child(1),sc); }
      TValue l=evalNode(n->child(0),sc);
      TValue r=evalNode(n->child(1),sc);
      const String& op=n->sval;
      // string ops
      if(l.kind==TK_STRING||r.kind==TK_STRING) {
        if(op=="+") return TValue(l.toString()+r.toString());
        if(op=="==") return TValue(l.toString()==r.toString());
        if(op=="!=") return TValue(l.toString()!=r.toString());
        if(op=="<")  return TValue(l.toString()<r.toString());
        if(op=="<=") return TValue(l.toString()<=r.toString());
        if(op==">")  return TValue(l.toString()>r.toString());
        if(op==">=") return TValue(l.toString()>=r.toString());
      }
      // bool
      if(l.kind==TK_BOOL&&r.kind==TK_BOOL) {
        if(op=="==") return TValue(l.b==r.b);
        if(op=="!=") return TValue(l.b!=r.b);
      }
      // numeric
      bool useFloat=(l.kind==TK_FLOAT||r.kind==TK_FLOAT);
      if(useFloat) {
        double a=l.toFloat(), b=r.toFloat();
        if(op=="+")  return TValue(a+b);
        if(op=="-")  return TValue(a-b);
        if(op=="*")  return TValue(a*b);
        if(op=="/")  return b==0?TValue():TValue(a/b);
        if(op=="%")  return TValue(fmod(a,b));
        if(op=="^")  return TValue(pow(a,b));
        if(op=="==") return TValue(a==b);
        if(op=="!=") return TValue(a!=b);
        if(op=="<")  return TValue(a<b);
        if(op=="<=") return TValue(a<=b);
        if(op==">")  return TValue(a>b);
        if(op==">=") return TValue(a>=b);
      } else {
        long a=l.toInt(), b=r.toInt();
        if(op=="+")  return TValue(a+b);
        if(op=="-")  return TValue(a-b);
        if(op=="*")  return TValue(a*b);
        if(op=="/")  return b==0?TValue():TValue(a/b);
        if(op=="%")  return TValue(a%b);
        if(op=="^")  return TValue((long)pow(a,b));
        if(op=="==") return TValue(a==b);
        if(op=="!=") return TValue(a!=b);
        if(op=="<")  return TValue(a<b);
        if(op=="<=") return TValue(a<=b);
        if(op==">")  return TValue(a>b);
        if(op==">=") return TValue(a>=b);
      }
      error("Unknown op: "+op); return TValue();
    }

    // ── unary ─────────────────────────────────────────────
    case AST_UNARY: {
      TValue v=evalNode(n->child(0),sc);
      if(n->sval=="-") { if(v.kind==TK_FLOAT) return TValue(-v.f); return TValue(-v.toInt()); }
      if(n->sval=="not") return TValue(!v.toBool());
      return v;
    }

    // ── cast ──────────────────────────────────────────────
    case AST_CAST: {
      TValue v=evalNode(n->child(0),sc);
      if(n->sval=="int")   return TValue(v.toInt());
      if(n->sval=="float") return TValue(v.toFloat());
      if(n->sval=="bool")  return TValue(v.toBool());
      if(n->sval=="string")return TValue(v.toString());
      return v;
    }

    // ── collection literals ───────────────────────────────
    case AST_VEC_LIT: case AST_SET_LIT: {
      TValue v; v.kind=(n->kind==AST_VEC_LIT?TK_VEC:TK_SET);
      v.vec=new TVec();
      for(int i=0;i<n->nchildren;i++) v.vec->push(evalNode(n->children[i],sc));
      return v;
    }
    case AST_MAP_LIT: {
      TValue v; v.kind=TK_MAP; v.map=new TMap();
      for(int i=0;i+1<n->nchildren;i+=2) {
        TValue k=evalNode(n->children[i],sc);
        TValue val=evalNode(n->children[i+1],sc);
        v.map->set(k.toString(),val);
      }
      return v;
    }
    case AST_TYPE_INST: {
      // stack{T} / queue{T}
      TValue v; v.kind=(n->sval=="queue"?TK_QUEUE:TK_STACK);
      v.vec=new TVec();
      return v;
    }

    // ── struct literal ────────────────────────────────────
    case AST_STRUCT_LIT: {
      TValue v; v.kind=TK_STRUCT_INST;
      v.sinst=new TStructInst(); v.sinst->typeName=n->sval;
      TStructDef* sd=findStruct(n->sval);
      if(sd) { for(int i=0;i<sd->nFields;i++) v.sinst->fields.set(sd->fields[i].name,sd->fields[i].defVal); }
      for(int i=0;i<n->nchildren;i++) {
        ASTNode* f=n->children[i]; // AST_ASSIGN node, sval=fieldname
        TValue fv=evalNode(f->child(0),sc);
        v.sinst->fields.set(f->sval,fv);
      }
      return v;
    }

    // ── function call ─────────────────────────────────────
    case AST_CALL: {
      // gather args
      TValue argv[16]; int argc=0;
      int firstArg=0;
      // if first child is object (method call), eval it
      bool isMethod=(n->sval.length()>0&&n->sval[0]=='.');
      if(isMethod) { argv[argc++]=evalNode(n->child(0),sc); firstArg=1; }
      for(int i=firstArg;i<n->nchildren&&argc<16;i++)
        argv[argc++]=evalNode(n->children[i],sc);
      return callFunc(isMethod?n->sval.substring(1):n->sval, argv, argc, sc);
    }

    // ── variable declaration ───────────────────────────────
    case AST_VAR_DECL: {
      String name=n->sval;
      String typeName="";
      int pipe=name.indexOf('|');
      if(pipe>=0){ typeName=name.substring(pipe+1); name=name.substring(0,pipe); }
      TValue v;
      if(n->nchildren>0) v=evalNode(n->child(0),sc);
      else {
        // typed default
        if(typeName=="int")   v=TValue(0L);
        else if(typeName=="float") v=TValue(0.0);
        else if(typeName=="bool")  v=TValue(false);
        else if(typeName=="string")v=TValue(String(""));
        else if(typeName.startsWith("vec")||typeName.startsWith("set"))
          { v.kind=TK_VEC;v.vec=new TVec(); }
        else if(typeName.startsWith("map"))
          { v.kind=TK_MAP;v.map=new TMap(); }
        else if(typeName.startsWith("stack"))
          { v.kind=TK_STACK;v.vec=new TVec(); }
        else if(typeName.startsWith("queue"))
          { v.kind=TK_QUEUE;v.vec=new TVec(); }
      }
      sc->defVar(name,v);
      return v;
    }

    // ── assignment ────────────────────────────────────────
    case AST_ASSIGN: {
      TValue rhs=evalNode(n->child(1),sc);
      ASTNode* lhsNode=n->child(0);
      const String& op=n->sval;

      // helper to apply compound op
      auto applyOp=[&](TValue old)->TValue{
        if(op=="=") return rhs;
        double a=old.toFloat(),b=rhs.toFloat();
        bool fi=(old.kind==TK_FLOAT||rhs.kind==TK_FLOAT);
        if(op=="+="){return fi?TValue(a+b):TValue(old.toInt()+rhs.toInt());}
        if(op=="-="){return fi?TValue(a-b):TValue(old.toInt()-rhs.toInt());}
        if(op=="*="){return fi?TValue(a*b):TValue(old.toInt()*rhs.toInt());}
        if(op=="/="){return fi?TValue(a/b):TValue(old.toInt()/rhs.toInt());}
        return rhs;
      };

      if(lhsNode->kind==AST_IDENT) {
        TValue* vp=sc->lookup(lhsNode->sval);
        if(!vp){ error("Undefined var: "+lhsNode->sval); return TValue(); }
        *vp=applyOp(*vp);
        if(op=="+=") { // string concat
          if((*vp).kind==TK_STRING||rhs.kind==TK_STRING){
            TValue* vp2=sc->lookup(lhsNode->sval);
            *vp2=TValue(vp2->toString()+rhs.toString());
          }
        }
        return *vp;
      }
      if(lhsNode->kind==AST_INDEX) {
        TValue obj=evalNode(lhsNode->child(0),sc);
        TValue idx=evalNode(lhsNode->child(1),sc);
        if(obj.vec){ int i=(int)idx.toInt(); if(i>=0&&i<obj.vec->size) obj.vec->data[i]=applyOp(obj.vec->data[i]); }
        if(obj.map){ TValue* v=obj.map->get(idx.toString()); if(v)*v=applyOp(*v); else obj.map->set(idx.toString(),rhs); }
        return rhs;
      }
      if(lhsNode->kind==AST_MEMBER) {
        TValue obj=evalNode(lhsNode->child(0),sc);
        if(obj.sinst) obj.sinst->fields.set(lhsNode->sval, applyOp(TValue()));
        return rhs;
      }
      return rhs;
    }

    // ── if ────────────────────────────────────────────────
    case AST_IF: {
      // children: cond, block [, cond, block ...]
      for(int i=0;i+1<n->nchildren;i+=2) {
        bool cond;
        if(n->children[i]->kind==AST_NIL_LIT) cond=true;
        else cond=evalNode(n->children[i],sc).toBool();
        if(cond) {
          TScope inner; inner.parent=sc;
          return evalBlock(n->children[i+1],&inner);
        }
      }
      return TValue();
    }

    // ── while ─────────────────────────────────────────────
    case AST_WHILE: {
      while(!hasError) {
        if(timedOut()){ error("Timeout: возможен бесконечный while"); break; }
        TValue cond=evalNode(n->child(0),sc);
        if(!cond.toBool()) break;
        TScope inner; inner.parent=sc;
        evalBlock(n->child(1),&inner);
        if(signal==SIG_BREAK){signal=SIG_NONE;break;}
        if(signal==SIG_CONTINUE){signal=SIG_NONE;continue;}
        if(signal==SIG_RETURN||signal==SIG_ERROR) break;
      }
      return TValue();
    }

    // ── for in ────────────────────────────────────────────
    case AST_FOR_IN: {
      // n->sval = "varname" or "idxname,valname"
      String varA=n->sval, varB="";
      int comma=varA.indexOf(',');
      if(comma>=0){ varB=varA.substring(comma+1); varA=varA.substring(0,comma); }
      TValue iterable=evalNode(n->child(0),sc);
      int count=0;
      if(iterable.kind==TK_STRING) {
        for(int i=0;i<(int)iterable.s.length()&&!hasError;i++) {
          TScope inner; inner.parent=sc;
          if(varB.length()){ inner.defVar(varA,TValue((long)i)); inner.defVar(varB,TValue(String(iterable.s[i]))); }
          else              inner.defVar(varA,TValue(String(iterable.s[i])));
          evalBlock(n->child(1),&inner);
          if(signal==SIG_BREAK){signal=SIG_NONE;break;}
          if(signal==SIG_CONTINUE){signal=SIG_NONE;continue;}
          if(signal==SIG_RETURN||signal==SIG_ERROR)break;
        }
      } else if(iterable.vec) {
        for(int i=0;i<iterable.vec->size&&!hasError;i++) {
          TScope inner; inner.parent=sc;
          if(varB.length()){ inner.defVar(varA,TValue((long)i)); inner.defVar(varB,iterable.vec->at(i)); }
          else              inner.defVar(varA,iterable.vec->at(i));
          evalBlock(n->child(1),&inner);
          if(signal==SIG_BREAK){signal=SIG_NONE;break;}
          if(signal==SIG_CONTINUE){signal=SIG_NONE;continue;}
          if(signal==SIG_RETURN||signal==SIG_ERROR)break;
        }
      } else if(iterable.map) {
        for(int i=0;i<iterable.map->size&&!hasError;i++) {
          TScope inner; inner.parent=sc;
          if(varB.length()){ inner.defVar(varA,TValue(iterable.map->entries[i].key)); inner.defVar(varB,*iterable.map->entries[i].val); }
          else              inner.defVar(varA,TValue(iterable.map->entries[i].key));
          evalBlock(n->child(1),&inner);
          if(signal==SIG_BREAK){signal=SIG_NONE;break;}
          if(signal==SIG_CONTINUE){signal=SIG_NONE;continue;}
          if(signal==SIG_RETURN||signal==SIG_ERROR)break;
        }
      }
      return TValue();
    }

    // ── switch ────────────────────────────────────────────
    case AST_SWITCH: {
      TValue sv=evalNode(n->child(0),sc);
      String svStr=sv.toString();
      if(sv.kind==TK_ENUM_VAL&&sv.eval) svStr=sv.eval->tag;
      // children[1..] : labelIdent, block, labelIdent, block ...
      for(int i=1;i+1<n->nchildren;i+=2) {
        String lbl=n->children[i]->sval;
        // lbl may be "Shape.Line" or just "Line"
        int dot=lbl.indexOf('.');
        if(dot>=0) lbl=lbl.substring(dot+1);
        if(lbl==svStr) {
          TScope inner; inner.parent=sc;
          evalBlock(n->children[i+1],&inner);
          if(signal==SIG_BREAK) signal=SIG_NONE;
          return TValue();
        }
      }
      return TValue();
    }

    // ── return ────────────────────────────────────────────
    case AST_RETURN: {
      if(n->nchildren>0) retVal=evalNode(n->child(0),sc);
      else retVal=TValue();
      signal=SIG_RETURN;
      return retVal;
    }
    case AST_BREAK:    signal=SIG_BREAK;    return TValue();
    case AST_CONTINUE: signal=SIG_CONTINUE; return TValue();

    // ── expr stmt ─────────────────────────────────────────
    case AST_EXPR_STMT:
      return evalNode(n->child(0),sc);

    case AST_BLOCK:
      return evalBlock(n,sc);

    // ── program ───────────────────────────────────────────
    case AST_PROGRAM:
      return evalBlock(n,sc);

    // ignored at eval time
    case AST_FUNC_DEF:
    case AST_ENUM_DEF:
    case AST_STRUCT_DEF:
    case AST_IMPORT:
      return TValue();

    default:
      return TValue();
  }
}

// ── function call dispatch ───────────────────────────────────
TValue TInterp::callFunc(const String& name, TValue* argv, int argc, TScope* caller) {
  // dotted: module.func
  int dot=name.indexOf('.');
  if(dot>=0) {
    return callModFunc(name.substring(0,dot), name.substring(dot+1), argv, argc);
  }

  // user-defined
  TFuncDef* fd=findFunc(name);
  if(fd) {
    TScope sc; sc.parent=nullptr; // fresh scope (no closure)
    for(int i=0;i<fd->nParams&&i<argc;i++)
      sc.defVar(fd->params[i].name, argv[i]);
    signal=SIG_NONE;
    evalBlock(fd->body, &sc);
    TValue r=retVal; retVal=TValue();
    if(signal==SIG_RETURN||signal==SIG_ERROR) signal=SIG_NONE;
    return r;
  }

  return callBuiltin(name, argv, argc, caller);
}

// ── built-in functions ──────────────────────────────────────
TValue TInterp::callBuiltin(const String& name, TValue* argv, int argc, TScope* sc) {
  TValue res;

  // ── vars: показывает текущие переменные (имя=значение) во всех
  //   видимых областях видимости (от текущей вверх по parent-цепочке).
  //   Даёт скрипту/системе возможность интроспекции переменных языка,
  //   как и одноимённая команда "vars" в bash. ─────────────────────
  if(name=="vars") {
    String out="";
    TScope* s=sc; int depth=0;
    while(s && depth<8) {
      for(int i=0;i<s->n;i++) out += s->names[i] + "=" + s->vals[i].toString() + "\n";
      s = s->parent;
      depth++;
    }
    if(out.length()==0) out="(no variables)\n";
    if(cbPrint) cbPrint(out.c_str());
    if(cbSerialPCPrint) cbSerialPCPrint(out.c_str());
    return res;
  }

  // ── print ────────────────────────────────────────────────
  if(name=="print") {
    String out="";
    for(int i=0;i<argc;i++){ if(i)out+=" "; out+=argv[i].toString(); }
    out+="\n";
    if(cbPrint) cbPrint(out.c_str());
    if(cbSerialPCPrint) cbSerialPCPrint(out.c_str());
    return res;
  }

  // ── format ───────────────────────────────────────────────
  if(name=="format") {
    if(argc<1) return TValue(String(""));
    return TValue(turbineFormat(argv[0].toString(), argv, argc));
  }

  // ── math ──────────────────────────────────────────────────
  if(name=="abs")    { return argc>=1?TValue(fabs(argv[0].toFloat())):res; }
  if(name=="sqrt")   { return argc>=1?TValue(sqrt(argv[0].toFloat())):res; }
  if(name=="pow")    { return argc>=2?TValue(pow(argv[0].toFloat(),argv[1].toFloat())):res; }
  if(name=="sin")    { return argc>=1?TValue(sin(argv[0].toFloat())):res; }
  if(name=="cos")    { return argc>=1?TValue(cos(argv[0].toFloat())):res; }
  if(name=="tan")    { return argc>=1?TValue(tan(argv[0].toFloat())):res; }
  if(name=="floor")  { return argc>=1?TValue((long)floor(argv[0].toFloat())):res; }
  if(name=="ceil")   { return argc>=1?TValue((long)ceil(argv[0].toFloat())):res; }
  if(name=="round")  { return argc>=1?TValue((long)round(argv[0].toFloat())):res; }
  if(name=="min")    { return argc>=2?((argv[0].toFloat()<argv[1].toFloat())?argv[0]:argv[1]):res; }
  if(name=="max")    { return argc>=2?((argv[0].toFloat()>argv[1].toFloat())?argv[0]:argv[1]):res; }

  // ── type / container ──────────────────────────────────────
  if(name=="len"||name=="veclen"||name=="strlen"||
     name=="vecpush"||name=="stackpush"||name=="queuepush"||
     name=="vecpop"||name=="stackpop"||name=="queuepop"||name=="dequeue"||
     name=="stacktop") {
    return builtinContainerFunc(name,argv,argc);
  }

  // ── display API ───────────────────────────────────────────
  if(name=="fillScreen"||name=="display.fillScreen") {
    if(cbFillScreen&&argc>=3) cbFillScreen((uint8_t)argv[0].toInt(),(uint8_t)argv[1].toInt(),(uint8_t)argv[2].toInt());
    return res;
  }
  if(name=="setCursor"||name=="display.setCursor") {
    if(cbSetCursor&&argc>=2) cbSetCursor((uint16_t)argv[0].toInt(),(uint16_t)argv[1].toInt());
    return res;
  }
  if(name=="setTextColor"||name=="display.setTextColor") {
    if(cbSetColor&&argc>=3) cbSetColor((uint8_t)argv[0].toInt(),(uint8_t)argv[1].toInt(),(uint8_t)argv[2].toInt());
    return res;
  }
  if(name=="printText"||name=="display.print") {
    if(cbPrintText&&argc>=1) cbPrintText(argv[0].toString().c_str());
    return res;
  }
  if(name=="fillRect"||name=="display.fillRect") {
    if(cbFillRect&&argc>=7) cbFillRect((uint16_t)argv[0].toInt(),(uint16_t)argv[1].toInt(),(uint16_t)argv[2].toInt(),(uint16_t)argv[3].toInt(),(uint8_t)argv[4].toInt(),(uint8_t)argv[5].toInt(),(uint8_t)argv[6].toInt());
    return res;
  }
  if(name=="drawRect"||name=="display.drawRect") {
    if(cbDrawRect&&argc>=7) cbDrawRect((uint16_t)argv[0].toInt(),(uint16_t)argv[1].toInt(),(uint16_t)argv[2].toInt(),(uint16_t)argv[3].toInt(),(uint8_t)argv[4].toInt(),(uint8_t)argv[5].toInt(),(uint8_t)argv[6].toInt());
    return res;
  }
  if(name=="drawLine"||name=="display.drawLine") {
    if(cbDrawLine&&argc>=7) cbDrawLine((uint16_t)argv[0].toInt(),(uint16_t)argv[1].toInt(),(uint16_t)argv[2].toInt(),(uint16_t)argv[3].toInt(),(uint8_t)argv[4].toInt(),(uint8_t)argv[5].toInt(),(uint8_t)argv[6].toInt());
    return res;
  }
  if(name=="drawPixel"||name=="display.drawPixel") {
    if(cbDrawPixel&&argc>=5) cbDrawPixel((uint16_t)argv[0].toInt(),(uint16_t)argv[1].toInt(),(uint8_t)argv[2].toInt(),(uint8_t)argv[3].toInt(),(uint8_t)argv[4].toInt());
    return res;
  }

  // ── audio ─────────────────────────────────────────────────
  if(name=="audio.play"||name=="playMusic") {
    if(cbStartMusic&&argc>=1) return TValue(cbStartMusic(argv[0].toString().c_str()));
    return res;
  }
  if(name=="audio.stop"||name=="stopMusic")   { if(cbStopMusic)  cbStopMusic();  return res; }
  if(name=="audio.pause"||name=="pauseMusic") { if(cbPauseMusic) cbPauseMusic(); return res; }
  if(name=="audio.resume")                    { if(cbResumeMusic)cbResumeMusic();return res; }
  if(name=="audio.setVolume")                 { if(cbSetVolume&&argc>=1)cbSetVolume((uint8_t)argv[0].toInt()); return res; }

  // ── GPIO ──────────────────────────────────────────────────
  if(name=="gpio.read"||name=="digitalRead") {
    if(cbReadPin&&argc>=1) return TValue((long)cbReadPin((int)argv[0].toInt()));
    return TValue(0L);
  }
  if(name=="gpio.write"||name=="digitalWrite") {
    if(cbWritePin&&argc>=2) cbWritePin((int)argv[0].toInt(),(int)argv[1].toInt());
    return res;
  }
  if(name=="gpio.mode"||name=="pinMode2") {
    if(cbPinMode2&&argc>=2) cbPinMode2((int)argv[0].toInt(),(int)argv[1].toInt());
    return res;
  }

  // ── encoder/buttons ──────────────────────────────────────
  if(name=="enc.delta"||name=="encoderDelta") {
    if(cbEncDelta) return TValue((long)cbEncDelta());
    return TValue(0L);
  }
  if(name=="btn.pressed") {
    if(cbBtnPressed&&argc>=1) return TValue(cbBtnPressed((int)argv[0].toInt()));
    return TValue(false);
  }

  // ── file I/O ──────────────────────────────────────────────
  if(name=="file.read") {
    if(argc<1) return TValue(String(""));
    String path=tuResolvePath(argv[0].toString());
    VfsFile f;
    if(!f.openRead(path)) return TValue(String(""));
    String content="";
    uint8_t b;
    while(f.read(&b,1)==1) content+=(char)b;
    f.close();
    return TValue(content);
  }
  if(name=="file.write") {
    if(argc<2) return TValue(false);
    String path=tuResolvePath(argv[0].toString());
    VfsFile f;
    if(!f.openWrite(path,false)) return TValue(false);
    String s=argv[1].toString();
    f.write((const uint8_t*)s.c_str(),s.length());
    f.close();
    return TValue(true);
  }
  if(name=="file.append") {
    if(argc<2) return TValue(false);
    String path=tuResolvePath(argv[0].toString());
    VfsFile f;
    if(!f.openWrite(path,true)) return TValue(false);
    String s=argv[1].toString();
    f.write((const uint8_t*)s.c_str(),s.length());
    f.close();
    return TValue(true);
  }
  if(name=="file.exists") {
    if(argc<1) return TValue(false);
    return TValue(vfsExists(tuResolvePath(argv[0].toString())));
  }
  if(name=="file.delete") {
    if(argc<1) return TValue(false);
    return TValue(vfsRemove(tuResolvePath(argv[0].toString())));
  }

  // ── serial ────────────────────────────────────────────────
  if(name=="serial.print"||name=="serialPC.print") {
    if(cbSerialPCPrint&&argc>=1) cbSerialPCPrint(argv[0].toString().c_str());
    return res;
  }
  if(name=="serial.println"||name=="serialPC.println") {
    if(cbSerialPCPrint&&argc>=1){ cbSerialPCPrint(argv[0].toString().c_str()); cbSerialPCPrint("\n"); }
    return res;
  }

  // ── misc ──────────────────────────────────────────────────
  if(name=="delay") { if(argc>=1) ::delay((unsigned long)argv[0].toInt()); return res; }
  if(name=="millis") { return TValue((long)::millis()); }
  if(name=="micros") { return TValue((long)::micros()); }

  error("Unknown function: "+name);
  return res;
}

// ── module function dispatch ─────────────────────────────────
TValue TInterp::callModFunc(const String& mod, const String& fn, TValue* argv, int argc) {
  // math module
  if(mod=="math") {
    if(fn=="_PI_")  return TValue(M_PI);
    if(fn=="_E_")   return TValue(M_E);
    if(fn=="sqrt")  return argc>=1?TValue(sqrt(argv[0].toFloat())):TValue();
    if(fn=="pow")   return argc>=2?TValue(pow(argv[0].toFloat(),argv[1].toFloat())):TValue();
    if(fn=="abs")   return argc>=1?TValue(fabs(argv[0].toFloat())):TValue();
    if(fn=="sin")   return argc>=1?TValue(sin(argv[0].toFloat())):TValue();
    if(fn=="cos")   return argc>=1?TValue(cos(argv[0].toFloat())):TValue();
    if(fn=="tan")   return argc>=1?TValue(tan(argv[0].toFloat())):TValue();
    if(fn=="floor") return argc>=1?TValue((long)floor(argv[0].toFloat())):TValue();
    if(fn=="ceil")  return argc>=1?TValue((long)ceil(argv[0].toFloat())):TValue();
    if(fn=="round") return argc>=1?TValue((long)round(argv[0].toFloat())):TValue();
    if(fn=="log")   return argc>=1?TValue(log(argv[0].toFloat())):TValue();
    if(fn=="log10") return argc>=1?TValue(log10(argv[0].toFloat())):TValue();
  }
  // display module
  if(mod=="display") {
    TValue fakeArgv[8]; int ai=0;
    for(int i=0;i<argc&&i<8;i++) fakeArgv[ai++]=argv[i];
    return callBuiltin("display."+fn,fakeArgv,argc,nullptr);
  }
  // audio module
  if(mod=="audio") return callBuiltin("audio."+fn,argv,argc,nullptr);
  // gpio module
  if(mod=="gpio")  return callBuiltin("gpio."+fn,argv,argc,nullptr);
  // serial
  if(mod=="serial"||mod=="serialPC") return callBuiltin("serial."+fn,argv,argc,nullptr);
  // file
  if(mod=="file")  return callBuiltin("file."+fn,argv,argc,nullptr);
  // time module
  if(mod=="time") {
    if(fn=="now")  return TValue((long)millis());
    if(fn=="elapsed"&&argc>=1) return TValue((double)(millis()-argv[0].toInt())/1000.0);
  }
  // test module (for format tests)
  if(mod=="test") {
    if(fn=="AssertS"&&argc>=2) {
      bool ok=(argv[0].toString()==argv[1].toString());
      if(!ok){ error("AssertS FAIL: expected '"+argv[0].toString()+"' got '"+argv[1].toString()+"'"); }
      return TValue(ok);
    }
    if(fn=="AssertI"&&argc>=2) {
      bool ok=(argv[0].toInt()==argv[1].toInt());
      if(!ok){ error("AssertI FAIL: expected "+String(argv[0].toInt())+" got "+String(argv[1].toInt())); }
      return TValue(ok);
    }
    if(fn=="AssertB"&&argc>=2) {
      bool ok=(argv[0].toBool()==argv[1].toBool());
      if(!ok) error("AssertB FAIL");
      return TValue(ok);
    }
    if(fn=="_test_count_") return TValue(0L);
  }
  return TValue();
}

// ── run source ───────────────────────────────────────────────
bool TInterp::runSource(const char* src, int srcLen) {
  hasError=false; errMsg=""; signal=SIG_NONE; retVal=TValue();
  nFuncs=0; nEnums=0; nStructs=0; nImports=0;
  deadlineMs = millis() + 60000; // защита от зависания: 60 секунд на скрипт (поправь константу, если нужно дольше)

  Lexer lx; lx.init(src, srcLen<0?(int)strlen(src):srcLen);
  Parser p; p.init(&lx,this);
  p.parseAll();
  if(p.hasError||hasError) return false;

  TFuncDef* main=findFunc("main");
  if(!main){ error("No main() function"); return false; }

  TValue args; args.kind=TK_VEC; args.vec=new TVec(); // empty args
  TValue argv[1]={args};
  callFunc("main",argv,1,nullptr);
  return !hasError;
}

bool TInterp::runFile(const String& path) {
  String fullPath=tuResolvePath(path);
  if(!vfsExists(fullPath)){ error("File not found: "+fullPath); return false; }
  VfsFile f;
  if(!f.openRead(fullPath)){ error("Cannot open: "+fullPath); return false; }
  String src="";
  uint8_t b;
  while(f.read(&b,1)==1) src+=(char)b;
  f.close();
  return runSource(src.c_str(),(int)src.length());
}
