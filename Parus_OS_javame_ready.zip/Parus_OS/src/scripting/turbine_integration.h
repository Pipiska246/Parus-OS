// ============================================================
//  turbine_integration.h
//  Вставь этот файл рядом с .ino и сделай:
//    #include "turbine_integration.h"
//  СРАЗУ ПОСЛЕ updateButtons() в .ино (см. инструкцию в самом низу
//  файла) - НЕ в самом начале, иначе будет "not declared in this scope".
// ============================================================
#pragma once
#include "turbine.h"
#include "turbine_logger.h"

// ── глобальный интерпретатор ─────────────────────────────────
TInterp gTurbine;
TurbineLogger gTurbineLogger;
bool    tuRunning   = false;
String  tuFilePath  = "";
String  tuOutput    = "";   // накопленный вывод print()
int     tuOutScroll = 0;

// ── вывод на экран читалки ───────────────────────────────────
// накапливаем строки, рисуем поверх через drawTuOutput()
void drawTuOutput(); // forward decl - используется в tuPrintCallback ниже

#define TU_MAX_OUT_LINES 200
String tuOutLines[TU_MAX_OUT_LINES];
int    tuOutCount = 0;

static void tuAddOutputLine(const String& line) {
  if (tuOutCount < TU_MAX_OUT_LINES) {
    tuOutLines[tuOutCount++] = line;
  } else {
    // rolling buffer
    for (int i = 0; i < TU_MAX_OUT_LINES - 1; i++)
      tuOutLines[i] = tuOutLines[i+1];
    tuOutLines[TU_MAX_OUT_LINES-1] = line;
  }
}

// split by \n and add; живой вывод на экран (с троттлингом)
static void tuPrintCallback(const char* s) {
  if (SerialPC) SerialPC.print(s);   // зеркало в Serial, но НЕ блокируясь,
                                      // если порт не открыт (см. turbine_logger.h)
  String str(s);
  int start = 0;
  while (true) {
    int nl = str.indexOf('\n', start);
    if (nl < 0) {
      if (start < (int)str.length())
        tuAddOutputLine(str.substring(start));
      break;
    }
    tuAddOutputLine(str.substring(start, nl));
    start = nl + 1;
  }
  tuOutScroll = max(0, tuOutCount - MAX_VIEW_LINES);
  static unsigned long lastDraw = 0;
  unsigned long now = millis();
  if (now - lastDraw >= 150) { lastDraw = now; drawTuOutput(); }
}

// ── экран вывода .tu ─────────────────────────────────────────
void drawTuOutput() {
  sendFillScreen(0, 0, 0);
  // header
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 0, 60, 40);
  sendSetCursor(2, 2);
  sendSetTextColor(200, 255, 150);
  String hdr = "TU: " + tuFilePath.substring(tuFilePath.lastIndexOf('/') + 1);
  if ((int)hdr.length() > 24) hdr = hdr.substring(0, 22) + "..";
  sendPrintStr(hdr);

  // output lines
  int visLines = MAX_VIEW_LINES;
  int yStart   = HDR_H + 2;

  for (int i = 0; i < visLines; i++) {
    int idx = tuOutScroll + i;
    if (idx >= tuOutCount) break;
    sendSetCursor(0, yStart + i * LINE_H);
    sendSetTextColor(200, 255, 200);
    String ln = tuOutLines[idx];
    if ((int)ln.length() > CHARS_PER_LINE)
      ln = ln.substring(0, CHARS_PER_LINE - 1);
    sendPrintStr(ln);
  }

  // error line
  if (gTurbine.hasError) {
    sendFillRect(0, DISPLAY_HEIGHT - 33, DISPLAY_WIDTH, 11, 60, 0, 0);
    sendSetCursor(2, DISPLAY_HEIGHT - 32);
    sendSetTextColor(255, 80, 80);
    String err = gTurbine.errMsg;
    if ((int)err.length() > 25) err = err.substring(0, 24) + "..";
    sendPrintStr(err);
  }

  // LOG info line
  sendFillRect(0, DISPLAY_HEIGHT - 22, DISPLAY_WIDTH, 11, 0, 40, 20);
  sendSetCursor(2, DISPLAY_HEIGHT - 21);
  sendSetTextColor(150, 200, 150);
  String logInfo = "LOG: " + gTurbineLogger.getLogPath();
  if ((int)logInfo.length() > 25) logInfo = logInfo.substring(0, 24) + "..";
  sendPrintStr(logInfo);

  // footer
  sendFillRect(0, DISPLAY_HEIGHT - 11, DISPLAY_WIDTH, 11, 0, 30, 20);
  sendSetCursor(2, DISPLAY_HEIGHT - 9);
  sendSetTextColor(100, 120, 100);
  if (tuOutCount > visLines)
    sendPrintText("ENC/UD=scroll  HOME=back");
  else
    sendPrintText("HOME=back  OK=rerun");
}

// ── привязка колбэков движка (один раз; безопасно звать повторно) ──
// Вынесено отдельно от runTuFile(), чтобы этими же колбэками мог
// воспользоваться и bash (команда `tu <file>`) без полноэкранного
// раннера - см. cmdTu() в terminal.cpp.
static bool s_tuCallbacksReady = false;
void tuInitCallbacks() {
  if (s_tuCallbacksReady) return;
  s_tuCallbacksReady = true;

  gTurbine.cbPrint         = tuPrintCallback;
  gTurbine.cbSerialPCPrint = [](const char* s){
    if (SerialPC) SerialPC.print(s);   // не блокируем скрипт, если порт закрыт
    gTurbineLogger.log(String(s));
  };
  // display
  gTurbine.cbFillScreen   = sendFillScreen;
  gTurbine.cbSetCursor    = sendSetCursor;
  gTurbine.cbSetColor     = sendSetTextColor;
  gTurbine.cbPrintText    = sendPrintText;
  gTurbine.cbFillRect     = [](uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b){sendFillRect(x,y,w,h,r,g,b);};
  gTurbine.cbDrawRect     = [](uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b){sendDrawRect(x,y,w,h,r,g,b);};
  gTurbine.cbDrawLine     = [](uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint8_t r,uint8_t g,uint8_t b){sendDrawLine(x0,y0,x1,y1,r,g,b);};
  gTurbine.cbDrawPixel    = [](uint16_t x,uint16_t y,uint8_t r,uint8_t g,uint8_t b){sendDrawPixel(x,y,r,g,b);};
  // audio (логируем только начало/конец, не каждый тик)
  gTurbine.cbStartMusic   = [](const char* p)->bool{
    gTurbineLogger.info("Start music: " + String(p));
    return startMusic(String(p));
  };
  gTurbine.cbStopMusic    = [](){ gTurbineLogger.info("Stop music");   stopMusic();   };
  gTurbine.cbPauseMusic   = [](){ gTurbineLogger.info("Pause music");  pauseMusic();  };
  gTurbine.cbResumeMusic  = [](){ gTurbineLogger.info("Resume music"); resumeMusic(); };
  gTurbine.cbSetVolume    = [](uint8_t v){ gTurbineLogger.info("Set volume: " + String(v)); setVolume(v); };
  // gpio - НЕ логируем построчно по умолчанию (это и било по
  // производительности/Serial раньше); включается gTurbineLogger.setVerbose(true)
  gTurbine.cbReadPin      = [](int p)->int{
    int val = digitalRead(p);
    gTurbineLogger.logVerbose("[GPIO] READ pin" + String(p) + " = " + String(val));
    return val;
  };
  gTurbine.cbWritePin     = [](int p,int v){
    gTurbineLogger.logVerbose("[GPIO] WRITE pin" + String(p) + " = " + String(v));
    digitalWrite(p,v);
  };
  gTurbine.cbPinMode2     = [](int p,int m){
    String mode = (m == 0) ? "INPUT" : (m == 1) ? "OUTPUT" : "INPUT_PULLUP";
    gTurbineLogger.logVerbose("[GPIO] MODE pin" + String(p) + " = " + mode);
    pinMode(p,m);
  };
  // encoder / buttons
  gTurbine.cbEncDelta     = []()->int{ return readEncoderDelta(); };
  gTurbine.cbBtnPressed   = [](int id)->bool{
    switch(id){
      case 0: return bUp.pressed();
      case 1: return bDown.pressed();
      case 2: return bLeft.pressed();
      case 3: return bRight.pressed();
      case 4: return bOk.pressed();
      case 5: return bHome.pressed();
      case 6: return bCancel.pressed();
      case 7: return bEncBtn.pressed();
    }
    return false;
  };
}

// ── launcher (полноэкранный, из файлового браузера) ──────────
void runTuFile(const String& path) {
  tuFilePath   = path;
  tuOutCount   = 0;
  tuOutScroll  = 0;
  tuRunning    = true;

  gTurbineLogger.begin(path);   // не блокирует, даже если порт Serial закрыт
  gTurbineLogger.info("Starting script: " + path);

  // показываем заставку "Running..."
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 0, 60, 40);
  sendSetCursor(2, 2); sendSetTextColor(200, 255, 150);
  sendPrintText("TU: Running...");
  sendSetCursor(4, 40); sendSetTextColor(180, 180, 180);
  String fn = path.substring(path.lastIndexOf('/') + 1);
  sendPrintStr(fn);

  tuInitCallbacks();
  gTurbine.cbPrint = tuPrintCallback; // на случай, если bash временно подменял его

  gTurbineLogger.info("Running script...");
  bool ok = gTurbine.runFile(path);

  if (ok) gTurbineLogger.info("Script completed successfully");
  else    gTurbineLogger.error("Script failed: " + gTurbine.errMsg);

  tuRunning = false;
  gTurbineLogger.end();

  drawTuOutput();
}

// ── фильтр: .tu файлы в файловом менеджере ───────────────────
bool isTuFile(const String& filename) {
  String fn = filename; fn.toLowerCase();
  return fn.endsWith(".tu");
}

// ── STATE_TU_RUNNER handler — вставь в loop() ────────────────
void handleTuRunner(int enc) {
  bool redraw = false;
  int visLines = MAX_VIEW_LINES;

  if (bUp.pressed() || bUp.repeat()) {
    if (tuOutScroll > 0) { tuOutScroll--; redraw = true; }
  }
  if (bDown.pressed() || bDown.repeat()) {
    if (tuOutScroll + visLines < tuOutCount) { tuOutScroll++; redraw = true; }
  }
  if (enc != 0) {
    tuOutScroll = constrain(tuOutScroll + enc, 0, max(0, tuOutCount - visLines));
    redraw = true;
  }
  if (redraw) drawTuOutput();

  // rerun
  if (bOk.pressed()) {
    runTuFile(tuFilePath);
  }

  // back
  if (bHome.pressed() || bCancel.pressed()) {
    currentState = STATE_FILE_BROWSER;
    drawFileBrowser();
  }
}

// ============================================================
//  КАК ПОДКЛЮЧИТЬ к TextReaderVFS.ino (актуальная схема проекта)
//  ─────────────────────────────────────────────────────────────
//  1. Подключи ПОСЛЕ updateButtons() (т.е. после того как SerialPC,
//     DISPLAY_WIDTH/HEIGHT/HDR_H/LINE_H/MAX_VIEW_LINES/CHARS_PER_LINE,
//     bUp/bDown/.../bEncBtn и readEncoderDelta() уже определены),
//     иначе будет "not declared in this scope":
//
//       #include "turbine_integration.h"
//
//  2. В enum AppState добавь STATE_TU_RUNNER (после STATE_EDITOR).
//
//  3. В обоих местах открытия файла из браузера (лямбда openSelected
//     в STATE_FILE_BROWSER и блок "Open" в STATE_FILE_BROWSER_MENU)
//     добавь ветку ПЕРЕД isAudioFile(...):
//
//       } else if (isTuFile(e.name)) {
//         currentState = STATE_TU_RUNNER;
//         runTuFile(fullPath);
//
//  4. В refreshCurrentScreen() добавь:
//       case STATE_TU_RUNNER: drawTuOutput(); break;
//
//  5. В loop(), перед финальным "else { currentState = STATE_MENU; ... }"
//     добавь:
//       else if (currentState == STATE_TU_RUNNER) {
//         handleTuRunner(encDelta);
//       }
//
//  Файлы .tu кидаются в /sda или /sdb1.. как обычные текстовые файлы.
//
//  Если нужны подробные построчные GPIO-логи в .log файле - включи их
//  явно где-нибудь в setup(): gTurbineLogger.setVerbose(true);
//  По умолчанию выключено (именно это раньше било по скорости/Serial).
// ============================================================
