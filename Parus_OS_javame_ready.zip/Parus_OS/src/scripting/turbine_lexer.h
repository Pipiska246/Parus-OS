#pragma once
#include <Arduino.h>

// ============================================================
//  Turbine Lexer
// ============================================================

enum TokKind {
  TOK_EOF=0,
  TOK_NEWLINE,
  TOK_INDENT,    // synthetic: increase indent level
  TOK_DEDENT,    // synthetic: decrease indent level
  TOK_INT,
  TOK_FLOAT,
  TOK_STRING,
  TOK_BOOL,      // true / false
  TOK_IDENT,
  // keywords
  TOK_IF, TOK_ELIF, TOK_ELSE,
  TOK_WHILE, TOK_FOR, TOK_IN,
  TOK_SWITCH, TOK_STAR,      // '*' used for case
  TOK_RETURN, TOK_BREAK, TOK_CONTINUE,
  TOK_AND, TOK_OR, TOK_NOT,
  TOK_NIL,
  // declaration markers
  TOK_HASH,        // '#'  function
  TOK_DBLHASH,     // '##' enum/struct
  TOK_DASH,        // '-'  variable
  TOK_ARROW,       // '>'  import
  TOK_COLON,       // ':'  enum column header
  TOK_COMMA,
  TOK_DOT,
  TOK_DOTDOT,
  TOK_LBRACE,  TOK_RBRACE,
  TOK_LPAREN,  TOK_RPAREN,
  TOK_LBRACKET,TOK_RBRACKET,
  TOK_EQ,      // '='
  TOK_EQEQ,   TOK_NEQ,
  TOK_LT,     TOK_LE,
  TOK_GT,     TOK_GE,
  TOK_PLUS,   TOK_MINUS2,  // minus in expr (DASH is stmt-level '-')
  TOK_SLASH,  TOK_PERCENT,
  TOK_CARET,
  TOK_PLUSEQ, TOK_MINUSEQ, TOK_STAREQ, TOK_SLASHEQ,
};

struct Token {
  TokKind kind = TOK_EOF;
  long    ival = 0;
  double  fval = 0;
  bool    bval = false;
  String  sval;
  int     line = 1;
};

// ── Lexer ───────────────────────────────────────────────────
struct Lexer {
  const char* src = nullptr;
  int         pos = 0;
  int         len = 0;
  int         line = 1;

  // indent tracking
  int  indentStack[64];
  int  indentTop  = 0;
  int  curIndent  = 0;
  bool atLineStart = true;
  bool emittedNewline = false;

  // token buffer
  Token  buf[8];
  int    bufHead = 0, bufTail = 0, bufCount = 0;

  void init(const char* s, int l) {
    src = s; len = l; pos = 0; line = 1;
    indentStack[0] = 0; indentTop = 0;
    atLineStart = true; emittedNewline = false;
    bufHead = bufTail = bufCount = 0;
  }

  char peek(int off=0) {
    int p = pos+off;
    return (p<len) ? src[p] : '\0';
  }
  char advance() { return (pos<len)?src[pos++]:'\0'; }

  void skipLineComment() {
    while(pos<len && src[pos]!='\n') pos++;
  }

  bool isDigit(char c) { return c>='0'&&c<='9'; }
  bool isAlpha(char c) { return (c>='a'&&c<='z')||(c>='A'&&c<='Z')||c=='_'; }
  bool isAlNum(char c) { return isAlpha(c)||isDigit(c); }

  Token makeNumber() {
    Token t; t.line = line;
    bool hex = false;
    String raw = "";
    if(peek()=='0'&&(peek(1)=='x'||peek(1)=='X')) {
      advance(); advance(); hex=true;
      while(pos<len && (isDigit(peek())||(peek()>='a'&&peek()<='f')||(peek()>='A'&&peek()<='F')))
        raw += advance();
      t.kind = TOK_INT; t.ival = strtol(raw.c_str(),nullptr,16);
      return t;
    }
    if(peek()=='0'&&(peek(1)=='o'||peek(1)=='O')) {
      advance(); advance();
      while(pos<len && peek()>='0'&&peek()<='7') raw += advance();
      t.kind = TOK_INT; t.ival = strtol(raw.c_str(),nullptr,8);
      return t;
    }
    while(pos<len && isDigit(peek())) raw += advance();
    bool isFloat = false;
    if(pos<len && peek()=='.' && peek(1)!='.' && isDigit(peek(1))) {
      isFloat=true; raw += advance();
      while(pos<len && isDigit(peek())) raw += advance();
    }
    if(pos<len && (peek()=='e'||peek()=='E')) {
      isFloat=true; raw += advance();
      if(pos<len && (peek()=='+'||peek()=='-')) raw += advance();
      while(pos<len && isDigit(peek())) raw += advance();
    }
    if(isFloat) { t.kind=TOK_FLOAT; t.fval=atof(raw.c_str()); }
    else        { t.kind=TOK_INT;   t.ival=atol(raw.c_str()); }
    return t;
  }

  Token makeString() {
    advance(); // skip opening "
    Token t; t.line=line; t.kind=TOK_STRING;
    while(pos<len && peek()!='"') {
      char c=advance();
      if(c=='\\') {
        char e=advance();
        switch(e){
          case 'n':  t.sval+='\n'; break;
          case 't':  t.sval+='\t'; break;
          case 'r':  t.sval+='\r'; break;
          case '\\': t.sval+='\\'; break;
          case '"':  t.sval+='"';  break;
          default:   t.sval+=e;    break;
        }
      } else t.sval += c;
    }
    if(pos<len) advance(); // skip closing "
    return t;
  }

  Token makeIdent() {
    Token t; t.line=line;
    String id="";
    while(pos<len && isAlNum(peek())) id += advance();
    t.sval = id;
    // keywords
    if(id=="if")       { t.kind=TOK_IF;    }
    else if(id=="elif"){ t.kind=TOK_ELIF;  }
    else if(id=="else"){ t.kind=TOK_ELSE;  }
    else if(id=="while"){t.kind=TOK_WHILE; }
    else if(id=="for")  {t.kind=TOK_FOR;   }
    else if(id=="in")   {t.kind=TOK_IN;    }
    else if(id=="switch"){t.kind=TOK_SWITCH;}
    else if(id=="return"){t.kind=TOK_RETURN;}
    else if(id=="break") {t.kind=TOK_BREAK; }
    else if(id=="continue"){t.kind=TOK_CONTINUE;}
    else if(id=="and")  {t.kind=TOK_AND;   }
    else if(id=="or")   {t.kind=TOK_OR;    }
    else if(id=="not")  {t.kind=TOK_NOT;   }
    else if(id=="true") {t.kind=TOK_BOOL; t.bval=true; }
    else if(id=="false"){t.kind=TOK_BOOL; t.bval=false;}
    else if(id=="nil")  {t.kind=TOK_NIL;  }
    else if(id=="int"||id=="float"||id=="bool"||id=="string"||
            id=="vec"  ||id=="map" ||id=="set" ||
            id=="stack"||id=="queue"||id=="out") {
      t.kind=TOK_IDENT;
    }
    else t.kind=TOK_IDENT;
    return t;
  }

  // measure indent of current line (called after \n)
  int measureIndent() {
    int ind=0;
    while(pos<len && (src[pos]==' '||src[pos]=='\t')) {
      if(src[pos]=='\t') ind+=4; else ind++;
      pos++;
    }
    return ind;
  }

  // raw next token (no indent synthesis)
  Token rawNext() {
    // skip spaces (not newline)
    while(pos<len && (src[pos]==' '||src[pos]=='\t') && !atLineStart)
      pos++;
    if(pos>=len) { Token t; t.kind=TOK_EOF; return t; }

    char c = src[pos];

    if(c=='\r') { pos++; return rawNext(); }
    if(c=='\n') {
      pos++; line++;
      atLineStart = true;
      curIndent = measureIndent();
      Token t; t.kind=TOK_NEWLINE; t.line=line;
      // skip blank lines and comment-only lines
      while(pos<len) {
        // skip whitespace that measureIndent already consumed
        if(pos<len && src[pos]=='\n') {
          pos++; line++;
          curIndent = measureIndent();
          continue;
        }
        if(pos+1<len && src[pos]=='/' && src[pos+1]=='/') {
          skipLineComment();
          if(pos<len&&src[pos]=='\n'){pos++;line++;curIndent=measureIndent();}
          continue;
        }
        break;
      }
      if(pos>=len){ t.kind=TOK_EOF; return t; }
      return t;
    }

    // handle indent at line start
    if(atLineStart) {
      atLineStart = false;
      // indent already measured by previous \n handler
      int top = indentStack[indentTop];
      if(curIndent > top) {
        indentStack[++indentTop] = curIndent;
        Token t; t.kind=TOK_INDENT; t.line=line; return t;
      }
      if(curIndent < top) {
        indentStack[indentTop--] = 0;
        Token t; t.kind=TOK_DEDENT; t.line=line; return t;
      }
    }

    if(c=='/'&&peek(1)=='/') { skipLineComment(); return rawNext(); }
    if(isDigit(c)) return makeNumber();
    if(c=='"')     return makeString();
    if(isAlpha(c)) return makeIdent();

    pos++;
    Token t; t.line=line;
    switch(c) {
      case '#':
        if(pos<len&&src[pos]=='#'){pos++;t.kind=TOK_DBLHASH;}
        else t.kind=TOK_HASH;
        break;
      case '-':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_MINUSEQ;}
        else if(atLineStart||emittedNewline) t.kind=TOK_DASH;
        else t.kind=TOK_MINUS2;
        break;
      case '>':
        if(atLineStart||emittedNewline) { t.kind=TOK_ARROW; }
        else if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_GE;}
        else t.kind=TOK_GT;
        break;
      case ':': t.kind=TOK_COLON;  break;
      case ',': t.kind=TOK_COMMA;  break;
      case '.':
        if(pos<len&&src[pos]=='.'){pos++;t.kind=TOK_DOTDOT;}
        else t.kind=TOK_DOT;
        break;
      case '{': t.kind=TOK_LBRACE;   break;
      case '}': t.kind=TOK_RBRACE;   break;
      case '(': t.kind=TOK_LPAREN;   break;
      case ')': t.kind=TOK_RPAREN;   break;
      case '[': t.kind=TOK_LBRACKET; break;
      case ']': t.kind=TOK_RBRACKET; break;
      case '=':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_EQEQ;}
        else t.kind=TOK_EQ;
        break;
      case '!':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_NEQ;}
        else t.kind=TOK_IDENT; // shouldn't happen
        break;
      case '<':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_LE;}
        else t.kind=TOK_LT;
        break;
      case '+':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_PLUSEQ;}
        else t.kind=TOK_PLUS;
        break;
      case '*':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_STAREQ;}
        else t.kind=TOK_STAR;
        break;
      case '/':
        if(pos<len&&src[pos]=='='){pos++;t.kind=TOK_SLASHEQ;}
        else t.kind=TOK_SLASH;
        break;
      case '%': t.kind=TOK_PERCENT; break;
      case '^': t.kind=TOK_CARET;   break;
      default:  t.kind=TOK_IDENT; t.sval=String(c); break;
    }
    emittedNewline = (t.kind==TOK_NEWLINE);
    return t;
  }

  // peek Nth token
  Token& peek2(int off=0) {
    while(bufCount <= off) {
      buf[(bufTail)%8] = rawNext();
      bufTail = (bufTail+1)%8;
      bufCount++;
    }
    return buf[(bufHead+off)%8];
  }

  Token next() {
    if(bufCount>0) {
      Token t = buf[bufHead%8];
      bufHead=(bufHead+1)%8;
      bufCount--;
      emittedNewline = (t.kind==TOK_NEWLINE);
      return t;
    }
    return rawNext();
  }

  void skipNewlines() {
    while(peek2().kind==TOK_NEWLINE) next();
  }
};
