#pragma once
#include <Arduino.h>

// ================================================================
//  net.h — WiFi / HTTP("curl") / NTP-время через ESP32-мост (Serial1)
//
//  Использует ТОТ ЖЕ UART-канал и фрейминг [0xAA][cmd][len][data][0x55],
//  что и команды экрана (devices_vfs.cpp), но новый диапазон команд
//  0x70-0x7F, который прошивка ESP32 (esp32_bridge.ino) обрабатывает
//  отдельно от графики/ESP-NOW.
//
//  ВАЖНО: эти функции БЛОКИРУЮТ выполнение (ждут ответ ESP32 с таймаутом).
//  Поэтому их нельзя дёргать из ISR/audio-таска - только из основного
//  loop()/bash/Turbine-скриптов, как обычные "медленные" операции.
// ================================================================

// Инициализация (не обязательна - Serial1 уже поднят кодом дисплея;
// функция оставлена для симметрии с остальными *Init() в проекте).
void netInit();

// Подключение к WiFi по SSID/паролю. Блокирует до ~15 секунд.
bool netWifiConnect(const String& ssid, const String& pass);

// Текущий статус WiFi: connected, RSSI (дБм, отрицательное число) и IP в виде строки.
bool netWifiStatus(bool& connected, int& rssiDbm, String& ip);

void netWifiDisconnect();

// Лёгкий неблокирующий опрос для статус-бара/часов - реальный (блокирующий)
// запрос к ESP32 делает не чаще раза в 5 секунд внутри. Зови откуда угодно
// часто (например, на каждой отрисовке статус-бара) - не подвиснет.
void netPoll();

// Сила сигнала в "барах" 0..4 (для статус-бара), -1 если не подключено.
int netWifiBars();

// Синхронизация времени по NTP (блокирует до ~8 секунд).
bool netTimeSync();

// Текущее unix-время (секунды с 1970), если уже синхронизировано.
bool netTimeGet(uint32_t& unixTime);

// Человекочитаемое HH:MM (UTC) для статус-бара/часов; "--:--" если нет времени.
String netTimeHHMM();
// Полная строка ЧЧ:ММ:СС ДД.ММ.ГГГГ (UTC).
String netTimeFull();

// HTTP GET. outBody обрезается до maxBytes. statusCode: HTTP-код, либо
// отрицательное значение при ошибке (-1 нет ответа/таймаут, -101.. ошибка ESP32).
bool netHttpGet(const String& url, String& outBody, int& statusCode, size_t maxBytes = 8000);

// TCP-ping (замер задержки соединения на порт 80, т.к. raw ICMP недоступен).
// rttMsOut заполняется временем в мс при успехе, -1 при таймауте/недоступности хоста.
bool netPing(const String& host, int& rttMsOut);

// ── сохранение Wi-Fi пароля для автоподключения при старте ──────
bool netSaveWifiConfig(const String& ssid, const String& pass);
bool netLoadWifiConfig(String& ssid, String& pass);   // true если файл найден
bool netAutoConnect(); // пытается подключиться по сохранённым данным (если есть)
