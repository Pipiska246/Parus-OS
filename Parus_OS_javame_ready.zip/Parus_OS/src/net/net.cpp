#include "net.h"
#include "../vfs/vfs.h"

// ================================================================
//  Низкоуровневый обмен кадрами с ESP32-мостом по Serial1.
//  Формат кадра: [0xAA][cmd][len][data...(len байт)][0x55]
// ================================================================
#define NET_CMD_WIFI_CONNECT     0x70
#define NET_CMD_WIFI_STATUS      0x71
#define NET_CMD_WIFI_DISCONNECT  0x72
#define NET_CMD_TIME_SYNC        0x73
#define NET_CMD_TIME_GET         0x74
#define NET_CMD_HTTP_GET         0x75
#define NET_CMD_HTTP_CHUNK       0x76
#define NET_CMD_HTTP_DONE        0x77
#define NET_CMD_HTTP_ERROR       0x78
#define NET_CMD_PING             0x79

#define WIFI_CFG_PATH "/sda/.wifi_cfg"

static void sendFrame(uint8_t cmd, const uint8_t* data, uint8_t len) {
  Serial1.write((uint8_t)0xAA);
  Serial1.write(cmd);
  Serial1.write(len);
  if (len) Serial1.write(data, len);
  Serial1.write((uint8_t)0x55);
}

// Читает один кадр [0xAA][cmd][len][data..][0x55] с общим таймаутом.
// Возвращает false при таймауте/обрыве кадра.
static bool readFrame(uint8_t& cmdOut, uint8_t* buf, uint8_t bufCap, uint8_t& lenOut, unsigned long timeoutMs) {
  unsigned long start = millis();
  // ждём байт-маркер начала кадра 0xAA
  while (true) {
    if ((millis() - start) > timeoutMs) return false;
    if (Serial1.available()) {
      if ((uint8_t)Serial1.read() == 0xAA) break;
    }
  }
  while (!Serial1.available()) { if ((millis() - start) > timeoutMs) return false; }
  cmdOut = Serial1.read();
  while (!Serial1.available()) { if ((millis() - start) > timeoutMs) return false; }
  uint8_t len = Serial1.read();
  uint8_t got = 0;
  while (got < len) {
    if (Serial1.available()) {
      uint8_t b = Serial1.read();
      if (got < bufCap) buf[got] = b;
      got++;
    } else if ((millis() - start) > timeoutMs) {
      return false;
    }
  }
  while (!Serial1.available()) { if ((millis() - start) > timeoutMs) return false; }
  uint8_t tail = Serial1.read();
  lenOut = len;
  return tail == 0x55;
}

void netInit() {
  // Serial1 уже инициализирован кодом дисплея (devices_vfs / .ino) - здесь
  // ничего открывать не нужно, функция оставлена для симметрии с *Init().
}

// ================================================================
//  WiFi
// ================================================================
static bool   s_wifiConnected = false;
static int    s_wifiRssi      = -127;
static String s_wifiIp        = "";
static unsigned long s_lastWifiPoll = 0;

bool netWifiConnect(const String& ssid, const String& pass) {
  uint8_t payload[200];
  uint8_t sl = (uint8_t)min((size_t)ssid.length(), (size_t)90);
  uint8_t pl = (uint8_t)min((size_t)pass.length(), (size_t)90);
  payload[0] = sl;
  memcpy(payload + 1, ssid.c_str(), sl);
  payload[1 + sl] = pl;
  memcpy(payload + 2 + sl, pass.c_str(), pl);
  uint8_t total = 2 + sl + pl;

  sendFrame(NET_CMD_WIFI_CONNECT, payload, total);

  uint8_t cmd, buf[8], len;
  // ESP32 само ждёт до 15с подключения, плюс запас на передачу кадра
  if (!readFrame(cmd, buf, sizeof(buf), len, 16000)) return false;
  if (cmd != NET_CMD_WIFI_CONNECT || len < 1) return false;
  bool ok = buf[0] == 1;
  if (ok) s_lastWifiPoll = 0; // форсируем обновление статуса при следующем netPoll()
  return ok;
}

bool netWifiStatus(bool& connected, int& rssiDbm, String& ip) {
  sendFrame(NET_CMD_WIFI_STATUS, nullptr, 0);
  uint8_t cmd, buf[8], len;
  if (!readFrame(cmd, buf, sizeof(buf), len, 3000)) return false;
  if (cmd != NET_CMD_WIFI_STATUS || len < 6) return false;
  connected = buf[0] == 1;
  rssiDbm   = connected ? -(int)buf[1] : -127;
  ip        = connected ? (String(buf[2]) + "." + buf[3] + "." + buf[4] + "." + buf[5]) : "";
  s_wifiConnected = connected; s_wifiRssi = rssiDbm; s_wifiIp = ip;
  s_lastWifiPoll = millis();
  return true;
}

void netWifiDisconnect() {
  sendFrame(NET_CMD_WIFI_DISCONNECT, nullptr, 0);
  uint8_t cmd, buf[4], len;
  readFrame(cmd, buf, sizeof(buf), len, 3000); // не критично, если не дождались
  s_wifiConnected = false; s_wifiRssi = -127; s_wifiIp = "";
}

// Лёгкий неблокирующий опрос - дёргай раз в несколько секунд из loop().
// Реальный (блокирующий) UART-запрос делается не чаще, чем раз в 5 секунд.
void netPoll() {
  if (millis() - s_lastWifiPoll < 5000) return;
  bool c; int r; String ip;
  netWifiStatus(c, r, ip); // обновит кэш и s_lastWifiPoll внутри
}

int netWifiBars() {
  if (!s_wifiConnected) return -1;
  if (s_wifiRssi >= -55) return 4;
  if (s_wifiRssi >= -65) return 3;
  if (s_wifiRssi >= -75) return 2;
  if (s_wifiRssi >= -85) return 1;
  return 0;
}

// ================================================================
//  Время (кэшируется локально - между NTP-синками просто прибавляем millis())
// ================================================================
static bool          s_timeValid    = false;
static uint32_t      s_baseUnixTime = 0;
static unsigned long s_baseMillis   = 0;

bool netTimeSync() {
  sendFrame(NET_CMD_TIME_SYNC, nullptr, 0);
  uint8_t cmd, buf[4], len;
  if (!readFrame(cmd, buf, sizeof(buf), len, 28000)) return false;
  if (cmd != NET_CMD_TIME_SYNC || len < 1 || buf[0] != 1) return false;

  // сразу забираем актуальное время одним обменом, чтобы не ждать второй раз
  sendFrame(NET_CMD_TIME_GET, nullptr, 0);
  uint8_t cmd2, buf2[8], len2;
  if (!readFrame(cmd2, buf2, sizeof(buf2), len2, 3000)) return false;
  if (cmd2 != NET_CMD_TIME_GET || len2 < 5 || buf2[0] != 1) return false;

  uint32_t t = ((uint32_t)buf2[1] << 24) | ((uint32_t)buf2[2] << 16) | ((uint32_t)buf2[3] << 8) | buf2[4];
  s_baseUnixTime = t;
  s_baseMillis   = millis();
  s_timeValid    = true;
  return true;
}

bool netTimeGet(uint32_t& unixTime) {
  if (!s_timeValid) return false;
  unixTime = s_baseUnixTime + (uint32_t)((millis() - s_baseMillis) / 1000UL);
  return true;
}

static void civilFromUnix(uint32_t unixTime, int& year, int& month, int& day, int& hour, int& min_, int& sec) {
  // Алгоритм Hinnant civil_from_days (UTC, без часовых поясов).
  long days = (long)(unixTime / 86400UL);
  long rem  = (long)(unixTime % 86400UL);
  hour = rem / 3600; rem %= 3600;
  min_ = rem / 60; sec = rem % 60;

  days += 719468;
  long era = (days >= 0 ? days : days - 146096) / 146097;
  unsigned doe = (unsigned)(days - era * 146097);
  unsigned yoe = (doe - doe/1460 + doe/36524 - doe/146096) / 365;
  long y = (long)yoe + era * 400;
  unsigned doy = doe - (365*yoe + yoe/4 - yoe/100);
  unsigned mp = (5*doy + 2)/153;
  unsigned d = doy - (153*mp+2)/5 + 1;
  unsigned m = mp + (mp < 10 ? 3 : -9);
  y += (m <= 2);

  year = (int)y; month = (int)m; day = (int)d;
}

String netTimeHHMM() {
  uint32_t t;
  if (!netTimeGet(t)) return "--:--";
  int y,mo,d,h,mi,s;
  civilFromUnix(t, y, mo, d, h, mi, s);
  char buf[6];
  snprintf(buf, sizeof(buf), "%02d:%02d", h, mi);
  return String(buf);
}

String netTimeFull() {
  uint32_t t;
  if (!netTimeGet(t)) return "--:--:-- --.--.----";
  int y,mo,d,h,mi,s;
  civilFromUnix(t, y, mo, d, h, mi, s);
  char buf[24];
  snprintf(buf, sizeof(buf), "%02d:%02d:%02d %02d.%02d.%04d", h, mi, s, d, mo, y);
  return String(buf);
}

// ================================================================
//  HTTP GET ("curl")
// ================================================================
bool netHttpGet(const String& url, String& outBody, int& statusCode, size_t maxBytes) {
  outBody = "";
  statusCode = -1;

  uint8_t ul = (uint8_t)min((size_t)url.length(), (size_t)244);
  sendFrame(NET_CMD_HTTP_GET, (const uint8_t*)url.c_str(), ul);

  unsigned long overallStart = millis();
  const unsigned long OVERALL_TIMEOUT = 20000;

  while (true) {
    unsigned long elapsed = millis() - overallStart;
    if (elapsed > OVERALL_TIMEOUT) { statusCode = -1; return false; }

    uint8_t cmd, buf[210], len;
    if (!readFrame(cmd, buf, sizeof(buf), len, OVERALL_TIMEOUT - elapsed)) {
      statusCode = -1;
      return false;
    }
    if (cmd == NET_CMD_HTTP_CHUNK) {
      if (outBody.length() < maxBytes) {
        size_t room = maxBytes - outBody.length();
        size_t take = min((size_t)len, room);
        outBody += String((const char*)buf, take);
      }
    } else if (cmd == NET_CMD_HTTP_DONE) {
      statusCode = (len >= 2) ? ((int)buf[0] << 8 | buf[1]) : -1;
      return true;
    } else if (cmd == NET_CMD_HTTP_ERROR) {
      statusCode = -100 - (len >= 1 ? buf[0] : 0);
      return false;
    }
    // прочие кадры (например, эхо чего-то параллельного на дисплейном
    // канале) просто игнорируем и продолжаем ждать ответ по HTTP
  }
}

// ================================================================
//  Сохранённые WiFi-данные для автоподключения
// ================================================================
// ================================================================
//  TCP-ping (port 80 connect latency)
// ================================================================
bool netPing(const String& host, int& rttMsOut) {
  rttMsOut = -1;
  uint8_t hl = (uint8_t)min((size_t)host.length(), (size_t)244);
  sendFrame(NET_CMD_PING, (const uint8_t*)host.c_str(), hl);

  uint8_t cmd, buf[8], len;
  if (!readFrame(cmd, buf, sizeof(buf), len, 10000)) return false;
  if (cmd != NET_CMD_PING || len < 3) return false;

  bool ok = buf[0] == 1;
  if (ok) rttMsOut = ((int)buf[1] << 8) | buf[2];
  return ok;
}

bool netSaveWifiConfig(const String& ssid, const String& pass) {
  VfsFile f;
  if (!f.openWrite(WIFI_CFG_PATH, false)) return false;
  String line = ssid + "\n" + pass + "\n";
  f.write((const uint8_t*)line.c_str(), line.length());
  f.close();
  return true;
}

bool netLoadWifiConfig(String& ssid, String& pass) {
  if (!vfsExists(WIFI_CFG_PATH)) return false;
  VfsFile f;
  if (!f.openRead(WIFI_CFG_PATH)) return false;
  String all = "";
  uint8_t b;
  while (f.read(&b, 1) == 1) all += (char)b;
  f.close();
  int nl = all.indexOf('\n');
  if (nl < 0) return false;
  ssid = all.substring(0, nl);
  int nl2 = all.indexOf('\n', nl + 1);
  pass = (nl2 < 0) ? all.substring(nl + 1) : all.substring(nl + 1, nl2);
  ssid.trim(); pass.trim();
  return ssid.length() > 0;
}

bool netAutoConnect() {
  String ssid, pass;
  if (!netLoadWifiConfig(ssid, pass)) return false;
  return netWifiConnect(ssid, pass);
}
