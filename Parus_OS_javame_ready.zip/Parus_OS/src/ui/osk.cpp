#include "osk.h"
#include "../core/ui_common.h"
#include <string.h>

// ================================================================
//  Grid layout
// ================================================================
struct GridKey { const char *label; OskAction action; char ch; };

static const GridKey ROW0[] = {
  {"1",OSK_CHAR,'1'},{"2",OSK_CHAR,'2'},{"3",OSK_CHAR,'3'},{"4",OSK_CHAR,'4'},{"5",OSK_CHAR,'5'},
  {"6",OSK_CHAR,'6'},{"7",OSK_CHAR,'7'},{"8",OSK_CHAR,'8'},{"9",OSK_CHAR,'9'},{"0",OSK_CHAR,'0'},
};
static const GridKey ROW1[] = {
  {"q",OSK_CHAR,'q'},{"w",OSK_CHAR,'w'},{"e",OSK_CHAR,'e'},{"r",OSK_CHAR,'r'},{"t",OSK_CHAR,'t'},
  {"y",OSK_CHAR,'y'},{"u",OSK_CHAR,'u'},{"i",OSK_CHAR,'i'},{"o",OSK_CHAR,'o'},{"p",OSK_CHAR,'p'},
};
static const GridKey ROW2[] = {
  {"a",OSK_CHAR,'a'},{"s",OSK_CHAR,'s'},{"d",OSK_CHAR,'d'},{"f",OSK_CHAR,'f'},{"g",OSK_CHAR,'g'},
  {"h",OSK_CHAR,'h'},{"j",OSK_CHAR,'j'},{"k",OSK_CHAR,'k'},{"l",OSK_CHAR,'l'},
};
static const GridKey ROW3[] = {
  {"z",OSK_CHAR,'z'},{"x",OSK_CHAR,'x'},{"c",OSK_CHAR,'c'},{"v",OSK_CHAR,'v'},{"b",OSK_CHAR,'b'},
  {"n",OSK_CHAR,'n'},{"m",OSK_CHAR,'m'},{"-",OSK_CHAR,'-'},{"_",OSK_CHAR,'_'},{".",OSK_CHAR,'.'},
  {"/",OSK_CHAR,'/'},{":",OSK_CHAR,':'},{"*",OSK_CHAR,'*'},{"~",OSK_CHAR,'~'},{">",OSK_CHAR,'>'},
};
static const GridKey ACTIONS_TERMINAL[] = {
  {"SPC",OSK_SPACE,0},{"<",OSK_LEFT,0},{">",OSK_RIGHT,0},{"DEL",OSK_BACKSPACE,0},
  {"RUN",OSK_ENTER,0},{"ESC",OSK_ESC,0},
};
static const GridKey ACTIONS_EDITOR[] = {
  {"SPC",OSK_SPACE,0},{"<",OSK_LEFT,0},{">",OSK_RIGHT,0},{"^",OSK_UP,0},{"v",OSK_DOWN,0},
  {"DEL",OSK_BACKSPACE,0},{"NL",OSK_ENTER,0},{"SAVE",OSK_SAVE,0},{"ESC",OSK_ESC,0},
};

static const GridKey *const LETTER_ROWS[4] = { ROW0, ROW1, ROW2, ROW3 };
static const int LETTER_ROW_LEN[4] = {
  sizeof(ROW0)/sizeof(GridKey), sizeof(ROW1)/sizeof(GridKey),
  sizeof(ROW2)/sizeof(GridKey), sizeof(ROW3)/sizeof(GridKey)
};
#define LETTER_ROW_COUNT 4
#define TOTAL_ROW_COUNT  (LETTER_ROW_COUNT + 1)   // + 1 action row

static bool s_editorMode = false;
static int  s_curRow = 0, s_curCol = 0;

static const GridKey *rowPtr(int row, int *lenOut) {
  if (row < LETTER_ROW_COUNT) { *lenOut = LETTER_ROW_LEN[row]; return LETTER_ROWS[row]; }
  if (s_editorMode) { *lenOut = sizeof(ACTIONS_EDITOR)/sizeof(GridKey); return ACTIONS_EDITOR; }
  *lenOut = sizeof(ACTIONS_TERMINAL)/sizeof(GridKey); return ACTIONS_TERMINAL;
}

void oskInit(bool editorMode) {
  s_editorMode = editorMode;
  s_curRow = 0;
  s_curCol = 0;
}

OskEvent oskHandleInput(bool *movedOut) {
  OskEvent ev{OSK_NONE, 0};
  bool moved = false;

  if (bUp.pressed() || bUp.repeat())   { if (s_curRow > 0) { s_curRow--; moved = true; } }
  if (bDown.pressed() || bDown.repeat()) { if (s_curRow < TOTAL_ROW_COUNT - 1) { s_curRow++; moved = true; } }

  int rowLen; rowPtr(s_curRow, &rowLen);
  if (s_curCol >= rowLen) s_curCol = rowLen - 1;

  if (bLeft.pressed() || bLeft.repeat()) {
    if (s_curCol > 0) s_curCol--; else s_curCol = rowLen - 1;
    moved = true;
  }
  if (bRight.pressed() || bRight.repeat()) {
    if (s_curCol < rowLen - 1) s_curCol++; else s_curCol = 0;
    moved = true;
  }
  int enc = readEncoderDelta();
  if (enc != 0) {
    int flat = 0;
    for (int r = 0; r < s_curRow; r++) { int l; rowPtr(r, &l); flat += l; }
    flat += s_curCol;
    int total = 0;
    for (int r = 0; r < TOTAL_ROW_COUNT; r++) { int l; rowPtr(r, &l); total += l; }
    flat = (flat + enc + total) % total;
    for (int r = 0; r < TOTAL_ROW_COUNT; r++) {
      int l; rowPtr(r, &l);
      if (flat < l) { s_curRow = r; s_curCol = flat; break; }
      flat -= l;
    }
    moved = true;
  }

  if (bOk.pressed()) {
    int len; const GridKey *row = rowPtr(s_curRow, &len);
    if (s_curCol < len) {
      const GridKey &k = row[s_curCol];
      ev.action = k.action;
      ev.ch     = k.ch;
    }
  }
  if (bCancel.pressed()) { ev.action = OSK_BACKSPACE; }

  if (movedOut) *movedOut = moved;
  return ev;
}

void oskDraw(int yTop, int height) {
  sendFillRect(0, yTop, UI_DISPLAY_WIDTH, height, 8, 8, 16);
  int rowH = height / TOTAL_ROW_COUNT;
  for (int r = 0; r < TOTAL_ROW_COUNT; r++) {
    int len; const GridKey *row = rowPtr(r, &len);
    int cellW = UI_DISPLAY_WIDTH / len;
    int y = yTop + r * rowH;
    for (int c = 0; c < len; c++) {
      int x = c * cellW;
      bool sel = (r == s_curRow && c == s_curCol);
      if (sel) sendFillRect(x + 1, y + 1, cellW - 2, rowH - 2, 0, 90, 60);
      sendSetCursor(x + (cellW - (int)strlen(row[c].label) * UI_CHAR_W) / 2, y + (rowH - UI_CHAR_H) / 2);
      sendSetTextColor(sel ? 255 : 190, sel ? 255 : 190, sel ? 120 : 190);
      sendPrintText(row[c].label);
    }
  }
}
