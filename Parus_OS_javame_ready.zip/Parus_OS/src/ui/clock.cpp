#include "clock.h"
#include "../core/ui_common.h"
#include "../net/net.h"

// ================================================================
//  внутреннее состояние
// ================================================================
enum ClockMode { CM_VIEW, CM_SET_TIMER, CM_TIMER_RUN, CM_SET_ALARM };
static ClockMode s_mode = CM_VIEW;

static int s_timerMin = 5, s_timerSec = 0;     // настройка таймера (мин:сек)
static uint32_t s_timerEndUnix = 0;
static bool s_timerActive = false;
static bool s_timerRang = false;

static int s_alarmHour = 7, s_alarmMin = 0;
static bool s_alarmArmed = false;
static bool s_alarmFiredToday = false;
static int s_lastAlarmCheckDay = -1;

static bool s_ringing = false; // будильник ИЛИ таймер прозвенел и ждёт подтверждения

void clockInit() {
  s_mode = CM_VIEW;
}

bool clockAlarmIsRinging() { return s_ringing; }
void clockAlarmDismiss() {
  s_ringing = false;
  s_timerActive = false;
  s_timerRang = false;
}

// ================================================================
//  7-segментный рендер цифр крупным шрифтом
// ================================================================
static const uint8_t SEG7[10] = {
  0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F
};

// thick = толщина сегмента, segLen = длина сегмента; полная ширина цифры
// = 2*thick+segLen, высота = 2*thick+2*segLen.
static void drawBigDigit(int x, int y, int digit, int thick, int segLen, uint8_t r, uint8_t g, uint8_t b) {
  if (digit < 0 || digit > 9) return;
  uint8_t s = SEG7[digit];
  if (s & 0x01) sendFillRect(x + thick, y, segLen, thick, r, g, b);                                   // a (top)
  if (s & 0x20) sendFillRect(x, y + thick, thick, segLen, r, g, b);                                   // f (top-left)
  if (s & 0x02) sendFillRect(x + thick + segLen, y + thick, thick, segLen, r, g, b);                  // b (top-right)
  if (s & 0x40) sendFillRect(x + thick, y + thick + segLen, segLen, thick, r, g, b);                  // g (middle)
  if (s & 0x10) sendFillRect(x, y + 2*thick + segLen, thick, segLen, r, g, b);                         // e (bottom-left)
  if (s & 0x04) sendFillRect(x + thick + segLen, y + 2*thick + segLen, thick, segLen, r, g, b);        // c (bottom-right)
  if (s & 0x08) sendFillRect(x + thick, y + 2*thick + 2*segLen, segLen, thick, r, g, b);                // d (bottom)
}

#define DIG_THICK 4
#define DIG_SEGLEN 16
#define DIG_W (2*DIG_THICK + DIG_SEGLEN)
#define DIG_H (2*DIG_THICK + 2*DIG_SEGLEN)

static void drawBigTime(int x, int y, int hh, int mm, uint8_t r, uint8_t g, uint8_t b) {
  int cx = x;
  drawBigDigit(cx, y, hh / 10, DIG_THICK, DIG_SEGLEN, r, g, b); cx += DIG_W + 4;
  drawBigDigit(cx, y, hh % 10, DIG_THICK, DIG_SEGLEN, r, g, b); cx += DIG_W + 6;
  // колон (двоеточие) - два маленьких квадрата
  sendFillRect(cx, y + DIG_H/2 - 10, 5, 5, r, g, b);
  sendFillRect(cx, y + DIG_H/2 + 5, 5, 5, r, g, b);
  cx += 11;
  drawBigDigit(cx, y, mm / 10, DIG_THICK, DIG_SEGLEN, r, g, b); cx += DIG_W + 4;
  drawBigDigit(cx, y, mm % 10, DIG_THICK, DIG_SEGLEN, r, g, b);
}

// ================================================================
//  отрисовка
// ================================================================
void clockDraw() {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, UI_DISPLAY_WIDTH, 12, 0, 50, 70);
  sendSetCursor(2, 2); sendSetTextColor(220, 240, 255);
  sendPrintText("CLOCK");

  uint32_t t;
  bool haveTime = netTimeGet(t);

  if (s_mode == CM_VIEW) {
    if (haveTime) {
      String full = netTimeFull(); // "HH:MM:SS DD.MM.YYYY"
      int hh = full.substring(0,2).toInt();
      int mm = full.substring(3,5).toInt();
      drawBigTime((UI_DISPLAY_WIDTH - (DIG_W*4+4+6+11)) / 2, 22, hh, mm, 0, 220, 255);
      sendSetCursor(46, 76); sendSetTextColor(150, 200, 220);
      sendPrintStr(full.substring(9)); // дата
    } else {
      sendSetCursor(10, 40); sendSetTextColor(255, 120, 120);
      sendPrintText("Нет времени.");
      sendSetCursor(10, 52); sendPrintText("В bash: time sync");
      sendSetCursor(10, 64); sendPrintText("(нужен WiFi)");
    }

    int wbar = netWifiBars();
    sendSetCursor(2, 90); sendSetTextColor(140,140,140);
    sendPrintText(wbar < 0 ? "wifi: --" : ("wifi: " + String(wbar) + "/4").c_str());

    if (s_timerActive) {
      uint32_t now; netTimeGet(now);
      long left = (long)s_timerEndUnix - (long)now;
      if (left < 0) left = 0;
      char buf[24];
      snprintf(buf, sizeof(buf), "Timer: %02ld:%02ld", left/60, left%60);
      sendSetCursor(2, 100); sendSetTextColor(255, 200, 80);
      sendPrintText(buf);
    }
    if (s_alarmArmed) {
      char buf[24];
      snprintf(buf, sizeof(buf), "Alarm: %02d:%02d", s_alarmHour, s_alarmMin);
      sendSetCursor(90, 100); sendSetTextColor(255, 200, 80);
      sendPrintText(buf);
    }
  } else if (s_mode == CM_SET_TIMER) {
    sendSetCursor(10, 30); sendSetTextColor(255,255,255);
    sendPrintText("Set timer (min:sec)");
    char buf[12]; snprintf(buf, sizeof(buf), "%02d:%02d", s_timerMin, s_timerSec);
    sendSetCursor(60, 55); sendSetTextColor(0,255,180);
    sendPrintText(buf);
    sendSetCursor(10, 80); sendSetTextColor(150,150,150);
    sendPrintText("UD=min LR=sec OK=start");
  } else if (s_mode == CM_SET_ALARM) {
    sendSetCursor(10, 30); sendSetTextColor(255,255,255);
    sendPrintText("Set alarm (HH:MM)");
    char buf[12]; snprintf(buf, sizeof(buf), "%02d:%02d", s_alarmHour, s_alarmMin);
    sendSetCursor(60, 55); sendSetTextColor(0,255,180);
    sendPrintText(buf);
    sendSetCursor(10, 80); sendSetTextColor(150,150,150);
    sendPrintText(s_alarmArmed ? "OK=disarm  UD=h LR=m" : "OK=arm  UD=h LR=m");
  }

  if (s_ringing) {
    sendFillRect(0, UI_DISPLAY_HEIGHT - 24, UI_DISPLAY_WIDTH, 24, 200, 30, 30);
    sendSetCursor(20, UI_DISPLAY_HEIGHT - 18); sendSetTextColor(255,255,255);
    sendPrintText("RING! OK = stop");
  } else {
    sendFillRect(0, UI_DISPLAY_HEIGHT - 11, UI_DISPLAY_WIDTH, 11, 0, 30, 40);
    sendSetCursor(2, UI_DISPLAY_HEIGHT - 9); sendSetTextColor(110,110,110);
    sendPrintText("LR=mode OK=sel H=back");
  }
}

// ================================================================
//  ввод
// ================================================================
void clockHandleInput(int encDelta) {
  if (s_ringing) {
    if (bOk.pressed() || bCancel.pressed() || bHome.pressed()) {
      clockAlarmDismiss();
      clockDraw();
    }
    return;
  }

  bool redraw = false;

  if (bLeft.pressed()) {
    if (s_mode == CM_VIEW) s_mode = CM_SET_ALARM;
    else if (s_mode == CM_SET_ALARM) s_mode = CM_SET_TIMER;
    else if (s_mode == CM_SET_TIMER) s_mode = CM_VIEW;
    redraw = true;
  }
  if (bRight.pressed()) {
    if (s_mode == CM_VIEW) s_mode = CM_SET_TIMER;
    else if (s_mode == CM_SET_TIMER) s_mode = CM_SET_ALARM;
    else if (s_mode == CM_SET_ALARM) s_mode = CM_VIEW;
    redraw = true;
  }

  if (s_mode == CM_SET_TIMER) {
    if (bUp.pressed() || bUp.repeat())   { s_timerMin = constrain(s_timerMin + 1, 0, 99); redraw = true; }
    if (bDown.pressed() || bDown.repeat()) { s_timerMin = constrain(s_timerMin - 1, 0, 99); redraw = true; }
    if (encDelta != 0) { s_timerSec = constrain(s_timerSec + encDelta, 0, 59); redraw = true; }
    if (bOk.pressed()) {
      uint32_t now;
      if (netTimeGet(now)) {
        s_timerEndUnix = now + (uint32_t)s_timerMin * 60 + s_timerSec;
        s_timerActive = true; s_timerRang = false;
        s_mode = CM_VIEW;
      }
      redraw = true;
    }
  } else if (s_mode == CM_SET_ALARM) {
    if (bUp.pressed() || bUp.repeat())   { s_alarmHour = (s_alarmHour + 1) % 24; redraw = true; }
    if (bDown.pressed() || bDown.repeat()) { s_alarmHour = (s_alarmHour + 23) % 24; redraw = true; }
    if (encDelta != 0) { s_alarmMin = ((s_alarmMin + encDelta) % 60 + 60) % 60; redraw = true; }
    if (bOk.pressed()) {
      s_alarmArmed = !s_alarmArmed;
      s_alarmFiredToday = false;
      s_mode = CM_VIEW;
      redraw = true;
    }
  } else if (s_mode == CM_VIEW) {
    if (bOk.pressed() && s_timerActive) { // досрочно остановить таймер
      s_timerActive = false; redraw = true;
    }
  }

  if (bHome.pressed() || bCancel.pressed()) {
    // выход из под-режимов в обзор, либо наверх в главное меню (решает .ino)
    if (s_mode != CM_VIEW) { s_mode = CM_VIEW; redraw = true; }
  }

  if (redraw) clockDraw();
}

// ================================================================
//  фоновая проверка будильника/таймера - звать из loop() ВСЕГДА,
//  независимо от текущего экрана.
// ================================================================
bool clockTickAlarm() {
  static unsigned long lastCheck = 0;
  if (millis() - lastCheck < 1000) return false;
  lastCheck = millis();

  uint32_t now32;
  if (!netTimeGet(now32)) return false;

  // таймер
  if (s_timerActive && !s_timerRang && (long)now32 >= (long)s_timerEndUnix) {
    s_timerRang = true;
    s_ringing = true;
    return true;
  }

  // будильник (сравниваем час:мин текущего UTC-времени; сутки определяем
  // по числу дней с эпохи, чтобы сработать не больше раза в день)
  if (s_alarmArmed) {
    long daysSinceEpoch = (long)(now32 / 86400UL);
    long secOfDay = (long)(now32 % 86400UL);
    int curH = secOfDay / 3600;
    int curM = (secOfDay % 3600) / 60;
    if (curH == s_alarmHour && curM == s_alarmMin) {
      if (s_lastAlarmCheckDay != daysSinceEpoch) {
        s_lastAlarmCheckDay = daysSinceEpoch;
        s_alarmFiredToday = true;
        s_ringing = true;
        return true;
      }
    }
  }
  return false;
}
