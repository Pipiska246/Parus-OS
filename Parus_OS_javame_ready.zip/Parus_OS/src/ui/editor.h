#pragma once
#include <Arduino.h>

// ================================================================
//  editor.h — minimal nano-like text editor over the VFS, driven by
//  the on-screen keyboard (or a USB keyboard if one's plugged in).
// ================================================================

// Loads `path` (creates it as empty if it doesn't exist yet) and
// resets cursor/scroll state. Call when entering STATE_EDITOR.
void editorOpen(const String &path);

// Feed one committed character/action, same convention as
// terminalFeedChar(): '\n' = insert newline, 0x08 = backspace,
// anything else printable is inserted at the cursor.
// Returns true if the screen should be redrawn.
bool editorFeedChar(char c);

bool editorMoveCursor(int dCol, int dLine);

// Writes the buffer back to the VFS path it was opened with.
bool editorSave();

// Renders the buffer (with cursor) into the area above the keyboard
// panel; `height` is the total screen height available to the editor
// (header + text + footer), same convention as terminalDraw().
void editorDraw(int height);

String editorCurrentPath();
bool   editorIsDirty();
