#include "editor.h"
#include "../core/ui_common.h"
#include "../vfs/vfs.h"
#include <vector>

#define EDITOR_MAX_LINES   400
#define EDITOR_LINE_MAX    120

static std::vector<String> s_lines;
static String s_path;
static int s_curLine = 0, s_curCol = 0;
static int s_scrollLine = 0;
static bool s_dirty = false;

String editorCurrentPath() { return s_path; }
bool   editorIsDirty()     { return s_dirty; }

void editorOpen(const String &path) {
  s_path = path;
  s_lines.clear();
  s_curLine = 0; s_curCol = 0; s_scrollLine = 0; s_dirty = false;

  VfsFile f;
  if (vfsExists(path) && f.openRead(path)) {
    String line; uint8_t b;
    while (f.read(&b, 1) == 1 && (int)s_lines.size() < EDITOR_MAX_LINES) {
      if (b == '\r') continue;
      if (b == '\n') { s_lines.push_back(line); line = ""; }
      else if (line.length() < EDITOR_LINE_MAX) line += (char)b;
    }
    if (line.length() || s_lines.empty()) s_lines.push_back(line);
    f.close();
  }
  if (s_lines.empty()) s_lines.push_back("");
}

bool editorSave() {
  VfsFile f;
  if (!f.openWrite(s_path, false)) return false;
  for (size_t i = 0; i < s_lines.size(); i++) {
    f.write((const uint8_t *)s_lines[i].c_str(), s_lines[i].length());
    f.write((const uint8_t *)"\n", 1);
  }
  f.close();
  s_dirty = false;
  return true;
}

bool editorFeedChar(char c) {
  String &line = s_lines[s_curLine];

  if (c == '\n' || c == '\r') {
    if ((int)s_lines.size() >= EDITOR_MAX_LINES) return false;
    String tail = line.substring(s_curCol);
    line.remove(s_curCol);
    s_lines.insert(s_lines.begin() + s_curLine + 1, tail);
    s_curLine++; s_curCol = 0; s_dirty = true;
    return true;
  }
  if (c == 0x08 || c == 0x7F) { // backspace
    if (s_curCol > 0) { line.remove(s_curCol - 1, 1); s_curCol--; s_dirty = true; return true; }
    if (s_curLine > 0) {
      int prevLen = s_lines[s_curLine - 1].length();
      s_lines[s_curLine - 1] += line;
      s_lines.erase(s_lines.begin() + s_curLine);
      s_curLine--; s_curCol = prevLen; s_dirty = true;
      return true;
    }
    return false;
  }
  if ((uint8_t)c < 0x20) return false;
  if ((int)line.length() >= EDITOR_LINE_MAX) return false;
  line = line.substring(0, s_curCol) + String(c) + line.substring(s_curCol);
  s_curCol++; s_dirty = true;
  return true;
}

bool editorMoveCursor(int dCol, int dLine) {
  bool changed = false;
  if (dLine != 0) {
    int nl = constrain(s_curLine + dLine, 0, (int)s_lines.size() - 1);
    if (nl != s_curLine) { s_curLine = nl; s_curCol = min(s_curCol, (int)s_lines[s_curLine].length()); changed = true; }
  }
  if (dCol != 0) {
    int nc = s_curCol + dCol;
    if (nc < 0) {
      if (s_curLine > 0) { s_curLine--; s_curCol = s_lines[s_curLine].length(); changed = true; }
    } else if (nc > (int)s_lines[s_curLine].length()) {
      if (s_curLine < (int)s_lines.size() - 1) { s_curLine++; s_curCol = 0; changed = true; }
    } else { s_curCol = nc; changed = true; }
  }
  return changed;
}

void editorDraw(int height) {
  int yTop = UI_LINE_H;
  sendFillRect(0, yTop, UI_DISPLAY_WIDTH, height - yTop, 0, 0, 0);

  int visible = (height - yTop) / UI_LINE_H;
  if (visible < 1) visible = 1;
  if (s_curLine < s_scrollLine) s_scrollLine = s_curLine;
  if (s_curLine >= s_scrollLine + visible) s_scrollLine = s_curLine - visible + 1;

  int maxCh = UI_DISPLAY_WIDTH / UI_CHAR_W;
  sendSetTextColor(220, 220, 220);
  for (int i = 0; i < visible && (s_scrollLine + i) < (int)s_lines.size(); i++) {
    int li = s_scrollLine + i;
    String text = s_lines[li];
    if ((int)text.length() > maxCh) text = text.substring(0, maxCh);
    sendSetCursor(2, yTop + i * UI_LINE_H);
    sendPrintStr(text);
    if (li == s_curLine) {
      int cx = 2 + min(s_curCol, maxCh - 1) * UI_CHAR_W;
      sendSetCursor(cx, yTop + i * UI_LINE_H);
      sendSetTextColor(0, 255, 0);
      sendPrintText("_");
      sendSetTextColor(220, 220, 220);
    }
  }
}
