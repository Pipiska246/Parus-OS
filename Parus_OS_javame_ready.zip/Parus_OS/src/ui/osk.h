#pragma once
#include <Arduino.h>

// ================================================================
//  osk.h — on-screen keyboard, navigated entirely with the existing
//  7 buttons + encoder (no touchscreen, no USB keyboard required).
//
//  UP/DOWN/LEFT/RIGHT move the highlighted key in a grid; OK presses
//  the highlighted key. Most keys just insert a character, but a few
//  are "action" keys (space, backspace, arrows that move the
//  *caller's* text cursor, enter, save, esc) - exactly like the
//  arrow/enter/esc keys on a real keyboard are still just keys.
//
//  This widget owns no text buffer itself - it just reports which
//  key was pressed each tick; the caller (terminal.cpp / editor.cpp)
//  decides what that means for its own line/cursor state.
// ================================================================

enum OskAction {
  OSK_NONE,
  OSK_CHAR,       // ev.ch holds the printable character to insert
  OSK_SPACE,
  OSK_BACKSPACE,
  OSK_LEFT, OSK_RIGHT,   // move caller's cursor within the current line
  OSK_UP, OSK_DOWN,      // move caller's cursor to prev/next line (editor only)
  OSK_ENTER,             // run command (terminal) / insert newline (editor)
  OSK_SAVE,              // save & exit (editor only)
  OSK_ESC                // cancel / exit screen
};

struct OskEvent {
  OskAction action;
  char      ch;
};

// editorMode=true adds the UP/DOWN-line and SAVE keys to the action
// row; the plain terminal keyboard omits them (it has no concept of
// "lines").
void oskInit(bool editorMode);

// Call once per loop() tick, after updateButtons()/readEncoderDelta()
// have run. Returns an event with action==OSK_NONE on most ticks.
// *movedOut is set true whenever the highlighted key changed (so the
// caller knows to redraw the keyboard panel even with no committed
// character/action).
OskEvent oskHandleInput(bool *movedOut);

// Draws the keyboard grid (highlighted selection + key labels) into
// the bottom `height` pixels of the screen, starting at y = yTop.
void oskDraw(int yTop, int height);
