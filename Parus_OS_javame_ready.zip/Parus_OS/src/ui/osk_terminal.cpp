#include "osk_terminal.h"
#include "../core/ui_common.h"
#include <string.h>

// ================================================================
//  Данные клавиатуры
// ================================================================

// Страница 1: Буквы
static const OskKey PAGE_LETTERS[] = {
  {'q', "q", false}, {'w', "w", false}, {'e', "e", false}, {'r', "r", false}, {'t', "t", false},
  {'y', "y", false}, {'u', "u", false}, {'i', "i", false}, {'o', "o", false}, {'p', "p", false},
  {'a', "a", false}, {'s', "s", false}, {'d', "d", false}, {'f', "f", false}, {'g', "g", false},
  {'h', "h", false}, {'j', "j", false}, {'k', "k", false}, {'l', "l", false},
  {'z', "z", false}, {'x', "x", false}, {'c', "c", false}, {'v', "v", false},
  {'b', "b", false}, {'n', "n", false}, {'m', "m", false},
  {0, "Bksp", true}, {0, "Enter", true}, {0, "Space", true}, {0, "Shft", true}, {0, "Page>", true}
};

// Страница 2: Цифры и основные символы
static const OskKey PAGE_NUMBERS[] = {
  {'1', "1", false}, {'2', "2", false}, {'3', "3", false}, {'4', "4", false}, {'5', "5", false},
  {'6', "6", false}, {'7', "7", false}, {'8', "8", false}, {'9', "9", false}, {'0', "0", false},
  {'!', "!", false}, {'@', "@", false}, {'#', "#", false}, {'$', "$", false}, {'%', "%", false},
  {'^', "^", false}, {'&', "&", false}, {'*', "*", false}, {'(', "(", false}, {')', ")", false},
  {'-', "-", false}, {'_', "_", false}, {'+', "+", false}, {'=', "=", false},
  {0, "Bksp", true}, {0, "Enter", true}, {0, "Space", true}, {0, "Page>", true}
};

// Страница 3: Специальные символы
static const OskKey PAGE_SYMBOLS[] = {
  {'`', "`", false}, {'~', "~", false}, {'|', "|", false}, {'\\', "\\", false}, {'/', "/", false},
  {'?', "?", false}, {'.', ".", false}, {',', ",", false}, {';', ";", false}, {':', ":", false},
  {'\'', "'", false}, {'"', "\"", false}, {'[', "[", false}, {']', "]", false}, {'{', "{", false},
  {'}', "}", false}, {'<', "<", false}, {'>', ">", false},
  {0, "Bksp", true}, {0, "Enter", true}, {0, "Space", true}, {0, "Page>", true}
};

// Страница 4: Управление
static const OskKey PAGE_ARROWS[] = {
  {0, "  ↑  ", true}, {0, "  ←  ", true}, {0, "  ↓  ", true}, {0, "  →  ", true},
  {0, "Home", true}, {0, "End", true}, {0, "Tab", true}, {0, "Esc", true},
  {0, "Clear", true}, {0, "Help", true}, {0, "Page>", true}, {0, "<Page", true}
};

static const OskKey* PAGES[OSK_PAGE_COUNT] = {
  PAGE_LETTERS, PAGE_NUMBERS, PAGE_SYMBOLS, PAGE_ARROWS
};

static const int PAGE_SIZES[OSK_PAGE_COUNT] = {
  sizeof(PAGE_LETTERS) / sizeof(OskKey),
  sizeof(PAGE_NUMBERS) / sizeof(OskKey),
  sizeof(PAGE_SYMBOLS) / sizeof(OskKey),
  sizeof(PAGE_ARROWS) / sizeof(OskKey)
};

static const char* PAGE_NAMES[OSK_PAGE_COUNT] = {
  "ABC", "123", "#+=", "⇱⇱"
};

// ================================================================
//  Состояние клавиатуры
// ================================================================
static bool s_visible = false;
static OskPage s_currentPage = OSK_PAGE_LETTERS;
static int s_selectedRow = 0;
static int s_selectedCol = 0;
static char s_lastChar = 0;
static bool s_hasChar = false;
static bool s_shift = false;

// Количество строк и столбцов
#define OSK_ROWS 4
#define OSK_COLS 8
#define OSK_KEY_W  (UI_DISPLAY_WIDTH / OSK_COLS)
#define OSK_KEY_H  12
#define OSK_TOP_Y  25

// ================================================================
//  Функции
// ================================================================

void oskTerminalInit() {
  s_visible = false;
  s_currentPage = OSK_PAGE_LETTERS;
  s_selectedRow = 0;
  s_selectedCol = 0;
  s_hasChar = false;
  s_lastChar = 0;
  s_shift = false;
}

void oskTerminalShow() {
  s_visible = true;
  s_selectedRow = 0;
  s_selectedCol = 0;
  oskTerminalDraw();
}

void oskTerminalHide() {
  s_visible = false;
  s_hasChar = false;
}

bool oskTerminalIsVisible() {
  return s_visible;
}

bool oskTerminalHasChar() {
  return s_hasChar;
}

char oskTerminalGetChar() {
  if (s_hasChar) {
    s_hasChar = false;
    return s_lastChar;
  }
  return 0;
}

void oskTerminalNextPage() {
  s_currentPage = (OskPage)((s_currentPage + 1) % OSK_PAGE_COUNT);
  s_selectedRow = 0;
  s_selectedCol = 0;
  if (s_visible) oskTerminalDraw();
}

void oskTerminalPrevPage() {
  s_currentPage = (OskPage)((s_currentPage + OSK_PAGE_COUNT - 1) % OSK_PAGE_COUNT);
  s_selectedRow = 0;
  s_selectedCol = 0;
  if (s_visible) oskTerminalDraw();
}

OskPage oskTerminalGetPage() {
  return s_currentPage;
}

const char* oskTerminalGetPageName() {
  return PAGE_NAMES[s_currentPage];
}

static const OskKey* getKey(int row, int col, int &actualRow) {
  const OskKey* page = PAGES[s_currentPage];
  int size = PAGE_SIZES[s_currentPage];
  
  int keysPerRow = OSK_COLS;
  int totalRows = (size + keysPerRow - 1) / keysPerRow;
  
  if (row >= totalRows) {
    actualRow = -1;
    return nullptr;
  }
  
  int idx = row * keysPerRow + col;
  if (idx >= size) {
    actualRow = -1;
    return nullptr;
  }
  
  actualRow = row;
  return &page[idx];
}

void oskTerminalProcess() {
  if (!s_visible) return;
  
  bool redraw = false;
  int totalKeys = PAGE_SIZES[s_currentPage];
  int keysPerRow = OSK_COLS;
  int totalRows = (totalKeys + keysPerRow - 1) / keysPerRow;
  
  // Навигация
  if (bUp.pressed()) {
    if (s_selectedRow > 0) { s_selectedRow--; redraw = true; }
  }
  if (bDown.pressed()) {
    if (s_selectedRow < totalRows - 1) { s_selectedRow++; redraw = true; }
  }
  if (bLeft.pressed()) {
    if (s_selectedCol > 0) { s_selectedCol--; redraw = true; }
    else if (s_selectedRow > 0) { s_selectedRow--; s_selectedCol = OSK_COLS - 1; redraw = true; }
  }
  if (bRight.pressed()) {
    int maxCol = OSK_COLS - 1;
    int lastRowKeys = totalKeys - s_selectedRow * OSK_COLS;
    if (s_selectedRow == totalRows - 1) {
      maxCol = lastRowKeys - 1;
    }
    if (s_selectedCol < maxCol) { s_selectedCol++; redraw = true; }
    else if (s_selectedRow < totalRows - 1) { s_selectedRow++; s_selectedCol = 0; redraw = true; }
  }
  
  int enc = readEncoderDelta();
  if (enc != 0) {
    int total = totalKeys;
    int flat = s_selectedRow * OSK_COLS + s_selectedCol;
    flat = (flat + enc + total) % total;
    s_selectedRow = flat / OSK_COLS;
    s_selectedCol = flat % OSK_COLS;
    int lastRowKeys = totalKeys - s_selectedRow * OSK_COLS;
    if (s_selectedRow == totalRows - 1 && s_selectedCol >= lastRowKeys) {
      s_selectedCol = lastRowKeys - 1;
    }
    redraw = true;
  }
  
  if (redraw) {
    oskTerminalDraw();
  }
  
  // Выбор клавиши
  if (bOk.pressed()) {
    const OskKey* key = nullptr;
    
    int idx = s_selectedRow * OSK_COLS + s_selectedCol;
    if (idx < totalKeys) {
      key = &PAGES[s_currentPage][idx];
    }
    
    if (key) {
      if (key->special) {
        const char* label = key->label;
        if (strcmp(label, "Bksp") == 0) {
          s_lastChar = 0x08;
          s_hasChar = true;
        } else if (strcmp(label, "Enter") == 0) {
          s_lastChar = '\n';
          s_hasChar = true;
        } else if (strcmp(label, "Space") == 0) {
          s_lastChar = ' ';
          s_hasChar = true;
        } else if (strcmp(label, "Shft") == 0) {
          s_shift = !s_shift;
          redraw = true;
        } else if (strcmp(label, "Page>") == 0) {
          oskTerminalNextPage();
          return;
        } else if (strcmp(label, "<Page") == 0) {
          oskTerminalPrevPage();
          return;
        } else if (strcmp(label, "  ↑  ") == 0) {
          s_lastChar = 0x01;
          s_hasChar = true;
        } else if (strcmp(label, "  ↓  ") == 0) {
          s_lastChar = 0x02;
          s_hasChar = true;
        } else if (strcmp(label, "  ←  ") == 0) {
          s_lastChar = 0x03;
          s_hasChar = true;
        } else if (strcmp(label, "  →  ") == 0) {
          s_lastChar = 0x04;
          s_hasChar = true;
        } else if (strcmp(label, "Home") == 0) {
          s_lastChar = 0x05;
          s_hasChar = true;
        } else if (strcmp(label, "End") == 0) {
          s_lastChar = 0x06;
          s_hasChar = true;
        } else if (strcmp(label, "Tab") == 0) {
          s_lastChar = '\t';
          s_hasChar = true;
        } else if (strcmp(label, "Esc") == 0) {
          s_lastChar = 0x1B;
          s_hasChar = true;
        } else if (strcmp(label, "Clear") == 0) {
          s_lastChar = 0x0C;
          s_hasChar = true;
        } else if (strcmp(label, "Help") == 0) {
          s_lastChar = '?';
          s_hasChar = true;
        }
      } else {
        char ch = key->ch;
        if (s_shift && ch >= 'a' && ch <= 'z') {
          ch = ch - 'a' + 'A';
        }
        s_lastChar = ch;
        s_hasChar = true;
        if (s_shift) {
          s_shift = false;
          redraw = true;
        }
      }
      
      if (redraw && s_visible) {
        oskTerminalDraw();
      }
    }
  }
  
  if (bCancel.pressed() || bHome.pressed()) {
    oskTerminalHide();
  }
}

void oskTerminalDraw() {
  if (!s_visible) return;
  
  const OskKey* page = PAGES[s_currentPage];
  int size = PAGE_SIZES[s_currentPage];
  
  // Затемняем фон под клавиатурой
  sendFillRect(0, OSK_TOP_Y - 5, UI_DISPLAY_WIDTH, OSK_ROWS * OSK_KEY_H + 10, 0, 0, 40);
  delay(5);
  
  // Рисуем рамку клавиатуры
  sendDrawRect(0, OSK_TOP_Y - 5, UI_DISPLAY_WIDTH, OSK_ROWS * OSK_KEY_H + 10, 100, 100, 200);
  delay(5);
  
  // Очищаем область клавиатуры
  sendFillRect(1, OSK_TOP_Y - 4, UI_DISPLAY_WIDTH - 2, OSK_ROWS * OSK_KEY_H + 8, 0, 0, 50);
  delay(10);
  
  // Рисуем заголовок
  sendFillRect(0, OSK_TOP_Y, UI_DISPLAY_WIDTH, 10, 10, 10, 40);
  delay(5);
  
  sendSetCursor(2, OSK_TOP_Y + 1);
  sendSetTextColor(200, 200, 255);
  String title = "OSK: ";
  title += PAGE_NAMES[s_currentPage];
  if (s_shift) title += " [Shift]";
  sendPrintText(title.c_str());
  delay(5);
  
  int startY = OSK_TOP_Y + 10;
  int keysPerRow = OSK_COLS;
  
  // Рисуем клавиши с задержкой
  for (int i = 0; i < size; i++) {
    int row = i / keysPerRow;
    int col = i % keysPerRow;
    int x = col * OSK_KEY_W;
    int y = startY + row * OSK_KEY_H;
    bool selected = (row == s_selectedRow && col == s_selectedCol);
    
    const OskKey& key = page[i];
    
    // Рисуем фон клавиши
    if (selected) {
      sendFillRect(x + 1, y + 1, OSK_KEY_W - 2, OSK_KEY_H - 2, 0, 120, 80);
      delay(3);
      sendDrawRect(x, y, OSK_KEY_W, OSK_KEY_H, 255, 255, 100);
      delay(3);
      sendSetTextColor(255, 255, 255);
    } else {
      if (key.special) {
        sendFillRect(x + 1, y + 1, OSK_KEY_W - 2, OSK_KEY_H - 2, 40, 30, 60);
        delay(3);
        sendDrawRect(x, y, OSK_KEY_W, OSK_KEY_H, 150, 100, 150);
        delay(3);
        sendSetTextColor(200, 200, 255);
      } else {
        sendFillRect(x + 1, y + 1, OSK_KEY_W - 2, OSK_KEY_H - 2, 20, 30, 50);
        delay(3);
        sendDrawRect(x, y, OSK_KEY_W, OSK_KEY_H, 100, 150, 200);
        delay(3);
        sendSetTextColor(200, 220, 255);
      }
    }
    
    // Текст на клавише
    const char* label = key.label;
    int textLen = strlen(label);
    int textX = x + (OSK_KEY_W - textLen * UI_CHAR_W) / 2;
    int textY = y + (OSK_KEY_H - UI_CHAR_H) / 2;
    sendSetCursor(textX, textY);
    delay(2);
    
    if (strcmp(label, "Shft") == 0 && s_shift) {
      sendSetTextColor(255, 255, 0);
    }
    sendPrintText(label);
    delay(2);

  }
}