#pragma once
#include <Arduino.h>
#include <vector>

// ================================================================
//  On-Screen Keyboard for Terminal
//  Многостраничная экранная клавиатура
// ================================================================

// Страницы клавиатуры
enum OskPage {
    OSK_PAGE_LETTERS,    // буквы
    OSK_PAGE_NUMBERS,    // цифры и основные символы
    OSK_PAGE_SYMBOLS,    // специальные символы
    OSK_PAGE_ARROWS,     // стрелки и управление
    OSK_PAGE_COUNT
};

// Структура клавиши
struct OskKey {
    char ch;            // символ (0 для специальных)
    const char* label;  // текст на кнопке
    bool special;       // специальная клавиша (Enter, Backspace, etc)
};

// Инициализация
void oskTerminalInit();

// Показать/скрыть клавиатуру
void oskTerminalShow();
void oskTerminalHide();
bool oskTerminalIsVisible();

// Обработка ввода
void oskTerminalProcess();

// Отрисовка клавиатуры
void oskTerminalDraw();

// Получить последний введённый символ
char oskTerminalGetChar();

// Переключить страницу
void oskTerminalNextPage();
void oskTerminalPrevPage();

// Получить текущую страницу
OskPage oskTerminalGetPage();
const char* oskTerminalGetPageName();
bool oskTerminalHasChar();