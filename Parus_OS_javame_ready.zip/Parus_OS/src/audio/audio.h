#pragma once
// ================================================================
//  audio.h — glitch-free music engine
//
//  Replaces the old "loop1() bit-banging one sample at a time from
//  the VFS file" design. The problem with that design: a single
//  VfsFile::read() against a USB-MSC/FAT partition can block for
//  several milliseconds (sector read, FAT lookup, USB transfer...).
//  When that blocking read happened *inside* the precisely-timed
//  per-sample loop, it stalled the PWM output for exactly as long as
//  the disk needed - audible stutter every time the song read across
//  a sector/cluster boundary.
//
//  New design (classic producer/consumer):
//
//    [FreeRTOS task: audioProducerTask, core1]
//         reads/decodes the file in ~KB-sized chunks (WAV/raw PCM
//         directly, MP3 via arduino-libhelix) and pushes decoded
//         mono 16-bit PCM samples into a lock-free ring buffer.
//         It is allowed to block on slow storage - that's fine,
//         it just refills the buffer a bit later.
//                          |
//                          v
//                 [ring buffer, ~8192 samples ]
//                          |
//                          v
//    [hardware repeating_timer ISR, runs on whichever core armed it]
//         fires at the exact sample rate (independent of any task
//         scheduling/storage latency), pops ONE sample and writes it
//         to the PWM peripheral. As long as the buffer isn't empty,
//         output timing is rock solid no matter what core0/core1 are
//         doing.
//
//  Same public surface (function/variable names) as before, so the
//  rest of the sketch (UI, settings, file info, file browser) did
//  not need to change.
// ================================================================

#include <Arduino.h>
#include "../vfs/vfs.h"

// ---- legacy WAV info struct, still used for the "Info" screen ----
struct WavInfo {
  bool     isWav;
  uint32_t dataOffset;
  uint32_t dataSize;
  uint16_t channels;
  uint32_t sampleRate;
  uint16_t bitsPerSample;
};

// Parses a RIFF/WAVE header if present; otherwise treats the file as
// legacy headerless 8-bit raw PCM (kept for the file-info screen).
bool wavParseHeader(VfsFile &f, WavInfo &info);

// One-call probe used by the file-info screen: works for .wav, .mp3
// and legacy headerless .pcm/.raw files.
bool audioProbeFile(const String &path, String &typeOut, String &detailsOut);

// ---- engine lifecycle ----
// Call once from setup(). Sets up the PWM output, the sample-clock
// hardware timer and starts the FreeRTOS producer task (pinned to
// core1 if FreeRTOS SMP is available).
void audioInit();

// Plain-integer stand-in for the audioProducerTask's (core1) FreeRTOS
// task handle: non-zero once audioInit() has run, 0 before that.
// Kept as a uint32_t (not TaskHandle_t) so callers like /proc/audio
// (audio_vfs.h/.cpp) and terminal.cpp don't need to pull in the
// FreeRTOS headers just to display a pid-like number.
uint32_t audioTaskId();

// ---- transport controls (same names/signatures as the old engine) ----
bool startMusic(const String &fullPath);   // returns true once playback has actually started
void stopMusic();
void pauseMusic();
void resumeMusic();

void setVolume(uint8_t volume);
void volumeUp();
void volumeDown();

void setSpeed(float speed);
void speedUp();
void speedDown();

// ---- live status, read directly by the UI (drawMusicPlayer etc.) ----
extern volatile bool musicPlaying;
extern volatile bool musicPaused;
extern bool           autoPlayNext;
extern volatile bool  trackEndedSignal;   // one-shot, cleared by loop() after handling

extern uint32_t musicPosition;     // bytes consumed from the source file so far
extern uint32_t musicTotalSize;    // total bytes in the source file's audio payload
extern String   musicFileNameForUI;

extern uint8_t audioVolume;
extern float   audioSpeed;
extern uint32_t audioSampleRate;   // user-configurable rate for headerless raw PCM (Settings menu)

// Diagnostics (optional - handy if you want to show buffer health
// somewhere, e.g. on the status overlay)
uint32_t audioRingUnderruns();
uint8_t  audioRingFillPercent();
