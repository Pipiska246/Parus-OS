#define __FREERTOS 1
#include "audio.h"
#include "../core/config.h"
#include <string.h>

#include "hardware/pwm.h"
#include "hardware/gpio.h"
#include "hardware/clocks.h"
#include "pico/time.h"

// FreeRTOS (Earle Philhower's RP2040 SMP port)
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>


// VFS mutex is defined in vfs.cpp
extern SemaphoreHandle_t s_vfsMutex;
extern void vfsLockInit();

#ifndef AUDIO_ENABLE_MP3
#define AUDIO_ENABLE_MP3 1
#endif

#if AUDIO_ENABLE_MP3
  #include "MP3DecoderHelix.h"
  using namespace libhelix;
#endif

// ... rest of audio.cpp remains the same ...

// ================================================================
//  Public state (kept as plain globals so the existing UI code -
//  drawMusicPlayer(), drawFileInfo(), the music-player input
//  handler, etc. - doesn't need to change at all)
// ================================================================
volatile bool musicPlaying      = false;
volatile bool musicPaused       = false;
bool          autoPlayNext      = true;
volatile bool trackEndedSignal  = false;

uint32_t musicPosition   = 0;
uint32_t musicTotalSize  = 0;
String   musicFileNameForUI = "";

uint8_t audioVolume = 128;
float   audioSpeed  = 1.0f;

// ================================================================
//  Lock-free SPSC ring buffer of decoded mono 16-bit PCM samples.
//  Producer = audioProducerTask (FreeRTOS task, does the slow VFS/USB
//  reads + decoding). Consumer = hardware timer ISR (the only thing
//  with hard real-time requirements).
// ================================================================
static int16_t        ringBuf[AUDIO_RING_SAMPLES];
static volatile uint32_t ringHead = 0;   // next slot the producer will write
static volatile uint32_t ringTail = 0;   // next slot the consumer will read
#define RING_MASK (AUDIO_RING_SAMPLES - 1)

static inline uint32_t ringCount() { return (ringHead - ringTail) & RING_MASK; }
static inline uint32_t ringFree()  { return (AUDIO_RING_SAMPLES - 1) - ringCount(); }

static void ringReset() { ringHead = 0; ringTail = 0; }

static inline void ringPush(int16_t s) {
  ringBuf[ringHead & RING_MASK] = s;
  ringHead++;
}

static volatile uint32_t g_underruns = 0;
uint32_t audioRingUnderruns() { return g_underruns; }
uint8_t  audioRingFillPercent() { return (uint8_t)((ringCount() * 100UL) / (AUDIO_RING_SAMPLES - 1)); }

// ================================================================
//  PWM output - same 100kHz/8-bit setup as the old analogWrite()
//  based code, but driven with raw pico-sdk calls so the ISR can
//  update it in a couple of instructions (no Arduino-side pin
//  lookup/locking on every sample).
// ================================================================
static uint s_pwmSlice, s_pwmChannel;

static void initAudioPWM() {
  gpio_set_function(AUDIO_PIN, GPIO_FUNC_PWM);
  s_pwmSlice   = pwm_gpio_to_slice_num(AUDIO_PIN);
  s_pwmChannel = pwm_gpio_to_channel(AUDIO_PIN);

  pwm_config cfg = pwm_get_default_config();
  // Reproduces the old analogWriteFreq(100000) + analogWriteRange(256):
  // wrap = 255, clkdiv chosen so wrap*freq == sys_clk.
  float clkdiv = (float)clock_get_hz(clk_sys) / (256.0f * 100000.0f);
  if (clkdiv < 1.0f) clkdiv = 1.0f;
  pwm_config_set_clkdiv(&cfg, clkdiv);
  pwm_config_set_wrap(&cfg, 255);
  pwm_init(s_pwmSlice, &cfg, true);
  pwm_set_chan_level(s_pwmSlice, s_pwmChannel, 0);
}

static inline void writePwm(uint8_t v) {
  pwm_set_chan_level(s_pwmSlice, s_pwmChannel, v);
}

// ================================================================
//  Sample-clock: a hardware repeating_timer fires at exactly the
//  track's sample rate (scaled by playback speed). This is what
//  actually decouples audio timing from storage/decoding latency -
//  even if the producer task stalls for tens of milliseconds on a
//  slow USB read, the ISR just keeps draining whatever is already
//  in the ring buffer at a perfectly steady rate.
// ================================================================
static repeating_timer_t s_timer;
static volatile uint32_t s_intervalUs = 125; // 8kHz default

static bool audioTimerCb(repeating_timer_t *) {
  if (!musicPlaying || musicPaused) {
    writePwm(0);
    return true;
  }
  if (ringCount() == 0) {
    // Buffer underrun (decoder genuinely couldn't keep up - e.g. very
    // slow card). Hold last level rather than clicking to 0.
    g_underruns++;
    return true;
  }
  int16_t s = ringBuf[ringTail & RING_MASK];
  ringTail++;
  uint8_t  pwmVal = (uint8_t)(((int32_t)s + 32768) >> 8);     // 16-bit signed -> 8-bit unsigned
  uint16_t scaled = (uint16_t)pwmVal * audioVolume / 255;
  writePwm((uint8_t)scaled);
  return true;
}

static void startSampleClock(uint32_t intervalUs) {
  if (intervalUs < 10) intervalUs = 10;
  s_intervalUs = intervalUs;
  cancel_repeating_timer(&s_timer);
  // Negative delay = fixed-rate scheduling (next fire computed from the
  // *start* of the previous call, not its end), which is what keeps the
  // sample clock steady regardless of how long the callback itself took.
  add_repeating_timer_us(-(int64_t)s_intervalUs, audioTimerCb, NULL, &s_timer);
}

// ================================================================
//  WAV header parsing (unchanged logic from the old engine)
// ================================================================
static bool wavSkip(VfsFile &f, uint32_t n) {
  uint8_t junk[64];
  while (n) {
    uint32_t c = min((uint32_t)sizeof(junk), n);
    if (f.read(junk, c) != c) return false;
    n -= c;
  }
  return true;
}

bool wavParseHeader(VfsFile &f, WavInfo &info) {
  info.isWav = false; info.dataOffset = 0; info.dataSize = f.size();
  info.channels = 1; info.sampleRate = audioSampleRate; info.bitsPerSample = 8;
  uint8_t hdr[12];
  if (f.read(hdr, 12) != 12) { f.seek(0); return true; }
  if (memcmp(hdr, "RIFF", 4) != 0 || memcmp(hdr + 8, "WAVE", 4) != 0) { f.seek(0); return true; }

  bool gotFmt = false;
  while (true) {
    uint8_t ch[8];
    if (f.read(ch, 8) != 8) return gotFmt;
    uint32_t chunkSize = ch[4] | (ch[5] << 8) | (ch[6] << 16) | ((uint32_t)ch[7] << 24);
    if (memcmp(ch, "fmt ", 4) == 0) {
      uint8_t fmt[16]; uint32_t toRead = min((uint32_t)16, chunkSize);
      if (f.read(fmt, toRead) != toRead) return false;
      info.channels     = fmt[2] | (fmt[3] << 8);
      info.sampleRate    = fmt[4] | (fmt[5] << 8) | (fmt[6] << 16) | ((uint32_t)fmt[7] << 24);
      info.bitsPerSample = fmt[14] | (fmt[15] << 8);
      if (chunkSize > 16) wavSkip(f, chunkSize - 16);
      gotFmt = true;
    } else if (memcmp(ch, "data", 4) == 0) {
      info.dataOffset = f.position();
      info.dataSize    = chunkSize;
      info.isWav = true;
      return gotFmt;
    } else {
      if (!wavSkip(f, chunkSize)) return false;
    }
    if (chunkSize % 2 == 1) wavSkip(f, 1);
  }
}

static bool isMp3Path(const String &path) {
  String n = path; n.toLowerCase();
  return n.endsWith(".mp3");
}

bool audioProbeFile(const String &path, String &typeOut, String &detailsOut) {
  if (isMp3Path(path)) {
    typeOut = "MP3 file";
    detailsOut = "rate/channels auto-detected at playback";
    return true;
  }
  VfsFile af; WavInfo wi;
  if (af.openRead(path) && wavParseHeader(af, wi)) {
    if (wi.isWav) {
      typeOut = "WAV file";
      detailsOut = String(wi.sampleRate) + " Hz, " + String(wi.bitsPerSample) + "-bit, " + String(wi.channels) + "ch";
    } else {
      typeOut = "Audio file";
      detailsOut = "raw PCM, " + String(audioSampleRate) + " Hz";
    }
    af.close();
    return true;
  }
  typeOut = "Audio file";
  detailsOut = "?";
  return false;
}

// ================================================================
//  Producer task state machine
// ================================================================
enum ProducerCmd { CMD_NONE, CMD_START, CMD_STOP };

static volatile ProducerCmd s_cmd = CMD_NONE;
static char     s_cmdPath[200] = "";
static volatile uint32_t s_trackSampleRate = AUDIO_DEFAULT_SAMPLE_RATE;

#if AUDIO_ENABLE_MP3
static MP3DecoderHelix *s_mp3 = nullptr;
static volatile bool s_mp3RateKnown = false;

static void mp3DataCB(MP3FrameInfo &info, short *pcm, size_t len, void * /*ref*/) {
  // Called synchronously from inside mp3->write(), i.e. from the
  // producer task - safe to push straight into the ring buffer.
  if (!s_mp3RateKnown && info.samprate > 0) {
    s_trackSampleRate = info.samprate;
    s_mp3RateKnown = true;
    startSampleClock((uint32_t)((1000000.0 / s_trackSampleRate) / audioSpeed));
  }
  int ch = info.nChans > 0 ? info.nChans : 1;
  size_t frames = (ch >= 2) ? (len / 2) : len;
  for (size_t i = 0; i < frames; i++) {
    int16_t sample;
    if (ch >= 2) sample = (int16_t)(((int32_t)pcm[i * 2] + (int32_t)pcm[i * 2 + 1]) / 2);
    else sample = pcm[i];
    // Block (briefly) rather than drop samples if the ring is full -
    // this naturally throttles the decoder to real playback speed.
    while (ringFree() == 0) { vTaskDelay(pdMS_TO_TICKS(2)); }
    ringPush(sample);
  }
}
#endif

static void producerPlayWav(VfsFile &f, const WavInfo &wav) {
  s_trackSampleRate = wav.isWav ? wav.sampleRate : audioSampleRate;
  startSampleClock((uint32_t)((1000000.0 / s_trackSampleRate) / audioSpeed));

  const size_t CHUNK_FRAMES = 512;
  uint8_t raw[CHUNK_FRAMES * 4]; // worst case: 16-bit stereo

  size_t bytesPerFrame = wav.isWav ? ((wav.bitsPerSample / 8) * max((uint16_t)1, wav.channels)) : 1;
  if (bytesPerFrame == 0) bytesPerFrame = 1;

  while (s_cmd != CMD_STOP) {
    // Throttle ourselves to how much room is actually in the ring -
    // this is what lets a slow VFS/USB read happen *without* affecting
    // sample output: we simply wait here, the ISR keeps draining the
    // buffer at a steady rate regardless.
    while (ringFree() < CHUNK_FRAMES && s_cmd != CMD_STOP) vTaskDelay(pdMS_TO_TICKS(3));
    if (s_cmd == CMD_STOP) break;

    size_t wantBytes = CHUNK_FRAMES * bytesPerFrame;
    size_t got = f.read(raw, wantBytes);
    if (got == 0) break; // EOF

    size_t frames = got / bytesPerFrame;
    musicPosition += got;

    for (size_t i = 0; i < frames; i++) {
      int16_t sample;
      if (wav.isWav && wav.bitsPerSample == 16) {
        int16_t l = *(int16_t *)(raw + i * bytesPerFrame);
        if (wav.channels >= 2) {
          int16_t r = *(int16_t *)(raw + i * bytesPerFrame + 2);
          sample = (int16_t)(((int32_t)l + (int32_t)r) / 2);
        } else sample = l;
      } else {
        // 8-bit WAV PCM or legacy headerless raw 8-bit PCM - both
        // unsigned 8-bit in the common case (matches old behaviour).
        uint8_t v = raw[i * bytesPerFrame];
        sample = (int16_t)(((int32_t)v - 128) << 8);
      }
      ringPush(sample);
    }

    if (musicPosition >= musicTotalSize) break;
  }
}

#if AUDIO_ENABLE_MP3
static void producerPlayMp3(VfsFile &f) {
  s_mp3RateKnown = false;
  s_trackSampleRate = AUDIO_DEFAULT_SAMPLE_RATE;
  startSampleClock((uint32_t)((1000000.0 / s_trackSampleRate) / audioSpeed));

  if (s_mp3 == nullptr) s_mp3 = new MP3DecoderHelix(mp3DataCB);
  s_mp3->begin();

  uint8_t buf[1024];
  while (s_cmd != CMD_STOP) {
    size_t got = f.read(buf, sizeof(buf));
    if (got == 0) break; // EOF
    musicPosition += got;
    s_mp3->write(buf, got);   // may call mp3DataCB(...) zero or more times
    if (musicPosition >= musicTotalSize) break;
  }
  s_mp3->end();
}
#endif

static void audioProducerTask(void *) {
  VfsFile f;
  for (;;) {
    // Wait for a start command.
    while (s_cmd != CMD_START) {
      vTaskDelay(pdMS_TO_TICKS(5));
    }
    s_cmd = CMD_NONE;

    String path(s_cmdPath);
    ringReset();
    musicPosition = 0;
    g_underruns = 0;

    if (!f.openRead(path)) {
      musicPlaying = false;
      continue;
    }

    bool isMp3 = isMp3Path(path);
    musicTotalSize = f.size();

    String nameOnly = path;
    int slash = nameOnly.lastIndexOf('/');
    if (slash >= 0) nameOnly = nameOnly.substring(slash + 1);
    musicFileNameForUI = nameOnly;

    musicPlaying = true;
    musicPaused  = false;

    if (isMp3) {
#if AUDIO_ENABLE_MP3
      producerPlayMp3(f);
#else
      // MP3 support not compiled in - bail out gracefully.
#endif
    } else {
      WavInfo wav;
      if (wavParseHeader(f, wav)) {
        musicTotalSize = wav.dataSize;
        producerPlayWav(f, wav);
      }
    }

    f.close();

    // Let the ring buffer fully drain before declaring the track over,
    // so the last fraction of a second of audio actually plays out.
    while (ringCount() > 0 && s_cmd != CMD_STOP) vTaskDelay(pdMS_TO_TICKS(5));

    musicPlaying = false;
    musicPaused  = false;
    if (s_cmd != CMD_STOP) trackEndedSignal = true;
    s_cmd = CMD_NONE;
  }
}

// ================================================================
//  Public API
// ================================================================
static TaskHandle_t s_audioTaskHandle = nullptr;

void audioInit() {
  initAudioPWM();
  startSampleClock(s_intervalUs);

  TaskHandle_t h = nullptr;
  xTaskCreate(audioProducerTask, "audioProducer", 4096, NULL, 3, &h);
  s_audioTaskHandle = h;
#if configNUM_CORES > 1
  if (h) {
    // Keep the decoder off core0 so it never competes with button
    // polling / UART-to-display traffic / USB-host servicing for CPU.
    vTaskCoreAffinitySet(h, (1 << 1));
  }
#endif
}

// Exposes the producer task's handle so /proc/audio/pid can report it -
// audio playback really is its own background "process" (see README);
// this just lets that process be inspected through a file instead of
// a global variable only the .ino could see.
uint32_t audioTaskId() {
  return (uint32_t)(uintptr_t)s_audioTaskHandle;
}

bool startMusic(const String &fullPath) {
  // Ask any currently-playing track to stop first, and wait for the
  // producer to actually acknowledge it before starting the new one.
  if (musicPlaying) {
    s_cmd = CMD_STOP;
    unsigned long t = millis();
    while (musicPlaying && millis() - t < 500) delay(2);
  }
  strncpy(s_cmdPath, fullPath.c_str(), sizeof(s_cmdPath) - 1);
  s_cmdPath[sizeof(s_cmdPath) - 1] = 0;
  trackEndedSignal = false;
  s_cmd = CMD_START;

  unsigned long t = millis();
  while (!musicPlaying && millis() - t < 500) delay(2);
  return musicPlaying;
}

void stopMusic() {
  if (!musicPlaying) return;
  s_cmd = CMD_STOP;
  unsigned long t = millis();
  while (musicPlaying && millis() - t < 500) delay(2);
  trackEndedSignal = false;
}

void pauseMusic()  { if (musicPlaying) musicPaused = true; }
void resumeMusic() { if (musicPlaying && musicPaused) musicPaused = false; }

void setVolume(uint8_t volume) { audioVolume = volume; }
void volumeUp()   { if (audioVolume < 235) audioVolume += 20; else audioVolume = 255; }
void volumeDown() { if (audioVolume > 20)  audioVolume -= 20; else audioVolume = 0; }

void setSpeed(float speed) {
  if (speed < 0.5f) speed = 0.5f;
  if (speed > 2.0f) speed = 2.0f;
  audioSpeed = speed;
  uint32_t rate = s_trackSampleRate ? s_trackSampleRate : AUDIO_DEFAULT_SAMPLE_RATE;
  startSampleClock((uint32_t)((1000000.0 / rate) / audioSpeed));
}
void speedUp()   { setSpeed(audioSpeed + 0.1f); }
void speedDown() { setSpeed(audioSpeed - 0.1f); }
