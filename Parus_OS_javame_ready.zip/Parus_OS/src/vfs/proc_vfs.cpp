#include "proc_vfs.h"
#include "audio_vfs.h"
#include "mount.h"
#include "../javame/jvm.h"

static const char* kProcTopEntries[] = { "mounts", "uptime", "version", "audio", "jvm" };
#define PROC_TOP_NENTRIES (sizeof(kProcTopEntries) / sizeof(kProcTopEntries[0]))

bool procVfsExists(const String &path) {
  if (path == "/proc") return true;
  if (path == "/proc/mounts")  return true;
  if (path == "/proc/uptime")  return true;
  if (path == "/proc/version") return true;
  if (path == "/proc/jvm") return true;
  if (path == "/proc/audio" || path.startsWith("/proc/audio/")) return audioVfsExists(path);
  return false;
}

bool procVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path == "/proc") {
    for (size_t i = 0; i < PROC_TOP_NENTRIES; i++) {
      bool isDir = (String(kProcTopEntries[i]) == "audio");
      out.push_back({String(kProcTopEntries[i]), isDir, 0});
    }
    return true;
  }
  if (path == "/proc/audio") return audioVfsListDir(path, out);
  return false;
}

bool procVfsIsDir(const String &path) {
  if (path == "/proc") return true;
  if (path == "/proc/audio") return true;
  return false;
}

bool procVfsRemove(const String &path) {
  (void)path;
  return false; // /proc - только для чтения/управления, нечего удалять
}

uint32_t procVfsFileSize(const String &path) {
  if (path.startsWith("/proc/audio/")) return audioVfsFileSize(path);
  return 0;
}

bool procVfsReadFile(const String &path, String &content) {
  if (path == "/proc/mounts") {
    content = mountProcMounts();
    return true;
  }
  if (path == "/proc/uptime") {
    content = String(millis() / 1000.0, 2);
    return true;
  }
  if (path == "/proc/version") {
    content = "Parus OS 1.2 (Bash 0.0.3, Turbine 0.0.1)";
    return true;
  }
  if (path == "/proc/jvm") {
    content = jvmStatusLine();
    return true;
  }
  if (path.startsWith("/proc/audio/")) return audioVfsReadFile(path, content);
  return false;
}

bool procVfsWriteFile(const String &path, const String &content) {
  if (path.startsWith("/proc/audio/")) return audioVfsWriteFile(path, content);
  return false; // mounts/uptime/version — только для чтения
}

void procVfsInit() {
  audioVfsInit();
}
