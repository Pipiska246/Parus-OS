#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  input_vfs.h — /dev/input/buttons, /dev/input/keyboard
//
//  The 7 physical buttons + rotary encoder (buttons.h) and the
//  keyboard input paths (osk.h button-driven on-screen keyboard,
//  keyboard_hid.h USB HID keyboard) were only readable from inside
//  C++ (bUp.state, hidKeyboardConnected(), ...). This gives both a
//  file-based front door too, consistent with /dev/gpio, /dev/display
//  and /dev/serial (gpio_vfs.h / devices_vfs.h):
//
//      /dev/input/buttons/up       (r) "0"/"1" - currently held?
//      /dev/input/buttons/down     (r)
//      /dev/input/buttons/left     (r)
//      /dev/input/buttons/right    (r)
//      /dev/input/buttons/ok       (r)
//      /dev/input/buttons/home     (r)
//      /dev/input/buttons/cancel   (r)
//      /dev/input/buttons/enc_btn  (r) - encoder push-button
//
//  (Encoder *rotation* isn't exposed here: readEncoderDelta() is a
//  consuming read used every loop() tick by the active screen: a
//  second consumer via a file would steal ticks from whichever menu
//  is on-screen. The push-button state is a plain level, so it's
//  safe to mirror.)
//
//      /dev/input/keyboard/connected (r) "0"/"1" - USB HID kbd present
//      /dev/input/keyboard/last      (r) last decoded key, e.g. "char:a",
//                                        "enter", "backspace", "esc", ...
//                                        (non-consuming peek, see
//                                        keyboard_hid.h hidKeyboardLastEvent())
// ================================================================

bool     inputVfsExists(const String &path);
bool     inputVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     inputVfsIsDir(const String &path);
bool     inputVfsRemove(const String &path);
uint32_t inputVfsFileSize(const String &path);
bool     inputVfsReadFile(const String &path, String &content);
bool     inputVfsWriteFile(const String &path, const String &content);

void inputVfsInit();
