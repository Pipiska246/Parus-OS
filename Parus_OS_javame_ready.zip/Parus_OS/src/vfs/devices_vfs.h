#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  Devices Virtual Filesystem
//  /dev/display/      - управление экраном
//  /dev/serial/       - управление последовательным портом
// ================================================================

// ---- Функции отображения (объявлены в .ino) ----
extern void sendFillScreen(uint8_t r, uint8_t g, uint8_t b);
extern void sendSetCursor(uint16_t x, uint16_t y);
extern void sendSetTextColor(uint8_t r, uint8_t g, uint8_t b);
extern void sendPrintText(const char* t);
extern void sendPrintStr(const String& s);
extern void sendDrawPixel(uint16_t x, uint16_t y, uint8_t r, uint8_t g, uint8_t b);
extern void sendDrawLine(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint8_t r, uint8_t g, uint8_t b);
extern void sendDrawRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);
extern void sendFillRect(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b);

// ---- Serial порты ----
extern HardwareSerial SerialESP;

// ---- Display device ----
bool displayVfsExists(const String &path);
bool displayVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool displayVfsIsDir(const String &path);
bool displayVfsRemove(const String &path);
uint32_t displayVfsFileSize(const String &path);
bool displayVfsReadFile(const String &path, String &content);
bool displayVfsWriteFile(const String &path, const String &content);

// ---- Serial device ----
bool serialVfsExists(const String &path);
bool serialVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool serialVfsIsDir(const String &path);
bool serialVfsRemove(const String &path);
uint32_t serialVfsFileSize(const String &path);
bool serialVfsReadFile(const String &path, String &content);
bool serialVfsWriteFile(const String &path, const String &content);

// ---- Инициализация ----
void devicesVfsInit();