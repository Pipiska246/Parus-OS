#define __FREERTOS 1
#include "vfs.h"
#include <string.h>
#include "gpio_vfs.h"
#include "devices_vfs.h"
#include "proc_vfs.h"
#include "lib_vfs.h"
#include "bin_vfs.h"
#include "input_vfs.h"
#include "mount.h"

static Adafruit_USBH_MSC_BlockDevice msc_block_dev;
static FatVolume fatfs[VFS_MAX_EXT_PARTS];
static bool      extMounted[VFS_MAX_EXT_PARTS] = {false};

static SemaphoreHandle_t s_vfsMutex = nullptr;

static void vfsLockInit() {
  if (s_vfsMutex == nullptr) s_vfsMutex = xSemaphoreCreateMutex();
}

struct VfsLock {
  VfsLock()  { vfsLockInit(); xSemaphoreTake(s_vfsMutex, portMAX_DELAY); }
  ~VfsLock() { xSemaphoreGive(s_vfsMutex); }
};

void vfsBegin() {
  LittleFS.begin();
}

bool vfsExternalBegin(uint8_t dev_addr) {
  // Сбрасываем предыдущие монтирования
  for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) {
    if (extMounted[i]) fatfs[i].end();
    extMounted[i] = false;
  }
  mountUnregisterPrefix(VFS_EXTERNAL_BASE); // забыть предыдущую флешку в /proc/mounts

  if (!msc_block_dev.begin(dev_addr)) return false;

  // --- СТРАТЕГИЯ 1: Сначала пробуем найти все разделы в MBR ---
  bool anyPartition = false;

  for (int part = 1; part <= VFS_MAX_EXT_PARTS; part++) {
    int slot = part - 1;

    if (fatfs[slot].begin(&msc_block_dev, true, (uint8_t)part)) {
      extMounted[slot] = true;
      anyPartition = true;
      mountRegister(VFS_EXTERNAL_BASE + String(part), "usb0p" + String(part), "vfat");
    }
  }

  if (anyPartition) {
    return true;
  }

  // --- СТРАТЕГИЯ 2: Superfloppy (без MBR) ---
  if (fatfs[0].begin(&msc_block_dev, true, 0)) {
    extMounted[0] = true;
    mountRegister(VFS_EXTERNAL_BASE + String(1), "usb0p1", "vfat");
    return true;
  }

  // --- СТРАТЕГИЯ 3: Последняя попытка ---
  if (fatfs[0].begin(&msc_block_dev, true, 1)) {
    extMounted[0] = true;
    mountRegister(VFS_EXTERNAL_BASE + String(1), "usb0p1", "vfat");
    return true;
  }

  return false;
}

void vfsExternalEnd() {
  for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) {
    if (extMounted[i]) fatfs[i].end();
    extMounted[i] = false;
  }
  msc_block_dev.end();
  mountUnregisterPrefix(VFS_EXTERNAL_BASE);
}

bool vfsExternalMounted() {
  for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) if (extMounted[i]) return true;
  return false;
}

int vfsExternalPartitionCount() {
  int n = 0;
  for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) if (extMounted[i]) n++;
  return n;
}

bool vfsSplit(const String &path, VfsBackendType &backend, int &partIndex, String &sub) {
  String p = path;
  if (p.length() == 0) p = "/";
  partIndex = -1;

  if (p == "/") { backend = VFS_ROOT; sub = "/"; return true; }

  // Проверка на /dev, /proc, /lib, /bin - это корневые "виртуальные" пути
  if (p == "/dev" || p.startsWith("/dev/") ||
      p == "/proc" || p.startsWith("/proc/") ||
      p == "/lib" || p.startsWith("/lib/") ||
      p == "/bin" || p.startsWith("/bin/")) {
    backend = VFS_ROOT;
    sub = p;
    return true;
  }

  if (p.startsWith(VFS_INTERNAL_PREFIX)) {
    sub = p.substring(strlen(VFS_INTERNAL_PREFIX));
    if (sub.length() == 0) sub = "/";
    backend = VFS_SDA;
    return true;
  }

  if (p.startsWith(VFS_EXTERNAL_BASE)) {
    int i = strlen(VFS_EXTERNAL_BASE);
    int numStart = i;
    while (i < (int)p.length() && isDigit(p[i])) i++;
    if (i == numStart) { backend = VFS_NONE; return false; }
    int num = p.substring(numStart, i).toInt();
    if (num < 1 || num > VFS_MAX_EXT_PARTS) { backend = VFS_NONE; return false; }
    partIndex = num - 1;
    sub = p.substring(i);
    if (sub.length() == 0) sub = "/";
    backend = VFS_SDB;
    return true;
  }

  backend = VFS_NONE;
  return false;
}

String vfsJoin(const String &dir, const String &name) {
  String d = dir;
  if (d.length() > 1 && d.endsWith("/")) d.remove(d.length() - 1);
  return d + "/" + name;
}

bool vfsListDir(const String &path, std::vector<VfsEntry> &out) {
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;

  // Проверка GPIO VFS
  if (path == "/dev" || path == "/dev/gpio" || path == "/dev/input" || path == "/dev/output") {
    return gpioVfsListDir(path, out);
  }

  // Кнопки / клавиатура внутри /dev/input
  if (path == "/dev/input/buttons" || path == "/dev/input/keyboard") {
    return inputVfsListDir(path, out);
  }

  // Проверка Display VFS
  if (path == "/dev/display" || path.startsWith("/dev/display/")) {
    return displayVfsListDir(path, out);
  }
  
  // Проверка Serial VFS
  if (path == "/dev/serial" || path.startsWith("/dev/serial/")) {
    return serialVfsListDir(path, out);
  }

  // /proc - точки монтирования, аптайм, версия, "процесс" аудио
  if (path == "/proc" || path == "/proc/audio") {
    return procVfsListDir(path, out);
  }

  // /lib - статический манифест библиотек прошивки
  if (path == "/lib") {
    return libVfsListDir(path, out);
  }

  // /bin - реестр приложений
  if (path == "/bin") {
    return binVfsListDir(path, out);
  }

  if (backend == VFS_ROOT) {
    out.push_back({"sda", true, 0});
    out.push_back({"dev", true, 0});  // ← /dev уже есть
    out.push_back({"proc", true, 0});
    out.push_back({"lib", true, 0});
    out.push_back({"bin", true, 0});
    for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) {
      if (extMounted[i]) {
        out.push_back({String("sdb") + String(i + 1), true, 0});
      }
    }
    return true;
  }

  if (backend == VFS_SDA) {
    File dir = LittleFS.open(sub, "r");
    if (!dir || !dir.isDirectory()) { if (dir) dir.close(); return false; }
    File entry = dir.openNextFile();
    while (entry) {
      VfsEntry e;
      e.name  = String(entry.name());
      e.isDir = entry.isDirectory();
      e.size  = e.isDir ? 0 : entry.size();
      out.push_back(e);
      entry.close();
      entry = dir.openNextFile();
    }
    dir.close();
    return true;
  }

  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) return false;
    File32 dir = fatfs[part].open(sub.c_str());
    if (!dir || !dir.isDirectory()) return false;
    File32 entry;
    while (entry.openNext(&dir, O_RDONLY)) {
      char nameBuf[64];
      entry.getName(nameBuf, sizeof(nameBuf));
      VfsEntry e;
      e.name  = String(nameBuf);
      e.isDir = entry.isDirectory();
      e.size  = entry.fileSize();
      out.push_back(e);
      entry.close();
    }
    dir.close();
    return true;
  }

  return false;
}

bool vfsExists(const String &path) {
  // Проверка GPIO VFS
  if (gpioVfsExists(path)) return true;
  
  // Проверка Display VFS
  if (displayVfsExists(path)) return true;
  
  // Проверка Serial VFS
  if (serialVfsExists(path)) return true;

  // Кнопки / клавиатура, /proc, /lib, /bin
  if (inputVfsExists(path)) return true;
  if (procVfsExists(path)) return true;
  if (libVfsExists(path)) return true;
  if (binVfsExists(path)) return true;
  
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;
  
  if (backend == VFS_ROOT) {
    if (path == "/") return true;
    if (path == "/sda") return true;
    if (path == "/dev") return true;
    if (path == "/dev/gpio") return true;
    if (path == "/dev/input") return true;
    if (path == "/dev/output") return true;
    if (path == "/dev/display") return true;
    if (path == "/dev/serial") return true;
    if (path.startsWith("/dev/")) return true;  // ← ВАЖНО: все пути в /dev существуют
    if (path == "/proc") return true;
    if (path == "/lib") return true;
    if (path == "/bin") return true;
    for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) {
      if (extMounted[i] && path == "/sdb" + String(i + 1)) return true;
    }
    return false;
  }
  
  if (backend == VFS_SDA) return LittleFS.exists(sub);
  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) return false;
    File32 f = fatfs[part].open(sub.c_str(), O_RDONLY);
    bool ok = (bool)f;
    if (ok) f.close();
    return ok;
  }
  return false;
}

bool vfsIsDir(const String &path) {
  // Проверка GPIO VFS
  if (gpioVfsIsDir(path)) return true;
  
  // Проверка Display VFS
  if (displayVfsIsDir(path)) return true;
  
  // Проверка Serial VFS
  if (serialVfsIsDir(path)) return true;

  if (inputVfsIsDir(path)) return true;
  if (procVfsIsDir(path)) return true;
  if (libVfsIsDir(path)) return true;
  if (binVfsIsDir(path)) return true;
  
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;
  
  if (backend == VFS_ROOT) {
    if (path == "/") return true;
    if (path == "/sda") return true;
    if (path == "/dev") return true;
    if (path == "/dev/gpio") return true;
    if (path == "/dev/input") return true;
    if (path == "/dev/output") return true;
    if (path == "/dev/display") return true;
    if (path == "/dev/serial") return true;
    if (path == "/proc") return true;
    if (path == "/lib") return true;
    if (path == "/bin") return true;
    for (int i = 0; i < VFS_MAX_EXT_PARTS; i++) {
      if (extMounted[i] && path == "/sdb" + String(i + 1)) return true;
    }
    return false;
  }
  
  if (backend == VFS_SDA) {
    File f = LittleFS.open(sub, "r");
    bool d = f && f.isDirectory();
    if (f) f.close();
    return d;
  }
  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) return false;
    File32 f = fatfs[part].open(sub.c_str(), O_RDONLY);
    bool d = f && f.isDirectory();
    if (f) f.close();
    return d;
  }
  return false;
}

bool vfsRemove(const String &path) {
  if (gpioVfsRemove(path)) return true;
  if (displayVfsRemove(path)) return true;
  if (serialVfsRemove(path)) return true;
  if (inputVfsRemove(path)) return true;
  if (procVfsRemove(path)) return true;
  if (libVfsRemove(path)) return true;
  if (binVfsRemove(path)) return true;
  
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;
  if (backend == VFS_SDA) return LittleFS.remove(sub);
  if (backend == VFS_SDB) return part >= 0 && extMounted[part] && fatfs[part].remove(sub.c_str());
  return false;
}

bool vfsMkdir(const String &path) {
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;
  
  if (backend == VFS_SDA) {
    if (LittleFS.exists(sub)) {
      File f = LittleFS.open(sub, "r");
      bool isDir = f && f.isDirectory();
      if (f) f.close();
      if (isDir) return true;
      return false;
    }
    return LittleFS.mkdir(sub);
  }
  
  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) {

      return false;
    }
    
    // Нормализуем путь
    if (sub.length() > 1 && sub.endsWith("/")) sub.remove(sub.length() - 1);
    if (sub.length() == 0) sub = "/";
    
    
    // Проверяем с таймаутом
    unsigned long start = millis();
    bool exists = false;
    bool isDir = false;
    
    // Проверка существования с таймаутом
    File32 check = fatfs[part].open(sub.c_str(), O_RDONLY);
    if (check) {
      isDir = check.isDirectory();
      check.close();
      if (isDir) {
        return true;
      }

      return false;
    }
    
    // Если путь - корень
    if (sub == "/" || sub.length() == 0) return true;
    
    // Пытаемся создать напрямую
    bool result = fatfs[part].mkdir(sub.c_str());
    unsigned long elapsed = millis() - start;
    
    if (elapsed > 100) {

        }
    
    if (result) {
      return true;
    }
    
    // Если не удалось, пробуем создать рекурсивно
    
    // Разбиваем путь на компоненты
    std::vector<String> parts;
    String current = "";
    for (size_t i = 0; i < sub.length(); i++) {
      char c = sub[i];
      if (c == '/') {
        if (current.length() > 0) {
          parts.push_back(current);
          current = "";
        }
      } else {
        current += c;
      }
    }
    if (current.length() > 0) parts.push_back(current);
    
    if (parts.empty()) return true;
    
    // Создаём папки последовательно
    String buildPath = "";
    bool allOk = true;
    
    for (size_t i = 0; i < parts.size(); i++) {
      buildPath += "/" + parts[i];
      
      // Проверяем с таймаутом
      unsigned long checkStart = millis();
      File32 check2 = fatfs[part].open(buildPath.c_str(), O_RDONLY);
      if (check2) {
        check2.close();
        continue;
      }
      
      // Создаём папку
      bool ok = fatfs[part].mkdir(buildPath.c_str());
      if (!ok) {
        allOk = false;
        break;
      }
    }
    
    // Проверяем конечный результат
    File32 finalCheck = fatfs[part].open(sub.c_str(), O_RDONLY);
    bool finalOk = finalCheck && finalCheck.isDirectory();
    if (finalCheck) finalCheck.close();
    

    return finalOk;
  }
  
  return false;
}
bool vfsRmdir(const String &path) {
  VfsBackendType backend; int part; String sub;
  if (!vfsSplit(path, backend, part, sub)) return false;
  if (backend == VFS_SDA) return LittleFS.rmdir(sub);
  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) return false;
    File32 d = fatfs[part].open(sub.c_str(), O_RDONLY);
    if (!d || !d.isDirectory()) { if (d) d.close(); return false; }
    bool ok = d.rmdir();  // ← здесь rmDir() -> rmdir()
    d.close();
    return ok;
  }
  return false;
}

bool vfsRename(const String &oldPath, const String &newPath) {
  VfsBackendType b1, b2; int p1, p2; String s1, s2;
  if (!vfsSplit(oldPath, b1, p1, s1) || !vfsSplit(newPath, b2, p2, s2)) return false;
  if (b1 != b2 || p1 != p2) return false;
  if (b1 == VFS_SDA) return LittleFS.rename(s1, s2);
  if (b1 == VFS_SDB) return p1 >= 0 && extMounted[p1] && fatfs[p1].rename(s1.c_str(), s2.c_str());
  return false;
}

uint32_t vfsFileSize(const String &path) {
  VfsBackendType backend; int part; String sub;
  uint32_t gpioSize = gpioVfsFileSize(path);
  if (gpioSize > 0) return gpioSize;
  
  uint32_t displaySize = displayVfsFileSize(path);
  if (displaySize > 0) return displaySize;
  
  uint32_t serialSize = serialVfsFileSize(path);
  if (serialSize > 0) return serialSize;

  uint32_t inputSize = inputVfsFileSize(path);
  if (inputVfsExists(path)) return inputSize;

  uint32_t procSize = procVfsFileSize(path);
  if (procSize > 0) return procSize;

  uint32_t libSize = libVfsFileSize(path);
  if (libSize > 0) return libSize;

  uint32_t binSize = binVfsFileSize(path);
  if (binSize > 0) return binSize;
  
  if (gpioSize > 0) return gpioSize;

  if (!vfsSplit(path, backend, part, sub)) return 0;
  if (backend == VFS_SDA) {
    File f = LittleFS.open(sub, "r");
    uint32_t s = f ? f.size() : 0;
    if (f) f.close();
    return s;
  }
  if (backend == VFS_SDB) {
    if (part < 0 || !extMounted[part]) return 0;
    File32 f = fatfs[part].open(sub.c_str(), O_RDONLY);
    uint32_t s = f ? f.fileSize() : 0;
    if (f) f.close();
    return s;
  }
  return 0;
}

// ---------------- VfsFile ----------------

// ---------------- VfsFile ----------------

VfsFile::VfsFile() : _backend(VFS_NONE), _extPart(-1), _path("") {}

bool VfsFile::openRead(const String &path) {
  _path = path;
  
  // Проверка GPIO / display / serial / input / proc / lib / bin VFS
  if (gpioVfsExists(path) || displayVfsExists(path) || serialVfsExists(path) ||
      inputVfsExists(path) || procVfsExists(path) || libVfsExists(path) || binVfsExists(path)) {
    _backend = VFS_ROOT;
    _extPart = -1;
    return true;
  }
  
  String sub;
  if (!vfsSplit(path, _backend, _extPart, sub)) return false;
  if (_backend == VFS_SDA) {
    _internal = LittleFS.open(sub, "r");
    return (bool)_internal;
  }
  if (_backend == VFS_SDB) {
    if (_extPart < 0 || !extMounted[_extPart]) return false;
    _external = fatfs[_extPart].open(sub.c_str(), O_RDONLY);
    return (bool)_external;
  }
  return false;
}

bool VfsFile::openWrite(const String &path, bool append) {
  _path = path;
  
  // Проверка GPIO / display / serial / input / proc / lib / bin VFS
  if (gpioVfsExists(path) || displayVfsExists(path) || serialVfsExists(path) ||
      inputVfsExists(path) || procVfsExists(path) || libVfsExists(path) || binVfsExists(path)) {
    _backend = VFS_ROOT;
    _extPart = -1;
    return true;
  }
  
  String sub;
  if (!vfsSplit(path, _backend, _extPart, sub)) return false;
  if (_backend == VFS_SDA) {
    _internal = LittleFS.open(sub, append ? "a" : "w");
    return (bool)_internal;
  }
  if (_backend == VFS_SDB) {
    if (_extPart < 0 || !extMounted[_extPart]) return false;
    uint8_t mode = O_WRONLY | O_CREAT | (append ? O_APPEND : O_TRUNC);
    _external = fatfs[_extPart].open(sub.c_str(), mode);
    return (bool)_external;
  }
  return false;
}

size_t VfsFile::read(uint8_t *buf, size_t len) {
  if (_backend == VFS_ROOT && _path.startsWith("/dev/")) {
    String content;
    if (_path.startsWith("/dev/input/buttons/") || _path.startsWith("/dev/input/keyboard/")) {
      if (inputVfsReadFile(_path, content)) {
        size_t toCopy = min(len, content.length());
        memcpy(buf, content.c_str(), toCopy);
        return toCopy;
      }
      return 0;
    }
    if (_path.startsWith("/dev/input/") || _path.startsWith("/dev/gpio/") || _path.startsWith("/dev/output/")) {
      if (gpioVfsReadFile(_path, content)) {
        size_t toCopy = min(len, content.length());
        memcpy(buf, content.c_str(), toCopy);
        return toCopy;
      }
    }
    if (_path.startsWith("/dev/serial/")) {
      if (serialVfsReadFile(_path, content)) {
        size_t toCopy = min(len, content.length());
        memcpy(buf, content.c_str(), toCopy);
        return toCopy;
      }
    }
    return 0;
  }

  if (_backend == VFS_ROOT && _path.startsWith("/proc/")) {
    String content;
    if (procVfsReadFile(_path, content)) {
      size_t toCopy = min(len, content.length());
      memcpy(buf, content.c_str(), toCopy);
      return toCopy;
    }
    return 0;
  }

  if (_backend == VFS_ROOT && _path.startsWith("/lib/")) {
    String content;
    if (libVfsReadFile(_path, content)) {
      size_t toCopy = min(len, content.length());
      memcpy(buf, content.c_str(), toCopy);
      return toCopy;
    }
    return 0;
  }

  if (_backend == VFS_ROOT && _path.startsWith("/bin/")) {
    String content;
    if (binVfsReadFile(_path, content)) {
      size_t toCopy = min(len, content.length());
      memcpy(buf, content.c_str(), toCopy);
      return toCopy;
    }
    return 0;
  }
  
  if (_backend == VFS_SDA) return _internal.read(buf, len);
  if (_backend == VFS_SDB) return _external.read(buf, len);
  return 0;
}

size_t VfsFile::write(const uint8_t *buf, size_t len) {
  if (_backend == VFS_ROOT && _path.startsWith("/dev/")) {
    String content((const char*)buf, len);

    if (_path.startsWith("/dev/input/buttons/") || _path.startsWith("/dev/input/keyboard/")) {
      if (inputVfsWriteFile(_path, content)) return len;
      return 0;
    }
    if (_path.startsWith("/dev/input/") || _path.startsWith("/dev/gpio/") || _path.startsWith("/dev/output/")) {
      if (gpioVfsWriteFile(_path, content)) return len;
    }
    if (_path.startsWith("/dev/display/")) {
      if (displayVfsWriteFile(_path, content)) return len;
    }
    if (_path.startsWith("/dev/serial/")) {
      if (serialVfsWriteFile(_path, content)) return len;
    }
    return 0;
  }

  if (_backend == VFS_ROOT && _path.startsWith("/proc/")) {
    String content((const char*)buf, len);
    if (procVfsWriteFile(_path, content)) return len;
    return 0;
  }

  if (_backend == VFS_ROOT && (_path.startsWith("/lib/") || _path.startsWith("/bin/"))) {
    return 0; // read-only манифесты
  }
  
  if (_backend == VFS_SDA) return _internal.write(buf, len);
  if (_backend == VFS_SDB) return _external.write(buf, len);
  return 0;
}

bool VfsFile::seek(uint32_t pos) {
  if (_backend == VFS_SDA) return _internal.seek(pos, SeekSet);
  if (_backend == VFS_SDB) return _external.seek(pos);
  return false;
}

uint32_t VfsFile::position() {
  if (_backend == VFS_SDA) return _internal.position();
  if (_backend == VFS_SDB) return _external.curPosition();
  return 0;
}

bool VfsFile::isAvailable() {
  if (_backend == VFS_SDA) return _internal.available() > 0;
  if (_backend == VFS_SDB) return _external.available() > 0;
  return false;
}

uint32_t VfsFile::size() {
  if (_backend == VFS_SDA) return _internal.size();
  if (_backend == VFS_SDB) return _external.fileSize();
  return 0;
}

void VfsFile::close() {
  if (_backend == VFS_SDA) _internal.close();
  if (_backend == VFS_SDB) _external.close();
  _backend = VFS_NONE;
  _extPart = -1;
}

bool VfsFile::isOpen() {
  if (_backend == VFS_SDA) return (bool)_internal;
  if (_backend == VFS_SDB) return (bool)_external;
  return false;
}