#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  proc_vfs.h — /proc/
//
//  Linux-style "everything you'd want to introspect is a file"
//  directory. Ties together things that used to only be readable
//  from C++ (the mount table, uptime, firmware version) and the
//  audio background task (see audio_vfs.h) under one root:
//
//      /proc/mounts    (r)  one line per mount.h entry: "<dev> <mp> <fstype> <rw|ro>"
//      /proc/uptime    (r)  seconds since boot
//      /proc/version   (r)  "Parus OS <version> (Bash <ver>, Turbine <ver>)"
//      /proc/audio/... (rw) see audio_vfs.h - the audio task's own folder
// ================================================================

bool     procVfsExists(const String &path);
bool     procVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     procVfsIsDir(const String &path);
bool     procVfsRemove(const String &path);
uint32_t procVfsFileSize(const String &path);
bool     procVfsReadFile(const String &path, String &content);
bool     procVfsWriteFile(const String &path, const String &content);

void procVfsInit();
