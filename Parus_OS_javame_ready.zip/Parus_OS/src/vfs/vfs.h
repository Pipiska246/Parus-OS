#pragma once
#include <Arduino.h>
#include <vector>
#include <LittleFS.h>
#include "SdFat_Adafruit_Fork.h"
#include "Adafruit_TinyUSB.h"
#include "../core/config.h"

// A tiny "Linux-like" virtual filesystem that hides the real storage
// backends behind unified device-style paths:
//
//      /                 -> virtual root, lists "sda", "sdb1", "sdb2", ...
//      /sda/<path>       -> RP2040 on-chip flash         (LittleFS)
//      /sdb1/<path>      -> 1st partition on the USB drive (FatFs via SdFat fork)
//      /sdb2/<path>      -> 2nd partition on the USB drive (if it has more than one)
//      ... up to VFS_MAX_EXT_PARTS partitions
//
// Most USB sticks are a single, unpartitioned ("superfloppy") volume, so
// you'll usually just see "/sdb1". If the drive actually has a partition
// table with more than one partition, they show up as sdb1, sdb2, sdb3...
//
// Every app (file manager, music player, serial link, ...) only ever has
// to deal with strings like "/sdb1/music/track1.wav".

enum VfsBackendType { VFS_NONE, VFS_ROOT, VFS_SDA, VFS_SDB };

struct VfsEntry {
  String   name;
  bool     isDir;
  uint32_t size;
};

// --- lifecycle ---
void vfsBegin();                          // mounts LittleFS (/sda), call once in setup()
bool vfsExternalBegin(uint8_t dev_addr);   // call from tuh_msc_mount_cb() - mounts all partitions it finds
void vfsExternalEnd();                     // call from tuh_msc_umount_cb()
bool vfsExternalMounted();                 // true if at least one /sdbN partition is mounted
int  vfsExternalPartitionCount();          // how many /sdbN partitions are currently mounted

// --- path utilities ---
// (partIndex is 0-based and only meaningful when backend == VFS_SDB)
bool   vfsSplit(const String &path, VfsBackendType &backend, int &partIndex, String &sub);
String vfsJoin(const String &dir, const String &name);

// --- directory / file ops (all take a *full* vfs path, e.g. "/sdb1/a/b.txt") ---
bool     vfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     vfsExists(const String &path);
bool     vfsIsDir(const String &path);
bool     vfsRemove(const String &path);
bool     vfsMkdir(const String &path);
bool     vfsRmdir(const String &path);   // remove an *empty* directory
bool     vfsRename(const String &oldPath, const String &newPath);
uint32_t vfsFileSize(const String &path);

// --- generic file handle used by the music player, "cat" view and serial GET/PUT ---
class VfsFile {
public:
  VfsFile();
  bool     openRead(const String &path);
  bool     openWrite(const String &path, bool append = false);
  size_t   read(uint8_t *buf, size_t len);
  size_t   write(const uint8_t *buf, size_t len);
  bool     seek(uint32_t pos);
  uint32_t position();
  bool     isAvailable();
  uint32_t size();
  void     close();
  bool     isOpen();

private:
  VfsBackendType _backend;
  int            _extPart;
  String         _path;      // ← ДОБАВИТЬ
  File           _internal;
  File32         _external;
};
