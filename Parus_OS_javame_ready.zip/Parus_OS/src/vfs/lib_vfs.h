#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  lib_vfs.h — /lib/
//
//  A read-only, Linux-"/usr/lib"-ish directory listing every
//  compiled-in library the firmware links against (see README's
//  "Необходимые библиотеки" section). It doesn't do dynamic linking
//  (there's no such thing on a microcontroller image) - it's a
//  static manifest, so `ls /lib` / `cat /lib/<name>` tells a program
//  (or a human in bash) what it can rely on being available, instead
//  of that information only living in a comment inside README.md.
// ================================================================

bool     libVfsExists(const String &path);
bool     libVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     libVfsIsDir(const String &path);
bool     libVfsRemove(const String &path);
uint32_t libVfsFileSize(const String &path);
bool     libVfsReadFile(const String &path, String &content);
bool     libVfsWriteFile(const String &path, const String &content);

void libVfsInit();
