#include "mount.h"

static std::vector<MountEntry> s_mounts;

void mountInit() {
  s_mounts.clear();
  MountEntry e;
  e.device     = "littlefs0";
  e.mountpoint = "/sda";
  e.fstype     = "littlefs";
  e.readOnly   = false;
  s_mounts.push_back(e);
}

void mountRegister(const String &mountpoint, const String &device,
                   const String &fstype, bool readOnly) {
  mountUnregister(mountpoint); // no duplicates on remount
  MountEntry e;
  e.device     = device;
  e.mountpoint = mountpoint;
  e.fstype     = fstype;
  e.readOnly   = readOnly;
  s_mounts.push_back(e);
}

void mountUnregister(const String &mountpoint) {
  for (size_t i = 0; i < s_mounts.size(); i++) {
    if (s_mounts[i].mountpoint == mountpoint) {
      s_mounts.erase(s_mounts.begin() + i);
      return;
    }
  }
}

void mountUnregisterPrefix(const String &prefix) {
  for (size_t i = 0; i < s_mounts.size(); ) {
    if (s_mounts[i].mountpoint.startsWith(prefix)) {
      s_mounts.erase(s_mounts.begin() + i);
    } else {
      i++;
    }
  }
}

int mountCount() { return (int)s_mounts.size(); }

bool mountGet(int index, MountEntry &out) {
  if (index < 0 || index >= (int)s_mounts.size()) return false;
  out = s_mounts[index];
  return true;
}

bool mountFind(const String &mountpoint, MountEntry &out) {
  for (size_t i = 0; i < s_mounts.size(); i++) {
    if (s_mounts[i].mountpoint == mountpoint) {
      out = s_mounts[i];
      return true;
    }
  }
  return false;
}

String mountProcMounts() {
  String out;
  for (size_t i = 0; i < s_mounts.size(); i++) {
    out += s_mounts[i].device + " " + s_mounts[i].mountpoint + " " +
           s_mounts[i].fstype + " " + (s_mounts[i].readOnly ? "ro" : "rw") + "\n";
  }
  return out;
}
