#include "devices_vfs.h"
#include "vfs.h"
#include <Arduino.h>

// Используем Serial1 как ESP порт
#define SerialESP Serial1

// ================================================================
//  Display Device (/dev/display/)
// ================================================================

bool displayVfsExists(const String &path) {
  if (path == "/dev/display") return true;
  if (path == "/dev/display/clear") return true;
  if (path == "/dev/display/text") return true;
  if (path == "/dev/display/pixel") return true;
  if (path == "/dev/display/line") return true;
  if (path == "/dev/display/rect") return true;
  if (path == "/dev/display/fill") return true;
  return false;
}

bool displayVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path == "/dev/display") {
    out.push_back({"clear", false, 0});
    out.push_back({"text", false, 0});
    out.push_back({"pixel", false, 0});
    out.push_back({"line", false, 0});
    out.push_back({"rect", false, 0});
    out.push_back({"fill", false, 0});
    return true;
  }
  return false;
}

bool displayVfsIsDir(const String &path) {
  return (path == "/dev/display");
}

bool displayVfsRemove(const String &path) {
  return false;
}

uint32_t displayVfsFileSize(const String &path) {
  return 0;
}

bool displayVfsReadFile(const String &path, String &content) {
  return false;
}

bool displayVfsWriteFile(const String &path, const String &content) {
  // Все функции отображения объявлены в .ino
  if (path == "/dev/display/clear") {
    sendFillScreen(0, 0, 0);
    return true;
  }
  else if (path == "/dev/display/text") {
    String cmd = content;
    cmd.trim();
    
    int firstComma = cmd.indexOf(',');
    if (firstComma < 0) {
      sendSetCursor(0, 0);
      sendSetTextColor(255, 255, 255);
      sendPrintText(cmd.c_str());
    } else {
      int secondComma = cmd.indexOf(',', firstComma + 1);
      if (secondComma < 0) return false;
      
      int x = cmd.substring(0, firstComma).toInt();
      int y = cmd.substring(firstComma + 1, secondComma).toInt();
      String text = cmd.substring(secondComma + 1);
      
      sendSetCursor(x, y);
      sendSetTextColor(255, 255, 255);
      sendPrintStr(text);
    }
    return true;
  }
  else if (path == "/dev/display/pixel") {
    String cmd = content;
    cmd.trim();
    
    int c1 = cmd.indexOf(',');
    int c2 = cmd.indexOf(',', c1 + 1);
    int c3 = cmd.indexOf(',', c2 + 1);
    int c4 = cmd.indexOf(',', c3 + 1);
    
    if (c1 < 0 || c2 < 0 || c3 < 0 || c4 < 0) return false;
    
    int x = cmd.substring(0, c1).toInt();
    int y = cmd.substring(c1 + 1, c2).toInt();
    int r = cmd.substring(c2 + 1, c3).toInt();
    int g = cmd.substring(c3 + 1, c4).toInt();
    int b = cmd.substring(c4 + 1).toInt();
    
    sendDrawPixel(x, y, r, g, b);
    return true;
  }
  else if (path == "/dev/display/line") {
    String cmd = content;
    cmd.trim();
    
    int c1 = cmd.indexOf(',');
    int c2 = cmd.indexOf(',', c1 + 1);
    int c3 = cmd.indexOf(',', c2 + 1);
    int c4 = cmd.indexOf(',', c3 + 1);
    int c5 = cmd.indexOf(',', c4 + 1);
    int c6 = cmd.indexOf(',', c5 + 1);
    
    if (c1 < 0 || c2 < 0 || c3 < 0 || c4 < 0 || c5 < 0 || c6 < 0) return false;
    
    int x0 = cmd.substring(0, c1).toInt();
    int y0 = cmd.substring(c1 + 1, c2).toInt();
    int x1 = cmd.substring(c2 + 1, c3).toInt();
    int y1 = cmd.substring(c3 + 1, c4).toInt();
    int r = cmd.substring(c4 + 1, c5).toInt();
    int g = cmd.substring(c5 + 1, c6).toInt();
    int b = cmd.substring(c6 + 1).toInt();
    
    sendDrawLine(x0, y0, x1, y1, r, g, b);
    return true;
  }
  else if (path == "/dev/display/rect") {
    String cmd = content;
    cmd.trim();
    
    int c1 = cmd.indexOf(',');
    int c2 = cmd.indexOf(',', c1 + 1);
    int c3 = cmd.indexOf(',', c2 + 1);
    int c4 = cmd.indexOf(',', c3 + 1);
    int c5 = cmd.indexOf(',', c4 + 1);
    int c6 = cmd.indexOf(',', c5 + 1);
    
    if (c1 < 0 || c2 < 0 || c3 < 0 || c4 < 0 || c5 < 0 || c6 < 0) return false;
    
    int x = cmd.substring(0, c1).toInt();
    int y = cmd.substring(c1 + 1, c2).toInt();
    int w = cmd.substring(c2 + 1, c3).toInt();
    int h = cmd.substring(c3 + 1, c4).toInt();
    int r = cmd.substring(c4 + 1, c5).toInt();
    int g = cmd.substring(c5 + 1, c6).toInt();
    int b = cmd.substring(c6 + 1).toInt();
    
    sendDrawRect(x, y, w, h, r, g, b);
    return true;
  }
  else if (path == "/dev/display/fill") {
    String cmd = content;
    cmd.trim();
    
    int c1 = cmd.indexOf(',');
    int c2 = cmd.indexOf(',', c1 + 1);
    int c3 = cmd.indexOf(',', c2 + 1);
    int c4 = cmd.indexOf(',', c3 + 1);
    int c5 = cmd.indexOf(',', c4 + 1);
    int c6 = cmd.indexOf(',', c5 + 1);
    
    if (c1 < 0 || c2 < 0 || c3 < 0 || c4 < 0 || c5 < 0 || c6 < 0) return false;
    
    int x = cmd.substring(0, c1).toInt();
    int y = cmd.substring(c1 + 1, c2).toInt();
    int w = cmd.substring(c2 + 1, c3).toInt();
    int h = cmd.substring(c3 + 1, c4).toInt();
    int r = cmd.substring(c4 + 1, c5).toInt();
    int g = cmd.substring(c5 + 1, c6).toInt();
    int b = cmd.substring(c6 + 1).toInt();
    
    sendFillRect(x, y, w, h, r, g, b);
    return true;
  }
  return false;
}

// ================================================================
//  Serial Device (/dev/serial/)
// ================================================================

bool serialVfsExists(const String &path) {
  if (path == "/dev/serial") return true;
  if (path == "/dev/serial/pc") return true;
  if (path == "/dev/serial/esp") return true;
  return false;
}

bool serialVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path == "/dev/serial") {
    out.push_back({"pc", false, 0});
    out.push_back({"esp", false, 0});
    return true;
  }
  return false;
}

bool serialVfsIsDir(const String &path) {
  return (path == "/dev/serial");
}

bool serialVfsRemove(const String &path) {
  return false;
}

uint32_t serialVfsFileSize(const String &path) {
  if (path == "/dev/serial/pc") {
    return Serial.available();
  }
  if (path == "/dev/serial/esp") {
    return SerialESP.available();
  }
  return 0;
}

bool serialVfsReadFile(const String &path, String &content) {
  if (path == "/dev/serial/pc") {
    content = "";
    while (Serial.available()) {
      content += (char)Serial.read();
    }
    return content.length() > 0;
  }
  if (path == "/dev/serial/esp") {
    content = "";
    while (SerialESP.available()) {
      content += (char)SerialESP.read();
    }
    return content.length() > 0;
  }
  return false;
}

bool serialVfsWriteFile(const String &path, const String &content) {
  if (path == "/dev/serial/pc") {
    Serial.print(content);
    return true;
  }
  if (path == "/dev/serial/esp") {
    SerialESP.print(content);
    return true;
  }
  return false;
}

void devicesVfsInit() {
  // Инициализация не требуется
}