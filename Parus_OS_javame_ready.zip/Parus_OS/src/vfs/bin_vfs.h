#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  bin_vfs.h — /bin/
//
//  Every built-in app (file browser, calculator, plotter, clock,
//  terminal, editor, music player, settings, doom-nano, ...) gets an
//  entry here, the same way real programs on a Linux system live
//  under /bin - `ls /bin` lists what's runnable, `cat /bin/<name>`
//  shows a one-line description, and `run <name>` (terminal.cpp) is
//  the equivalent of typing the program's name at a shell prompt.
//
//  bin_vfs.cpp itself has no idea what an "AppState" is (that enum
//  lives in the .ino) - it just holds the manifest and a function
//  pointer the .ino registers once at boot, so switching screens
//  stays entirely the .ino's business.
// ================================================================

// Implemented in the .ino: switches currentState to whatever screen
// `progName` refers to. Returns false if progName isn't a known app.
typedef bool (*BinLauncher)(const String &progName);

void binVfsSetLauncher(BinLauncher fn);

// Looks `progName` up in the manifest and, if found, calls the
// registered launcher. Returns false if the program doesn't exist or
// no launcher has been registered yet.
bool binVfsRun(const String &progName);

bool     binVfsExists(const String &path);
bool     binVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     binVfsIsDir(const String &path);
bool     binVfsRemove(const String &path);
uint32_t binVfsFileSize(const String &path);
bool     binVfsReadFile(const String &path, String &content);
bool     binVfsWriteFile(const String &path, const String &content);

void binVfsInit();
