#include "audio_vfs.h"
#include "../audio/audio.h"

// Список "файлов" внутри /proc/audio (см. audio_vfs.h)
static const char* kAudioEntries[] = {
  "status", "track", "position", "control", "volume", "speed", "pid"
};
#define AUDIO_VFS_NENTRIES (sizeof(kAudioEntries) / sizeof(kAudioEntries[0]))

static bool isAudioEntry(const String &path, const char *name) {
  return path == (String("/proc/audio/") + name);
}

bool audioVfsExists(const String &path) {
  if (path == "/proc/audio") return true;
  for (size_t i = 0; i < AUDIO_VFS_NENTRIES; i++) {
    if (isAudioEntry(path, kAudioEntries[i])) return true;
  }
  return false;
}

bool audioVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path != "/proc/audio") return false;
  for (size_t i = 0; i < AUDIO_VFS_NENTRIES; i++) {
    out.push_back({String(kAudioEntries[i]), false, 0});
  }
  return true;
}

bool audioVfsIsDir(const String &path) {
  return path == "/proc/audio";
}

bool audioVfsRemove(const String &path) {
  (void)path;
  return false; // /proc/audio - псевдо-файлы, ничего нельзя удалить
}

uint32_t audioVfsFileSize(const String &path) {
  (void)path;
  return 0; // размер не фиксирован (текст переменной длины), как и в /dev
}

bool audioVfsReadFile(const String &path, String &content) {
  if (isAudioEntry(path, "status")) {
    content = musicPlaying ? (musicPaused ? "paused" : "playing") : "stopped";
    return true;
  }
  if (isAudioEntry(path, "track")) {
    content = musicFileNameForUI;
    return true;
  }
  if (isAudioEntry(path, "position")) {
    content = String(musicPosition) + "/" + String(musicTotalSize);
    return true;
  }
  if (isAudioEntry(path, "volume")) {
    content = String(audioVolume);
    return true;
  }
  if (isAudioEntry(path, "speed")) {
    content = String(audioSpeed, 2);
    return true;
  }
  if (isAudioEntry(path, "pid")) {
    content = String(audioTaskId());
    return true;
  }
  if (isAudioEntry(path, "control")) {
    content = ""; // write-only, как /dev/display/*
    return true;
  }
  return false;
}

bool audioVfsWriteFile(const String &path, const String &content) {
  if (isAudioEntry(path, "volume")) {
    long v = content.toInt();
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    setVolume((uint8_t)v);
    return true;
  }
  if (isAudioEntry(path, "speed")) {
    float v = content.toFloat();
    if (v > 0.1f && v < 4.0f) setSpeed(v);
    return true;
  }
  if (isAudioEntry(path, "control")) {
    String cmd = content;
    cmd.trim();
    int sp = cmd.indexOf(' ');
    String verb = sp < 0 ? cmd : cmd.substring(0, sp);
    String arg  = sp < 0 ? "" : cmd.substring(sp + 1);
    arg.trim();

    if (verb == "play" && arg.length() > 0) { startMusic(arg); return true; }
    if (verb == "stop")   { stopMusic();    return true; }
    if (verb == "pause")  { pauseMusic();   return true; }
    if (verb == "resume") { resumeMusic();  return true; }
    return false;
  }
  return false;
}

void audioVfsInit() {
  // Ничего заранее инициализировать не нужно - все данные читаются
  // напрямую из живых переменных audio.cpp в момент обращения к файлу.
}
