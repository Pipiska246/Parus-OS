#include "input_vfs.h"
#include "../core/ui_common.h"     // extern Btn/EncBtn globals (bUp, bDown, ..., bEncBtn)
#include "../input/keyboard_hid.h"

static const char* kButtonNames[] = {
  "up", "down", "left", "right", "ok", "home", "cancel", "enc_btn"
};
#define BUTTON_NAMES_N (sizeof(kButtonNames) / sizeof(kButtonNames[0]))

static const char* kKeyboardNames[] = { "connected", "last" };
#define KEYBOARD_NAMES_N (sizeof(kKeyboardNames) / sizeof(kKeyboardNames[0]))

// Non-destructive: just mirrors the already-updated Btn::state fields
// (updateButtons() in the .ino keeps these current every loop() tick).
static bool buttonState(const String &name) {
  if (name == "up")      return bUp.state;
  if (name == "down")    return bDown.state;
  if (name == "left")    return bLeft.state;
  if (name == "right")   return bRight.state;
  if (name == "ok")      return bOk.state;
  if (name == "home")    return bHome.state;
  if (name == "cancel")  return bCancel.state;
  if (name == "enc_btn") return bEncBtn.state;
  return false;
}

static bool isButtonPath(const String &path, String *nameOut = nullptr) {
  for (size_t i = 0; i < BUTTON_NAMES_N; i++) {
    if (path == (String("/dev/input/buttons/") + kButtonNames[i])) {
      if (nameOut) *nameOut = kButtonNames[i];
      return true;
    }
  }
  return false;
}

static bool isKeyboardPath(const String &path, String *nameOut = nullptr) {
  for (size_t i = 0; i < KEYBOARD_NAMES_N; i++) {
    if (path == (String("/dev/input/keyboard/") + kKeyboardNames[i])) {
      if (nameOut) *nameOut = kKeyboardNames[i];
      return true;
    }
  }
  return false;
}

// Human-readable label for a decoded HID key event, e.g. "char:a",
// "enter", "backspace" - matches HidKeyKind from keyboard_hid.h.
static String describeHidEvent(const HidKeyEvent &ev) {
  switch (ev.kind) {
    case HK_CHAR:      return String("char:") + ev.ch;
    case HK_ENTER:     return "enter";
    case HK_BACKSPACE: return "backspace";
    case HK_TAB:       return "tab";
    case HK_ESC:       return "esc";
    case HK_UP:        return "up";
    case HK_DOWN:      return "down";
    case HK_LEFT:      return "left";
    case HK_RIGHT:     return "right";
    case HK_DELETE:    return "delete";
    case HK_HOME:      return "home";
    case HK_END:       return "end";
    default:           return "none";
  }
}

bool inputVfsExists(const String &path) {
  if (path == "/dev/input/buttons") return true;
  if (path == "/dev/input/keyboard") return true;
  if (isButtonPath(path)) return true;
  if (isKeyboardPath(path)) return true;
  return false;
}

bool inputVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path == "/dev/input/buttons") {
    for (size_t i = 0; i < BUTTON_NAMES_N; i++) out.push_back({String(kButtonNames[i]), false, 0});
    return true;
  }
  if (path == "/dev/input/keyboard") {
    for (size_t i = 0; i < KEYBOARD_NAMES_N; i++) out.push_back({String(kKeyboardNames[i]), false, 0});
    return true;
  }
  return false;
}

bool inputVfsIsDir(const String &path) {
  return path == "/dev/input/buttons" || path == "/dev/input/keyboard";
}

bool inputVfsRemove(const String &path) {
  (void)path;
  return false; // только для чтения - это живое состояние железа, не файлы
}

uint32_t inputVfsFileSize(const String &path) {
  (void)path;
  return 1; // "0"/"1" или короткая строка - размер не принципиален (как /dev/gpio)
}

bool inputVfsReadFile(const String &path, String &content) {
  String name;
  if (isButtonPath(path, &name)) {
    content = buttonState(name) ? "1" : "0";
    return true;
  }
  if (isKeyboardPath(path, &name)) {
    if (name == "connected") {
      content = hidKeyboardConnected() ? "1" : "0";
      return true;
    }
    if (name == "last") {
      HidKeyEvent ev;
      content = hidKeyboardLastEvent(ev) ? describeHidEvent(ev) : "none";
      return true;
    }
  }
  return false;
}

bool inputVfsWriteFile(const String &path, const String &content) {
  (void)path; (void)content;
  return false; // кнопки/клавиатура - вход, писать в них нельзя
}

void inputVfsInit() {
  // Ничего заранее инициализировать не нужно - кнопки/энкодер уже
  // поднимает initButtons()/initEncoder(), HID-клавиатура -
  // hidKeyboardInit(); этот модуль только читает их состояние.
}
