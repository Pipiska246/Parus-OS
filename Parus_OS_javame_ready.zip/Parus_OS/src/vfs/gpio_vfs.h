#pragma once
#include <Arduino.h>
#include <vector>
#include <map>
#include "vfs.h"

// ================================================================
//  GPIO Virtual Filesystem
// ================================================================

#define GPIO_PINS_MAX 28

enum GpioMode {
  GPIO_MODE_UNUSED,
  GPIO_MODE_INPUT,
  GPIO_MODE_OUTPUT
};

struct GpioState {
  GpioMode mode;
  bool     value;
  bool     pullup;
  bool     pulldown;
  String   owner;
};

class GpioManager {
public:
  GpioManager();
  void begin();
  bool getState(int pin, GpioState &state);
  bool setMode(int pin, GpioMode mode, bool pullup = false, bool pulldown = false);
  bool setValue(int pin, bool value);
  bool getValue(int pin);
  bool releasePin(int pin);
  std::vector<int> getPins();
  bool pinExists(int pin);
  String getPinPath(int pin);
  
private:
  GpioState _pins[GPIO_PINS_MAX];
};

extern GpioManager gpioManager;

// Функции для работы с GPIO через VFS
bool gpioVfsExists(const String &path);
bool gpioVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool gpioVfsIsDir(const String &path);  // ← ДОБАВИТЬ
bool gpioVfsRemove(const String &path);
uint32_t gpioVfsFileSize(const String &path);
bool gpioVfsReadFile(const String &path, String &content);
bool gpioVfsWriteFile(const String &path, const String &content);