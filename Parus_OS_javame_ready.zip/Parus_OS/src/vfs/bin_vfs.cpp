#include "bin_vfs.h"

struct BinEntry {
  const char* name;         // /bin/<name>, also the "run <name>" argument
  const char* description;  // содержимое при cat /bin/<name>
};

// Манифест приложений - имена соответствуют тому, что понимает
// appLaunchByName() в .ino (см. binVfsSetLauncher()).
static const BinEntry kBins[] = {
  { "explorer",  "File browser - navigate /sda, /sdb1.., /dev, /proc, /lib, /bin" },
  { "editor",    "nano-like text editor (editor.h/.cpp)" },
  { "terminal",  "bash-like shell over the VFS (terminal.h/.cpp)" },
  { "player",    "Music player - WAV/MP3/raw PCM via the audio engine" },
  { "calc",      "Calculator" },
  { "plotter",   "Function plotter" },
  { "clock",     "Clock app - current time, timer, alarm (clock.h/.cpp)" },
  { "settings",  "Settings - sample rate, rotation, brightness, WiFi" },
  { "imageview", "Image viewer (PNG via PNGdec)" },
  { "tu",        "Turbine (.tu) script runner" },
  { "doom",      "doom-nano" },
  { "java",      "JavaME runner - CLDC 1.1 subset + minimal MIDP lcdui (javame/*, see /proc/jvm)" },
};
#define BIN_COUNT (sizeof(kBins) / sizeof(kBins[0]))

static BinLauncher s_launcher = nullptr;

static const BinEntry* findBin(const String &name) {
  for (size_t i = 0; i < BIN_COUNT; i++) {
    if (name == kBins[i].name) return &kBins[i];
  }
  return nullptr;
}

void binVfsSetLauncher(BinLauncher fn) {
  s_launcher = fn;
}

bool binVfsRun(const String &progName) {
  String name = progName;
  name.trim();
  if (name.startsWith("/bin/")) name = name.substring(5);
  if (findBin(name) == nullptr) return false;
  if (s_launcher == nullptr) return false;
  return s_launcher(name);
}

bool binVfsExists(const String &path) {
  if (path == "/bin") return true;
  if (path.startsWith("/bin/")) return findBin(path.substring(5)) != nullptr;
  return false;
}

bool binVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path != "/bin") return false;
  for (size_t i = 0; i < BIN_COUNT; i++) {
    out.push_back({String(kBins[i].name), false, (uint32_t)strlen(kBins[i].description)});
  }
  return true;
}

bool binVfsIsDir(const String &path) {
  return path == "/bin";
}

bool binVfsRemove(const String &path) {
  (void)path;
  return false; // приложения зашиты в прошивку - удалить файлом нельзя
}

uint32_t binVfsFileSize(const String &path) {
  if (!path.startsWith("/bin/")) return 0;
  const BinEntry* e = findBin(path.substring(5));
  return e ? (uint32_t)strlen(e->description) : 0;
}

bool binVfsReadFile(const String &path, String &content) {
  if (!path.startsWith("/bin/")) return false;
  const BinEntry* e = findBin(path.substring(5));
  if (!e) return false;
  content = e->description;
  return true;
}

bool binVfsWriteFile(const String &path, const String &content) {
  (void)path; (void)content;
  return false; // read-only манифест; запуск - через run <name>, не через write
}

void binVfsInit() {
  // Реестр статический - launcher регистрируется отдельно, из setup()
  // в .ino, через binVfsSetLauncher(appLaunchByName).
}
