#include "lib_vfs.h"

struct LibEntry {
  const char* name;         // /lib/<name>
  const char* description;  // содержимое при cat
};

// Статический манифест - соответствует разделу README "Необходимые
// библиотеки / настройки Arduino IDE". Обновляйте вручную, если
// список зависимостей проекта меняется.
static const LibEntry kLibs[] = {
  { "arduino-pico",  "arduino-pico core (Earle Philhower), RP2040 board support, >=3.x for SMP FreeRTOS" },
  { "freertos",      "FreeRTOS-Kernel (Earle Philhower RP2040 SMP port) - scheduler for audioProducerTask + UI loop" },
  { "tinyusb",       "Adafruit TinyUSB Library - USB host stack (pio-usb) for flash drive + HID keyboard" },
  { "sdfat",         "SdFat - Adafruit Fork - FatFs access to /sdb1.. USB partitions" },
  { "littlefs",      "LittleFS (bundled with arduino-pico) - backs /sda, the onboard flash filesystem" },
  { "pngdec",        "PNGdec - PNG decoding for the image viewer" },
  { "libhelix",      "arduino-libhelix (Phil Schatzmann) - MP3 decoding for the audio engine, optional (AUDIO_ENABLE_MP3)" },
};
#define LIB_COUNT (sizeof(kLibs) / sizeof(kLibs[0]))

static const LibEntry* findLib(const String &name) {
  for (size_t i = 0; i < LIB_COUNT; i++) {
    if (name == kLibs[i].name) return &kLibs[i];
  }
  return nullptr;
}

bool libVfsExists(const String &path) {
  if (path == "/lib") return true;
  if (path.startsWith("/lib/")) return findLib(path.substring(5)) != nullptr;
  return false;
}

bool libVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  if (path != "/lib") return false;
  for (size_t i = 0; i < LIB_COUNT; i++) {
    out.push_back({String(kLibs[i].name), false, (uint32_t)strlen(kLibs[i].description)});
  }
  return true;
}

bool libVfsIsDir(const String &path) {
  return path == "/lib";
}

bool libVfsRemove(const String &path) {
  (void)path;
  return false; // манифест зашит в прошивку - удалить "библиотеку" файлом нельзя
}

uint32_t libVfsFileSize(const String &path) {
  if (!path.startsWith("/lib/")) return 0;
  const LibEntry* e = findLib(path.substring(5));
  return e ? (uint32_t)strlen(e->description) : 0;
}

bool libVfsReadFile(const String &path, String &content) {
  if (!path.startsWith("/lib/")) return false;
  const LibEntry* e = findLib(path.substring(5));
  if (!e) return false;
  content = e->description;
  return true;
}

bool libVfsWriteFile(const String &path, const String &content) {
  (void)path; (void)content;
  return false; // read-only манифест
}

void libVfsInit() {
  // Статические данные - инициализация не требуется.
}
