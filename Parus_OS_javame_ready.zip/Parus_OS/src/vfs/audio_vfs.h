#pragma once
#include <Arduino.h>
#include <vector>
#include "vfs.h"

// ================================================================
//  audio_vfs.h — /proc/audio/
//
//  The music engine (audio.h/.cpp) already runs as its own
//  producer/consumer FreeRTOS task on core1, decoupled from the UI -
//  a real background "process" (see README's FreeRTOS section). This
//  module just gives that process a face in the VFS, the same way
//  Linux gives every process a /proc/<pid>/ directory: a folder any
//  caller (the UI, a .tu script, or a human typing into bash) can
//  read/write to drive playback, instead of calling audio.h's C++
//  functions directly.
//
//      /proc/audio/status    (r)   "playing|paused|stopped"
//      /proc/audio/track     (r)   currently loaded file path (or empty)
//      /proc/audio/position  (r)   "<bytes played>/<bytes total>"
//      /proc/audio/control   (w)   "play <path>" | "stop" | "pause" |
//                                  "resume"
//      /proc/audio/volume    (rw)  0-100
//      /proc/audio/speed     (rw)  e.g. "1.00"
//      /proc/audio/pid       (r)  FreeRTOS task handle of the producer
//                                  task (core1) - proof it's a real,
//                                  independently-scheduled process and
//                                  not just a flag checked in loop()
// ================================================================

bool     audioVfsExists(const String &path);
bool     audioVfsListDir(const String &path, std::vector<VfsEntry> &out);
bool     audioVfsIsDir(const String &path);
bool     audioVfsRemove(const String &path);
uint32_t audioVfsFileSize(const String &path);
bool     audioVfsReadFile(const String &path, String &content);
bool     audioVfsWriteFile(const String &path, const String &content);

void audioVfsInit();
