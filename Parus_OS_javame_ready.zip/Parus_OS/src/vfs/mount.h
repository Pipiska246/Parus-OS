#pragma once
#include <Arduino.h>
#include <vector>

// ================================================================
//  mount.h — Linux-style mount table
//
//  Before this, "what's mounted where" only lived implicitly inside
//  vfs.cpp's extMounted[] array - fine for the VFS itself, but there
//  was no single place that could answer "what's mounted right now"
//  for a human (bash `mount`) or a script (/proc/mounts). This module
//  is that place: every backend that comes and goes (USB partitions)
//  or is permanent (/sda) registers itself here, and everything else
//  (terminal.cpp's `mount`/`umount`, proc_vfs.cpp's /proc/mounts)
//  just reads the table instead of reaching into vfs.cpp internals.
// ================================================================

struct MountEntry {
  String device;       // "littlefs0", "usb0p1", "usb0p2", ...
  String mountpoint;    // "/sda", "/sdb1", "/sdb2", ...
  String fstype;        // "littlefs", "vfat"
  bool   readOnly;
};

// Registers the always-present /sda entry. Call once from setup(),
// after vfsBegin().
void mountInit();

// Adds one entry (used when a USB partition is found by
// vfsExternalBegin(), once per /sdbN it mounts).
void mountRegister(const String &mountpoint, const String &device,
                   const String &fstype, bool readOnly = false);

// Removes one entry by mountpoint.
void mountUnregister(const String &mountpoint);

// Removes every entry whose mountpoint starts with `prefix`
// (e.g. "/sdb" on full USB unplug, see vfsExternalEnd()).
void mountUnregisterPrefix(const String &prefix);

int  mountCount();
bool mountGet(int index, MountEntry &out);
bool mountFind(const String &mountpoint, MountEntry &out);

// One line per entry, Linux "/proc/mounts"-style:
//   <device> <mountpoint> <fstype> <rw|ro>
String mountProcMounts();
