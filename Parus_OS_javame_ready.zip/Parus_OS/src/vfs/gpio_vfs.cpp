#include "gpio_vfs.h"
#include "vfs.h"
#include <Arduino.h>

// ================================================================
//  GpioManager implementation
// ================================================================
GpioManager gpioManager;

GpioManager::GpioManager() {
  for (int i = 0; i < GPIO_PINS_MAX; i++) {
    _pins[i].mode = GPIO_MODE_UNUSED;
    _pins[i].value = false;
    _pins[i].pullup = false;
    _pins[i].pulldown = false;
  }
}

void GpioManager::begin() {
  int availablePins[] = {6, 7, 8, 9, 10, 11};
  for (int i = 0; i < 6; i++) {
    int pin = availablePins[i];
    _pins[pin].mode = GPIO_MODE_UNUSED;
    _pins[pin].value = false;
    _pins[pin].pullup = false;
    _pins[pin].pulldown = false;
    pinMode(pin, INPUT);
  }
}

bool GpioManager::pinExists(int pin) {
  if (pin < 0 || pin >= GPIO_PINS_MAX) return false;
  return (pin >= 6 && pin <= 11);
}

bool GpioManager::getState(int pin, GpioState &state) {
  if (!pinExists(pin)) return false;
  state = _pins[pin];
  if (state.mode == GPIO_MODE_INPUT) {
    state.value = digitalRead(pin) == HIGH;
  }
  return true;
}

bool GpioManager::setMode(int pin, GpioMode mode, bool pullup, bool pulldown) {
  if (!pinExists(pin)) return false;
  
  _pins[pin].mode = mode;
  _pins[pin].pullup = pullup;
  _pins[pin].pulldown = pulldown;
  
  if (mode == GPIO_MODE_INPUT) {
    if (pullup) {
      pinMode(pin, INPUT_PULLUP);
    } else {
      pinMode(pin, INPUT);
    }
    _pins[pin].value = digitalRead(pin) == HIGH;
  } else if (mode == GPIO_MODE_OUTPUT) {
    pinMode(pin, OUTPUT);
    _pins[pin].value = false;
    digitalWrite(pin, LOW);
  }
  
  return true;
}

bool GpioManager::setValue(int pin, bool value) {
  if (!pinExists(pin)) return false;
  if (_pins[pin].mode != GPIO_MODE_OUTPUT) return false;
  
  _pins[pin].value = value;
  digitalWrite(pin, value ? HIGH : LOW);
  return true;
}

bool GpioManager::getValue(int pin) {
  if (!pinExists(pin)) return false;
  if (_pins[pin].mode == GPIO_MODE_INPUT) {
    _pins[pin].value = digitalRead(pin) == HIGH;
  }
  return _pins[pin].value;
}

bool GpioManager::releasePin(int pin) {
  if (!pinExists(pin)) return false;
  _pins[pin].mode = GPIO_MODE_UNUSED;
  _pins[pin].value = false;
  _pins[pin].pullup = false;
  _pins[pin].pulldown = false;
  pinMode(pin, INPUT);
  return true;
}

std::vector<int> GpioManager::getPins() {
  std::vector<int> pins;
  for (int i = 6; i <= 11; i++) {
    if (_pins[i].mode != GPIO_MODE_UNUSED) {
      pins.push_back(i);
    }
  }
  return pins;
}

String GpioManager::getPinPath(int pin) {
  if (!pinExists(pin)) return "";
  
  GpioState state;
  if (!getState(pin, state)) return "";
  
  if (state.mode == GPIO_MODE_INPUT) {
    return "/dev/input/gpio" + String(pin);
  } else if (state.mode == GPIO_MODE_OUTPUT) {
    return "/dev/output/gpio" + String(pin);
  }
  return "/dev/gpio/gpio" + String(pin);
}

// ================================================================
//  VFS Integration Functions
// ================================================================

bool gpioVfsExists(const String &path) {
  if (path == "/dev") return true;
  if (path == "/dev/gpio") return true;
  if (path == "/dev/input") return true;
  if (path == "/dev/output") return true;
  
  if (path.startsWith("/dev/gpio/gpio")) {
    int pin = path.substring(strlen("/dev/gpio/gpio")).toInt();
    GpioState state;
    if (!gpioManager.getState(pin, state)) return false;
    return state.mode == GPIO_MODE_UNUSED;
  }
  
  if (path.startsWith("/dev/input/gpio")) {
    int pin = path.substring(strlen("/dev/input/gpio")).toInt();
    GpioState state;
    if (!gpioManager.getState(pin, state)) return false;
    return state.mode == GPIO_MODE_INPUT;
  }
  
  if (path.startsWith("/dev/output/gpio")) {
    int pin = path.substring(strlen("/dev/output/gpio")).toInt();
    GpioState state;
    if (!gpioManager.getState(pin, state)) return false;
    return state.mode == GPIO_MODE_OUTPUT;
  }
  
  return false;
}

bool gpioVfsIsDir(const String &path) {  // ← НОВАЯ ФУНКЦИЯ
  if (path == "/dev") return true;
  if (path == "/dev/gpio") return true;
  if (path == "/dev/input") return true;
  if (path == "/dev/output") return true;
  return false;
}

bool gpioVfsListDir(const String &path, std::vector<VfsEntry> &out) {
  
    if (path == "/dev") {
    out.push_back({"gpio", true, 0});
    out.push_back({"input", true, 0});
    out.push_back({"output", true, 0});
    out.push_back({"display", true, 0});  // ← ДОБАВИТЬ
    out.push_back({"serial", true, 0});   // ← ДОБАВИТЬ
    return true;
  }
  
  if (path == "/dev/gpio") {
    for (int pin = 6; pin <= 11; pin++) {
      GpioState state;
      if (gpioManager.getState(pin, state) && state.mode == GPIO_MODE_UNUSED) {
        out.push_back({"gpio" + String(pin), false, 0});
      }
    }
    return true;
  }
  
  if (path == "/dev/input") {
    // Кнопки и клавиатура (input_vfs.h/.cpp) - самостоятельные
    // подпапки внутри /dev/input, наравне с input-пинами GPIO общего
    // назначения.
    out.push_back({"buttons", true, 0});
    out.push_back({"keyboard", true, 0});
    for (int pin = 6; pin <= 11; pin++) {
      GpioState state;
      if (gpioManager.getState(pin, state) && state.mode == GPIO_MODE_INPUT) {
        out.push_back({"gpio" + String(pin), false, 0});
      }
    }
    return true;
  }
  
  if (path == "/dev/output") {
    for (int pin = 6; pin <= 11; pin++) {
      GpioState state;
      if (gpioManager.getState(pin, state) && state.mode == GPIO_MODE_OUTPUT) {
        out.push_back({"gpio" + String(pin), false, 0});
      }
    }
    return true;
  }
  
  return false;  // Если путь не обработан
}

bool gpioVfsRemove(const String &path) {
  int pin = -1;
  
  if (path.startsWith("/dev/input/gpio")) {
    pin = path.substring(strlen("/dev/input/gpio")).toInt();
  } else if (path.startsWith("/dev/output/gpio")) {
    pin = path.substring(strlen("/dev/output/gpio")).toInt();
  }
  
  if (pin < 0) return false;
  return gpioManager.releasePin(pin);
}

uint32_t gpioVfsFileSize(const String &path) {
  if (path.startsWith("/dev/input/gpio")) return 1;
  if (path.startsWith("/dev/output/gpio")) return 1;
  return 0;
}

bool gpioVfsReadFile(const String &path, String &content) {
  int pin = -1;
  
  if (path.startsWith("/dev/input/gpio")) {
    pin = path.substring(strlen("/dev/input/gpio")).toInt();
    GpioState state;
    if (!gpioManager.getState(pin, state)) return false;
    if (state.mode != GPIO_MODE_INPUT) return false;
    
    bool value = gpioManager.getValue(pin);
    content = String(value ? "1\n" : "0\n");
    return true;
  }
  
  if (path.startsWith("/dev/output/gpio")) {
    pin = path.substring(strlen("/dev/output/gpio")).toInt();
    GpioState state;
    if (!gpioManager.getState(pin, state)) return false;
    if (state.mode != GPIO_MODE_OUTPUT) return false;
    
    content = String(state.value ? "1\n" : "0\n");
    return true;
  }
  
  return false;
}

bool gpioVfsWriteFile(const String &path, const String &content) {
  int pin = -1;
  String cmd = content;
  cmd.trim();
  
  if (path.startsWith("/dev/gpio/gpio")) {
    pin = path.substring(strlen("/dev/gpio/gpio")).toInt();
    
    if (cmd == "mode input") {
      return gpioManager.setMode(pin, GPIO_MODE_INPUT, false, false);
    } else if (cmd == "mode input_pullup") {
      return gpioManager.setMode(pin, GPIO_MODE_INPUT, true, false);
    } else if (cmd == "mode output") {
      return gpioManager.setMode(pin, GPIO_MODE_OUTPUT, false, false);
    }
    return false;
  }
  
  if (path.startsWith("/dev/output/gpio")) {
    pin = path.substring(strlen("/dev/output/gpio")).toInt();
    
    if (cmd == "1" || cmd == "high" || cmd == "on") {
      return gpioManager.setValue(pin, true);
    } else if (cmd == "0" || cmd == "low" || cmd == "off") {
      return gpioManager.setValue(pin, false);
    } else if (cmd == "mode input") {
      return gpioManager.setMode(pin, GPIO_MODE_INPUT, false, false);
    } else if (cmd == "mode input_pullup") {
      return gpioManager.setMode(pin, GPIO_MODE_INPUT, true, false);
    }
    return false;
  }
  
  if (path.startsWith("/dev/input/gpio")) {
    pin = path.substring(strlen("/dev/input/gpio")).toInt();
    
    if (cmd == "mode output") {
      return gpioManager.setMode(pin, GPIO_MODE_OUTPUT, false, false);
    } else if (cmd == "mode input_pullup") {
      return gpioManager.setMode(pin, GPIO_MODE_INPUT, true, false);
    }
    return false;
  }
  
  return false;
}