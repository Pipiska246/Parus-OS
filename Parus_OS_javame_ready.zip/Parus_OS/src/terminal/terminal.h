#pragma once
#include <Arduino.h>
#include <vector>


// ================================================================
//  terminal.h — a small bash-like shell over the VFS (/sda, /sdb1..)
//
//  Supported commands: ls, cd, pwd, mkdir, rmdir, rm, cat, echo, mv,
//  clear, help. `nano <file>` / `edit <file>` doesn't edit inline -
//  it asks the caller (the main sketch) to switch to STATE_EDITOR by
//  making terminalWantsEditor() return true with the resolved path.
// ================================================================

void terminalInit();              // call once from setup()
void terminalOnEnter();           // call when switching into STATE_TERMINAL

// Feed one committed character/action from either the on-screen
// keyboard or a physical USB keyboard. 0x08='\b' backspace, '\n' or
// '\r' = run the current line, everything else printable is inserted
// at the cursor. Returns true if the screen should be redrawn.
bool terminalFeedChar(char c);
bool terminalMoveCursor(int delta);   // move within the current input line
void terminalHistoryUp();
void terminalHistoryDown();

// Renders the console (scrollback + input line) into the area above
// the on-screen keyboard panel.
void terminalDraw(int height);

// True exactly once after a `nano`/`edit` command runs; fills
// pathOut with the file to open and clears the flag.
bool terminalWantsEditor(String &pathOut);

// True exactly once after an `exit`/`quit` command runs.
bool terminalWantsExit();
// В конце файла добавить:
void terminalToggleOsk();
bool terminalHasOskChar();
char terminalGetOskChar();
void terminalClear();
void terminalToggleOsk();
void terminalClear();

// ================================================================
//  Самопроверка / системная интроспекция
// ================================================================
// Список переменных bash (имя/значение) - "система" (boot self-test,
// либо в будущем любой другой код) может посмотреть, что сейчас лежит
// в shell-переменных, не трогая внутреннее состояние terminal.cpp.
void terminalListVars(std::vector<String> &namesOut, std::vector<String> &valuesOut);

// Выполняет одну bash-команду "от лица системы": не трогает текущий
// введённый пользователем текст (s_input), результат уходит в обычный
// scrollback (как если бы команду ввели руками). Используется загрузочным
// self-test'ом, чтобы прогонять реальный bash-движок, а не его копию.
void terminalRunSystemCommand(const String &cmdLine);

// Возвращает последние N строк scrollback-а (после самых свежих команд) -
// нужно self-test'у, чтобы решить, успешно ли отработала команда.
void terminalGetLastLines(int n, std::vector<String> &outLines);