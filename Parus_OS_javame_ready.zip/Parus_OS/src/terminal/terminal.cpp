#include "terminal.h"
#include "../core/ui_common.h"
#include "../vfs/vfs.h"
#include <vector>
#include <ctype.h>
#include <string.h>
#include "../ui/osk_terminal.h"
#include "../scripting/turbine_interp.h"   // только объявление типа TInterp - реализация уже скомпонована в .ino
#include "../net/net.h"
#include "../audio/audio.h"     // play/stop/pause/resume/volume/speed - см. cmdPlay/cmdAudio
#include "../vfs/mount.h"     // mount/umount
#include "../vfs/bin_vfs.h"   // run <program>

// доступ к глобалам/настройкам, определённым в TextReaderVFS.ino - нужны
// команде "settings" (samplerate/rotation/brightness с автосохранением)
extern uint32_t audioSampleRate;
extern int      displayRotation;
extern uint8_t  displayBrightness;
extern float    audioSpeed;
extern void     saveSettings();
extern void     sendSetRotation(uint8_t r);
extern void     setDisplayBrightness(uint8_t b);
extern void     setSpeed(float speed);

// gTurbine и tuInitCallbacks() определены в turbine_integration.h (включается
// из TextReaderVFS.ino) - сюда их подключать нельзя (там же определяется сам
// объект gTurbine, повторное включение = ошибка линковки "multiple definition").
extern TInterp gTurbine;
extern void tuInitCallbacks();


static bool s_oskActive = false;





// В начале файла добавить глобальные переменные:


#define TERM_VISIBLE_LINES   9
#define TERM_SCROLLBACK_MAX  120
#define TERM_LINE_MAX        96
#define TERM_HISTORY_MAX     16
#define TERM_HISTORY_FILE    "/sda/.bash_history"

static std::vector<String> s_scrollback;
static String s_input;
static int    s_cursor = 0;
static String s_cwd = "/";

static std::vector<String> s_history;
static int s_historyPos = -1;

static String s_pendingEditorPath = "";
static bool   s_wantEditor = false;
static bool   s_wantExit = false;

// ----------------------------------------------------------------
//  shell variables: имена и значения хранятся в двух параллельных
//  массивах (как и просили) - s_varNames[i] <-> s_varValues[i]
// ----------------------------------------------------------------
static std::vector<String> s_varNames;
static std::vector<String> s_varValues;

// ----------------------------------------------------------------
//  shell functions
// ----------------------------------------------------------------
struct ShellFunction {
  String name;
  std::vector<String> body;
};
static std::vector<ShellFunction> s_functions;

// ----------------------------------------------------------------
//  multi-line capture (if/while/for/function typed interactively)
// ----------------------------------------------------------------
static std::vector<String> s_captureLines;
static int  s_captureDepth = 0;
static bool s_capturing = false;
static int  s_scriptDepth = 0;   // защита от бесконечной рекурсии функций
#define TERM_MAX_SCRIPT_DEPTH 12
#define TERM_MAX_LOOP_ITERS   2000

// ----------------------------------------------------------------
//  helpers
// ----------------------------------------------------------------
static void termPrint(const String &s) {
  s_scrollback.push_back(s);
  while (s_scrollback.size() > TERM_SCROLLBACK_MAX) s_scrollback.erase(s_scrollback.begin());
}

static String stripQuotes(const String &sIn) {
  String s = sIn;
  s.trim();
  if (s.length() >= 2 && s[0] == '"' && s[s.length() - 1] == '"') {
    s = s.substring(1, s.length() - 1);
  }
  return s;
}

// Resolves a (possibly relative) argument against s_cwd into a clean
// absolute VFS path, handling "." and "..", without ever climbing
// above "/". Принимает аргумент как с кавычками, так и без - кавычки
// снимаются автоматически (после подстановки $VAR, которая делается
// раньше в expandVars()).
static String resolvePath(const String &argIn) {
  String arg = stripQuotes(argIn);
  String base = arg.length() && arg[0] == '/' ? arg : (s_cwd == "/" ? ("/" + arg) : (s_cwd + "/" + arg));
  std::vector<String> parts;
  int i = 0;
  while (i < (int)base.length()) {
    while (i < (int)base.length() && base[i] == '/') i++;
    int start = i;
    while (i < (int)base.length() && base[i] != '/') i++;
    if (i > start) {
      String tok = base.substring(start, i);
      if (tok == ".") { /* no-op */ }
      else if (tok == "..") { if (!parts.empty()) parts.pop_back(); }
      else parts.push_back(tok);
    }
  }
  String out = "/";
  for (size_t p = 0; p < parts.size(); p++) { if (out != "/") out += "/"; out += parts[p]; }
  return out;
}

static void splitArgs(const String &line, std::vector<String> &out) {
  String cur; bool inTok = false; bool inQuotes = false;
  for (size_t i = 0; i < line.length(); i++) {
    char c = line[i];
    if (c == '"') { inQuotes = !inQuotes; inTok = true; continue; } // кавычка - не часть токена
    if (c == ' ' && !inQuotes) { if (inTok) { out.push_back(cur); cur = ""; inTok = false; } }
    else { cur += c; inTok = true; }
  }
  if (inTok) out.push_back(cur);
}

// Находит первое вхождение needle, не находящееся внутри "..." кавычек.
// Нужно для echo, чтобы '>'/'>>'  внутри строки (echo "a>b") не путались
// с перенаправлением в файл.
static int findUnquoted(const String &s, const char *needle) {
  int needleLen = (int)strlen(needle);
  bool q = false;
  for (int i = 0; i + needleLen <= (int)s.length(); i++) {
    if (s[i] == '"') { q = !q; continue; }
    if (!q && s.substring(i, i + needleLen) == needle) return i;
  }
  return -1;
}

// ----------------------------------------------------------------
//  history persistence (LittleFS, /sda/.bash_history)
// ----------------------------------------------------------------
static void loadHistoryFromDisk() {
  VfsFile f;
  if (!f.openRead(TERM_HISTORY_FILE)) return;
  String line; uint8_t b;
  while (f.read(&b, 1) == 1) {
    if (b == '\r') continue;
    if (b == '\n') { if (line.length()) s_history.push_back(line); line = ""; }
    else line += (char)b;
  }
  if (line.length()) s_history.push_back(line);
  f.close();
  while (s_history.size() > TERM_HISTORY_MAX) s_history.erase(s_history.begin());
}

static void appendHistoryToDisk(const String &cmd) {
  VfsFile f;
  if (!f.openWrite(TERM_HISTORY_FILE, true)) return;
  f.write((const uint8_t *)cmd.c_str(), cmd.length());
  f.write((const uint8_t *)"\n", 1);
  f.close();
}

// ----------------------------------------------------------------
//  variables: get/set, поиск по массиву имён
// ----------------------------------------------------------------
static int varFindIndex(const String &name) {
  for (size_t i = 0; i < s_varNames.size(); i++) {
    if (s_varNames[i] == name) return (int)i;
  }
  return -1;
}

static String varGet(const String &name) {
  int i = varFindIndex(name);
  return i >= 0 ? s_varValues[i] : "";
}

static void varSet(const String &name, const String &value) {
  int i = varFindIndex(name);
  if (i >= 0) s_varValues[i] = value;
  else { s_varNames.push_back(name); s_varValues.push_back(value); }
}

static bool varUnset(const String &name) {
  int i = varFindIndex(name);
  if (i < 0) return false;
  s_varNames.erase(s_varNames.begin() + i);
  s_varValues.erase(s_varValues.begin() + i);
  return true;
}

// Подстановка $NAME / ${NAME} в строке значениями переменных.
static String expandVars(const String &lineIn) {
  String out;
  out.reserve(lineIn.length() + 8);
  for (size_t i = 0; i < lineIn.length(); i++) {
    char c = lineIn[i];
    if (c == '$' && i + 1 < lineIn.length()) {
      size_t j = i + 1;
      bool braced = false;
      if (lineIn[j] == '{') { braced = true; j++; }
      size_t start = j;
      while (j < lineIn.length() && (isalnum((unsigned char)lineIn[j]) || lineIn[j] == '_')) j++;
      String name = lineIn.substring(start, j);
      if (braced) { if (j < lineIn.length() && lineIn[j] == '}') j++; }
      if (name.length() > 0) {
        out += varGet(name);
        i = j - 1;
        continue;
      }
    }
    out += c;
  }
  return out;
}

// ----------------------------------------------------------------
//  functions: поиск/регистрация
// ----------------------------------------------------------------
static int funcFindIndex(const String &name) {
  for (size_t i = 0; i < s_functions.size(); i++) {
    if (s_functions[i].name == name) return (int)i;
  }
  return -1;
}

static void funcDefine(const ShellFunction &f) {
  int i = funcFindIndex(f.name);
  if (i >= 0) s_functions[i] = f;
  else s_functions.push_back(f);
}

// читает все строки файла в вектор (общая утилита для bash<file>/funcload)
static bool readLinesFromFile(const String &path, std::vector<String> &out) {
  VfsFile f;
  if (!f.openRead(path)) return false;
  String line; uint8_t b;
  while (f.read(&b, 1) == 1) {
    if (b == '\r') continue;
    if (b == '\n') { out.push_back(line); line = ""; }
    else line += (char)b;
  }
  if (line.length()) out.push_back(line);
  f.close();
  return true;
}

static void cmdFuncLoad(const String &name, const String &path) {
  if (name.length() == 0 || path.length() == 0) { termPrint("funcload: usage: funcload <name> <file>"); return; }
  String target = resolvePath(path);
  ShellFunction sf; sf.name = name;
  if (!readLinesFromFile(target, sf.body)) { termPrint("funcload: cannot open: " + target); return; }
  funcDefine(sf);
  termPrint("function '" + name + "' loaded (" + String(sf.body.size()) + " lines)");
}

// ----------------------------------------------------------------
//  условия для if/while:  -f path  -d path  a==b  a!=b  a -lt b ...
// ----------------------------------------------------------------
static bool evalCondition(const String &condIn) {
  String cond = condIn; cond.trim();
  std::vector<String> t;
  splitArgs(cond, t);
  if (t.empty()) return false;

  if (t[0] == "-f" && t.size() > 1) { String p = resolvePath(t[1]); return vfsExists(p) && !vfsIsDir(p); }
  if (t[0] == "-d" && t.size() > 1) { String p = resolvePath(t[1]); return vfsExists(p) && vfsIsDir(p); }
  if (t[0] == "!" && t.size() > 1) {
    String rest = cond.substring(cond.indexOf('!') + 1); rest.trim();
    return !evalCondition(rest);
  }

  if (t.size() >= 3) {
    String a = t[0], op = t[1], b = t[2];
    if (op == "==") return a == b;
    if (op == "!=") return a != b;
    float fa = a.toFloat(), fb = b.toFloat();
    if (op == "-lt") return fa < fb;
    if (op == "-gt") return fa > fb;
    if (op == "-le") return fa <= fb;
    if (op == "-ge") return fa >= fb;
    if (op == "-eq") return fa == fb;
    if (op == "-ne") return fa != fb;
  }

  if (t.size() == 1) return t[0].length() > 0 && t[0] != "0";
  return false;
}

// ----------------------------------------------------------------
//  assignment detection:  NAME=value   (без пробелов в NAME, не "==")
// ----------------------------------------------------------------
static bool isAssignment(const String &line, String &name, String &rhs) {
  int eq = line.indexOf('=');
  if (eq <= 0) return false;
  if (eq + 1 < (int)line.length() && line[eq + 1] == '=') return false; // "=="
  int sp = line.indexOf(' ');
  if (sp >= 0 && sp < eq) return false; // "echo a=b" - не присвоение

  String lhs = line.substring(0, eq);
  if (!(isalpha((unsigned char)lhs[0]) || lhs[0] == '_')) return false;
  for (size_t i = 0; i < lhs.length(); i++) {
    char c = lhs[i];
    if (!(isalnum((unsigned char)c) || c == '_')) return false;
  }
  name = lhs;
  rhs = line.substring(eq + 1);
  return true;
}

// Вычисляет правую часть присвоения: поддерживает $(cat path),
// подстановку $VAR и обрезку обрамляющих кавычек.
static String evalRhs(String rhs) {
  rhs.trim();
  if (rhs.length() >= 2 && rhs[0] == '"' && rhs[rhs.length() - 1] == '"') {
    rhs = rhs.substring(1, rhs.length() - 1);
  }
  if (rhs.startsWith("$(") && rhs.endsWith(")")) {
    String inner = rhs.substring(2, rhs.length() - 1);
    inner.trim();
    if (inner.startsWith("cat ")) {
      String path = resolvePath(expandVars(inner.substring(4)));
      VfsFile f;
      String content = "";
      if (f.openRead(path)) {
        uint8_t b;
        bool first = true;
        while (f.read(&b, 1) == 1) {
          if (b == '\r') continue;
          if (b == '\n') { if (!first) content += ' '; }
          else content += (char)b;
          first = false;
        }
        f.close();
        content.trim();
      }
      return content;
    }
    return "";
  }
  return expandVars(rhs);
}

// ----------------------------------------------------------------
//  commands
// ----------------------------------------------------------------
static void cmdLs(const String &argPath) {
  String target = argPath.length() ? resolvePath(argPath) : s_cwd;
  std::vector<VfsEntry> entries;
  if (!vfsListDir(target, entries)) { termPrint("ls: cannot access '" + target + "'"); return; }
  if (entries.empty()) { termPrint("(empty)"); return; }
  for (auto &e : entries) {
    String line = e.isDir ? ("d  " + e.name + "/") : ("f  " + e.name + "  " + String(e.size) + "B");
    termPrint(line);
  }
}

static void cmdCd(const String &argPath) {
  if (argPath.length() == 0) { s_cwd = "/"; return; }
  String target = resolvePath(argPath);
  if (!vfsExists(target) || !vfsIsDir(target)) { termPrint("cd: no such directory: " + target); return; }
  s_cwd = target;
}

static void cmdMkdir(const String &argPath) {
  if (argPath.length() == 0) { termPrint("mkdir: missing operand"); return; }
  String target = resolvePath(argPath);
  termPrint(vfsMkdir(target) ? ("created " + target) : ("mkdir: failed: " + target));
}

static void cmdRmdir(const String &argPath) {
  if (argPath.length() == 0) { termPrint("rmdir: missing operand"); return; }
  String target = resolvePath(argPath);
  termPrint(vfsRmdir(target) ? ("removed " + target) : ("rmdir: failed (not empty?): " + target));
}

static void cmdRm(const String &argPath) {
  if (argPath.length() == 0) { termPrint("rm: missing operand"); return; }
  String target = resolvePath(argPath);
  if (vfsIsDir(target)) { termPrint("rm: '" + target + "' is a directory (use rmdir)"); return; }
  termPrint(vfsRemove(target) ? ("removed " + target) : ("rm: failed: " + target));
}

static void cmdMv(const String &a, const String &b) {
  if (a.length() == 0 || b.length() == 0) { termPrint("mv: usage: mv <src> <dst>"); return; }
  String src = resolvePath(a), dst = resolvePath(b);
  termPrint(vfsRename(src, dst) ? ("moved " + src + " -> " + dst)
                                 : ("mv: failed (different storage device?): " + src));
}

static void cmdCat(const String &argPath) {
  if (argPath.length() == 0) { termPrint("cat: missing operand"); return; }
  String target = resolvePath(argPath);
  VfsFile f;
  if (!f.openRead(target)) { termPrint("cat: cannot open: " + target); return; }
  String line; uint8_t b; uint32_t shown = 0;
  const uint32_t MAX_SHOW = 4000; // keep memory/scrollback bounded
  while (f.read(&b, 1) == 1 && shown < MAX_SHOW) {
    shown++;
    if (b == '\r') continue;
    if (b == '\n') { termPrint(line); line = ""; }
    else line += (char)b;
  }
  if (line.length()) termPrint(line);
  if (shown >= MAX_SHOW) termPrint("... (truncated)");
  f.close();
}

// echo text            -> prints text
// echo text > file     -> overwrite file with text
// echo text >> file    -> append text to file
// Поддерживает кавычки: echo "test" > "$path/test.txt" - '>' внутри
// кавычек не считается перенаправлением, а кавычки в тексте/пути снимаются.
static void cmdEcho(const String &rest) {
  int gtgt = findUnquoted(rest, ">>");
  int gt = findUnquoted(rest, ">");
  if (gtgt >= 0) {
    String text = stripQuotes(rest.substring(0, gtgt));
    String path = stripQuotes(rest.substring(gtgt + 2));
    if (path.length() == 0) { termPrint(text); return; }
    String target = resolvePath(path);
    VfsFile f;
    if (!f.openWrite(target, true)) { termPrint("echo: cannot open: " + target); return; }
    f.write((const uint8_t *)text.c_str(), text.length());
    f.write((const uint8_t *)"\n", 1);
    f.close();
  } else if (gt >= 0) {
    String text = stripQuotes(rest.substring(0, gt));
    String path = stripQuotes(rest.substring(gt + 1));
    if (path.length() == 0) { termPrint(text); return; }
    String target = resolvePath(path);
    VfsFile f;
    if (!f.openWrite(target, false)) { termPrint("echo: cannot open: " + target); return; }
    f.write((const uint8_t *)text.c_str(), text.length());
    f.write((const uint8_t *)"\n", 1);
    f.close();
  } else {
    termPrint(stripQuotes(rest));
  }
}

static void cmdVars() {
  if (s_varNames.empty()) { termPrint("(no variables)"); return; }
  for (size_t i = 0; i < s_varNames.size(); i++) {
    termPrint(s_varNames[i] + "=" + s_varValues[i]);
  }
}

static void cmdFuncs() {
  if (s_functions.empty()) { termPrint("(no functions)"); return; }
  for (auto &f : s_functions) {
    termPrint(f.name + "  (" + String(f.body.size()) + " lines)");
  }
}

static void runLines(std::vector<String> &lines, int start, int end);

static void cmdWifi(const String &rest) {
  std::vector<String> a; splitArgs(rest, a);
  String sub = a.empty() ? "" : a[0];
  if (sub == "connect") {
    if (a.size() < 3) { termPrint("usage: wifi connect <ssid> <password>"); return; }
    termPrint("wifi: connecting to '" + a[1] + "'...");
    bool ok = netWifiConnect(a[1], a[2]);
    termPrint(ok ? "wifi: connected" : "wifi: FAILED to connect");
    if (ok) netSaveWifiConfig(a[1], a[2]); // запомним для автоподключения при старте
  } else if (sub == "status") {
    bool c; int rssi; String ip;
    if (!netWifiStatus(c, rssi, ip)) { termPrint("wifi: no response from ESP32"); return; }
    if (c) {
      termPrint("wifi: connected");
      termPrint("ip=" + ip);
      termPrint("rssi=" + String(rssi) + "dBm");
    } else {
      termPrint("wifi: not connected");
    }
  } else if (sub == "disconnect") {
    netWifiDisconnect();
    termPrint("wifi: disconnected");
  } else {
    termPrint("usage: wifi connect <ssid> <pass> | wifi status | wifi disconnect");
  }
}

static void cmdTime(const String &rest) {
  String sub = rest; sub.trim();
  if (sub == "sync") {
    termPrint("time: sync (NTP->worldtimeapi->yandex)...");
    bool ok = netTimeSync();
    termPrint(ok ? ("time: OK -> " + netTimeFull()) : "time: все три метода не сработали");
  } else {
    termPrint(netTimeFull());
  }
}

static void cmdCurl(const String &rest) {
  // curl <url>          -> печатает тело в консоль
  // curl <url> > file    -> сохраняет тело в файл
  int gt = findUnquoted(rest, ">");
  String url  = stripQuotes(gt >= 0 ? rest.substring(0, gt) : rest);
  url.trim();
  if (url.length() == 0) { termPrint("usage: curl <url> [> file]"); return; }

  String body; int status;
  termPrint("curl: GET " + url);
  bool ok = netHttpGet(url, body, status);
  if (!ok) { termPrint("curl: error (status " + String(status) + ")"); return; }
  termPrint("curl: HTTP " + String(status) + ", " + String(body.length()) + " bytes");

  if (gt >= 0) {
    String path = stripQuotes(rest.substring(gt + 1));
    if (path.length() == 0) { termPrint("curl: missing output file after '>'"); return; }
    String target = resolvePath(path);
    VfsFile f;
    if (!f.openWrite(target, false)) { termPrint("curl: cannot write: " + target); return; }
    f.write((const uint8_t *)body.c_str(), body.length());
    f.close();
    termPrint("curl: saved to " + target);
  } else {
    // печатаем построчно, чтобы длинный ответ не утонул в одной "строке"
    int start = 0;
    const int MAX_PRINT = 2000; // не топим scrollback гигантскими ответами
    String shown = body.length() > MAX_PRINT ? body.substring(0, MAX_PRINT) : body;
    while (start < (int)shown.length()) {
      int nl = shown.indexOf('\n', start);
      if (nl < 0) { termPrint(shown.substring(start)); break; }
      termPrint(shown.substring(start, nl));
      start = nl + 1;
    }
    if (body.length() > MAX_PRINT) termPrint("... (truncated, used curl <url> > file for full output)");
  }
}

static void cmdPing(const String &rest) {
  String host = rest; host.trim();
  if (host.length() == 0) { termPrint("usage: ping <host>"); return; }
  termPrint("PING " + host + " (tcp:80)...");
  int rtt;
  bool ok = netPing(host, rtt);
  if (ok) termPrint("reply from " + host + ": time=" + String(rtt) + "ms");
  else    termPrint("ping: timeout / unreachable");
}

// settings show
// settings samplerate <Hz>     - частота/битрейт для PCM-файлов (1000-48000)
// settings rotation <0-3>      - поворот экрана (как в Settings меню)
// settings brightness <0-100>  - яркость подсветки в процентах
// Каждое изменение сразу автосохраняется (saveSettings()).
static void cmdSettings(const String &rest) {
  std::vector<String> a; splitArgs(rest, a);
  String sub = a.empty() ? "" : a[0];

  if (sub == "show" || sub.length() == 0) {
    termPrint("samplerate=" + String(audioSampleRate) + "Hz");
    termPrint("rotation=" + String(displayRotation));
    termPrint("brightness=" + String((int)(displayBrightness * 100 / 255)) + "%");
    return;
  }
  if (sub == "samplerate") {
    if (a.size() < 2) { termPrint("usage: settings samplerate <1000-48000>"); return; }
    long v = a[1].toInt();
    if (v < 1000 || v > 48000) { termPrint("settings: samplerate out of range (1000-48000)"); return; }
    audioSampleRate = (uint32_t)v;
    setSpeed(audioSpeed); // пересчитывает аппаратный sample-clock под новую частоту
    saveSettings();
    termPrint("samplerate=" + String(audioSampleRate) + "Hz (saved)");
    return;
  }
  if (sub == "rotation") {
    if (a.size() < 2) { termPrint("usage: settings rotation <0-3>"); return; }
    int v = a[1].toInt();
    if (v < 0 || v > 3) { termPrint("settings: rotation must be 0-3"); return; }
    displayRotation = v;
    sendSetRotation((uint8_t)displayRotation);
    saveSettings();
    termPrint("rotation=" + String(displayRotation) + " (saved)");
    return;
  }
  if (sub == "brightness") {
    if (a.size() < 2) { termPrint("usage: settings brightness <0-100>"); return; }
    int pct = a[1].toInt();
    if (pct < 0 || pct > 100) { termPrint("settings: brightness must be 0-100"); return; }
    setDisplayBrightness((uint8_t)(pct * 255 / 100));
    saveSettings();
    termPrint("brightness=" + String(pct) + "% (saved)");
    return;
  }
  termPrint("usage: settings show | samplerate <Hz> | rotation <0-3> | brightness <0-100>");
}

// ----------------------------------------------------------------
//  mount / umount — читают/меняют таблицу монтирования (mount.h);
//  сама флешка по-прежнему подключается автоматически по USB (см.
//  tuh_msc_mount_cb в .ino) - "mount" здесь в первую очередь для
//  просмотра, а "umount" - чтобы явно освободить флешку перед тем,
//  как её вынуть.
// ----------------------------------------------------------------
static void cmdMount(const String &rest) {
  std::vector<String> a; splitArgs(rest, a);
  if (a.empty()) {
    int n = mountCount();
    if (n == 0) { termPrint("mount: nothing mounted"); return; }
    for (int i = 0; i < n; i++) {
      MountEntry e;
      if (mountGet(i, e)) {
        termPrint(e.device + " on " + e.mountpoint + " type " + e.fstype + (e.readOnly ? " (ro)" : " (rw)"));
      }
    }
    return;
  }
  termPrint("mount: storage mounts automatically on plug-in; use 'umount <mountpoint>' before unplugging");
}

static void cmdUmount(const String &rest) {
  String mp = rest; mp.trim();
  if (mp.length() == 0) { termPrint("usage: umount <mountpoint>"); return; }
  if (mp == "/sda") { termPrint("umount: /sda (onboard flash) can't be unmounted"); return; }
  if (mp.startsWith("/sdb")) {
    if (!vfsExternalMounted()) { termPrint("umount: " + mp + ": not mounted"); return; }
    vfsExternalEnd();  // отпускает все /sdbN разом - у платы один USB-host порт
    termPrint("umount: " + mp + " released, safe to unplug the USB drive");
    return;
  }
  termPrint("umount: " + mp + ": not a mountpoint");
}

// ----------------------------------------------------------------
//  play/stop/pause/resume/volume/speed/audiostatus — управление
//  аудио-"процессом" (audio.h/.cpp, отдельная FreeRTOS-задача на
//  core1, см. README) прямо из bash. Те же самые действия доступны
//  и через файлы /proc/audio/* (audio_vfs.h/.cpp) - команды здесь
//  просто более удобная запись для интерактивной консоли.
// ----------------------------------------------------------------
static void cmdPlay(const String &rest) {
  if (rest.length() == 0) { termPrint("usage: play <file>"); return; }
  String target = resolvePath(rest);
  termPrint(startMusic(target) ? ("play: " + target) : ("play: failed to start " + target));
}

static void cmdVolume(const String &rest) {
  String s = rest; s.trim();
  if (s.length() > 0) {
    int v = s.toInt();
    if (v < 0) v = 0;
    if (v > 100) v = 100;
    setVolume((uint8_t)v);
  }
  termPrint("volume=" + String(audioVolume));
}

static void cmdSpeedCmd(const String &rest) {
  String s = rest; s.trim();
  if (s.length() > 0) {
    float v = s.toFloat();
    if (v > 0.1f && v < 4.0f) setSpeed(v);
  }
  termPrint("speed=" + String(audioSpeed, 2));
}

static void cmdAudioStatus() {
  termPrint(String("status=") + (musicPlaying ? (musicPaused ? "paused" : "playing") : "stopped"));
  termPrint("track=" + musicFileNameForUI);
  termPrint("position=" + String(musicPosition) + "/" + String(musicTotalSize));
  termPrint("pid=" + String(audioTaskId()) + " (core1)");
}

// ----------------------------------------------------------------
//  run <program> — запускает приложение из /bin (bin_vfs.h/.cpp);
//  сама смена экрана делается в .ино через appLaunchByName(),
//  зарегистрированную вызовом binVfsSetLauncher() в setup().
// ----------------------------------------------------------------
static void cmdRun(const String &rest) {
  String prog = rest; prog.trim();
  if (prog.length() == 0) { termPrint("usage: run <program>  (see: ls /bin)"); return; }
  if (!binVfsRun(prog)) termPrint("run: " + prog + ": no such program (see: ls /bin)");
}

// ----------------------------------------------------------------
//  ps — простейший список "процессов": UI-цикл на core0 и
//  аудио-задача на core1, если она сейчас реально проигрывает.
// ----------------------------------------------------------------
static void cmdPs(const String &rest) {
  (void)rest;
  termPrint("PID  CORE  STATE    NAME");
  termPrint("0    0     running  ui-loop");
  String state = musicPlaying ? (musicPaused ? "paused " : "running") : "idle   ";
  termPrint(String(audioTaskId() ? "1" : "-") + "    1     " + state + "  audioProducer");
}

static void cmdBashFile(const String &argPath) {
  if (argPath.length() == 0) { termPrint("bash: missing operand"); return; }
  String target = resolvePath(argPath);
  std::vector<String> lines;
  if (!readLinesFromFile(target, lines)) { termPrint("bash: cannot open: " + target); return; }
  if (lines.empty()) return;
  runLines(lines, 0, (int)lines.size() - 1);
}

// печатает вывод .tu-скрипта прямо в окно терминала (а не в полноэкранный
// раннер) - используется только пока выполняется cmdTu()
static void tuTermPrintCallback(const char* s) {
  String str(s);
  int start = 0;
  while (true) {
    int nl = str.indexOf('\n', start);
    if (nl < 0) { if (start < (int)str.length()) termPrint(str.substring(start)); break; }
    termPrint(str.substring(start, nl));
    start = nl + 1;
  }
}

static void cmdTu(const String &argPath) {
  if (argPath.length() == 0) { termPrint("tu: usage: tu <file.tu>"); return; }
  String target = resolvePath(argPath);
  tuInitCallbacks();                       // безопасно звать повторно
  void (*savedPrint)(const char*) = gTurbine.cbPrint;
  gTurbine.cbPrint = tuTermPrintCallback;  // на время запуска - в bash, не на весь экран
  bool ok = gTurbine.runFile(target);
  gTurbine.cbPrint = savedPrint;
  if (!ok) termPrint("tu error: " + gTurbine.errMsg);
  else     termPrint("(tu: done)");
}

static void runCommand(const String &lineIn);

// ----------------------------------------------------------------
//  блочный интерпретатор: if/else/endif, while/endwhile,
//  for VAR in v1 v2 .../endfor, function NAME/endfunction
// ----------------------------------------------------------------
static int findMatchingEnd(const std::vector<String> &lines, int start,
                            const String &openKw, const String &closeKw, int *elseIdx) {
  int depth = 1;
  if (elseIdx) *elseIdx = -1;
  for (size_t i = start + 1; i < lines.size(); i++) {
    String t = lines[i]; t.trim();
    int sp = t.indexOf(' ');
    String first = sp < 0 ? t : t.substring(0, sp);
    if (first == openKw) depth++;
    else if (first == closeKw) { depth--; if (depth == 0) return (int)i; }
    else if (depth == 1 && elseIdx && first == "else") *elseIdx = (int)i;
  }
  return -1;
}

static void runLines(std::vector<String> &lines, int start, int end) {
  if (s_scriptDepth >= TERM_MAX_SCRIPT_DEPTH) { termPrint("error: script nesting too deep"); return; }
  s_scriptDepth++;

  int i = start;
  while (i >= 0 && i <= end && i < (int)lines.size()) {
    String raw = lines[i];
    String line = raw; line.trim();
    if (line.length() == 0 || line.startsWith("#")) { i++; continue; }

    int sp = line.indexOf(' ');
    String first = sp < 0 ? line : line.substring(0, sp);
    String rest  = sp < 0 ? ""   : line.substring(sp + 1);

    if (first == "if") {
      int elseIdx = -1;
      int endIdx = findMatchingEnd(lines, i, "if", "endif", &elseIdx);
      if (endIdx < 0 || endIdx > end) { termPrint("if: missing endif"); break; }
      bool cond = evalCondition(expandVars(rest));
      if (cond) runLines(lines, i + 1, (elseIdx >= 0 ? elseIdx : endIdx) - 1);
      else if (elseIdx >= 0) runLines(lines, elseIdx + 1, endIdx - 1);
      i = endIdx + 1; continue;
    }

    if (first == "while") {
      int endIdx = findMatchingEnd(lines, i, "while", "endwhile", nullptr);
      if (endIdx < 0 || endIdx > end) { termPrint("while: missing endwhile"); break; }
      int guard = 0;
      while (evalCondition(expandVars(rest)) && guard++ < TERM_MAX_LOOP_ITERS) {
        runLines(lines, i + 1, endIdx - 1);
      }
      i = endIdx + 1; continue;
    }

    if (first == "for") {
      int endIdx = findMatchingEnd(lines, i, "for", "endfor", nullptr);
      if (endIdx < 0 || endIdx > end) { termPrint("for: missing endfor"); break; }
      std::vector<String> parts;
      splitArgs(expandVars(rest), parts);
      if (parts.size() >= 3 && parts[1] == "in") {
        String var = parts[0];
        for (size_t k = 2; k < parts.size() && k - 2 < TERM_MAX_LOOP_ITERS; k++) {
          varSet(var, parts[k]);
          runLines(lines, i + 1, endIdx - 1);
        }
      } else {
        termPrint("for: usage: for VAR in v1 v2 ...");
      }
      i = endIdx + 1; continue;
    }

    if (first == "function") {
      int endIdx = findMatchingEnd(lines, i, "function", "endfunction", nullptr);
      if (endIdx < 0 || endIdx > end) { termPrint("function: missing endfunction"); break; }
      ShellFunction f; f.name = rest; f.name.trim();
      for (int k = i + 1; k < endIdx; k++) f.body.push_back(lines[k]);
      funcDefine(f);
      i = endIdx + 1; continue;
    }

    // присвоение переменной?
    String vname, vrhs;
    if (isAssignment(line, vname, vrhs)) {
      varSet(vname, evalRhs(vrhs));
      i++; continue;
    }

    // вызов пользовательской функции?
    int fi = funcFindIndex(first);
    if (fi >= 0) {
      runLines(s_functions[fi].body, 0, (int)s_functions[fi].body.size() - 1);
      i++; continue;
    }

    // обычная команда
    runCommand(line);
    i++;
  }

  s_scriptDepth--;
}

static void runCommand(const String &lineIn) {
  String line = lineIn;
  line.trim();
  if (line.length() == 0) return;

  // Разделяем команды по точке с запятой
  // Но учитываем, что ; может быть в кавычках
  std::vector<String> commands;
  String currentCmd = "";
  bool inQuotes = false;

  for (size_t i = 0; i < line.length(); i++) {
    char c = line[i];

    if (c == '"') {
      inQuotes = !inQuotes;
      currentCmd += c;
    } else if (c == ';' && !inQuotes) {
      // Нашли разделитель команд
      if (currentCmd.length() > 0) {
        currentCmd.trim();
        commands.push_back(currentCmd);
        currentCmd = "";
      }
    } else {
      currentCmd += c;
    }
  }

  // Добавляем последнюю команду
  if (currentCmd.length() > 0) {
    currentCmd.trim();
    commands.push_back(currentCmd);
  }

  // Если команд нет - выходим
  if (commands.empty()) return;

  // Выполняем каждую команду
  for (size_t cmdIdx = 0; cmdIdx < commands.size(); cmdIdx++) {
    String cmdLine = commands[cmdIdx];
    cmdLine.trim();
    if (cmdLine.length() == 0) continue;

    // Показываем команду
    if (cmdIdx == 0) {
      termPrint("$ " + lineIn);  // Показываем всю строку один раз
    }

    // Добавляем команду в историю (только первую, чтобы не дублировать)
    if (cmdIdx == 0) {
      s_history.push_back(lineIn);
      while (s_history.size() > TERM_HISTORY_MAX) s_history.erase(s_history.begin());
      s_historyPos = -1;
      appendHistoryToDisk(lineIn);
    }

    // присвоение переменной прямо в потоке команд (a=1; b=2)
    String vname, vrhs;
    if (isAssignment(cmdLine, vname, vrhs)) {
      varSet(vname, evalRhs(vrhs));
      continue;
    }

    // подстановка $VAR/${VAR} для остальных команд
    cmdLine = expandVars(cmdLine);

    // Разбираем аргументы
    std::vector<String> args;
    splitArgs(cmdLine, args);
    String cmd = args.empty() ? "" : args[0];
    String rest = cmdLine.length() > cmd.length() ? cmdLine.substring(cmd.length() + 1) : "";
    rest.trim();

    // вызов пользовательской функции
    int fi = funcFindIndex(cmd);
    if (fi >= 0) {
      runLines(s_functions[fi].body, 0, (int)s_functions[fi].body.size() - 1);
      continue;
    }

    // Выполняем команду
    if (cmd == "ls") cmdLs(rest);
    else if (cmd == "cd") cmdCd(rest);
    else if (cmd == "pwd") termPrint(s_cwd);
    else if (cmd == "mkdir") cmdMkdir(rest);
    else if (cmd == "rmdir") cmdRmdir(rest);
    else if (cmd == "rm") cmdRm(rest);
    else if (cmd == "cat") cmdCat(rest);
    else if (cmd == "echo") cmdEcho(rest);
    else if (cmd == "mv") {
      std::vector<String> mvArgs; splitArgs(rest, mvArgs);
      cmdMv(mvArgs.size() > 0 ? mvArgs[0] : "", mvArgs.size() > 1 ? mvArgs[1] : "");
    }
    else if (cmd == "set") {
      std::vector<String> setArgs; splitArgs(rest, setArgs);
      if (setArgs.size() >= 2) {
        String val = rest.substring(setArgs[0].length());
        val.trim();
        varSet(setArgs[0], evalRhs(val));
      } else termPrint("set: usage: set NAME value");
    }
    else if (cmd == "unset") {
      if (rest.length() == 0) termPrint("unset: usage: unset NAME");
      else termPrint(varUnset(rest) ? ("unset " + rest) : ("unset: no such variable: " + rest));
    }
    else if (cmd == "vars") cmdVars();
    else if (cmd == "funcs") cmdFuncs();
    else if (cmd == "funcload") {
      std::vector<String> flArgs; splitArgs(rest, flArgs);
      cmdFuncLoad(flArgs.size() > 0 ? flArgs[0] : "", flArgs.size() > 1 ? flArgs[1] : "");
    }
    else if (cmd == "bash") cmdBashFile(rest);
    else if (cmd == "tu") cmdTu(rest);
    else if (cmd == "wifi") cmdWifi(rest);
    else if (cmd == "time") cmdTime(rest);
    else if (cmd == "curl") cmdCurl(rest);
    else if (cmd == "ping") cmdPing(rest);
    else if (cmd == "settings") cmdSettings(rest);
    else if (cmd == "mount") cmdMount(rest);
    else if (cmd == "umount") cmdUmount(rest);
    else if (cmd == "play") cmdPlay(rest);
    else if (cmd == "stop") { stopMusic(); termPrint("stop: ok"); }
    else if (cmd == "pause") { pauseMusic(); termPrint("pause: ok"); }
    else if (cmd == "resume") { resumeMusic(); termPrint("resume: ok"); }
    else if (cmd == "volume") cmdVolume(rest);
    else if (cmd == "speed") cmdSpeedCmd(rest);
    else if (cmd == "audiostatus") cmdAudioStatus();
    else if (cmd == "run") cmdRun(rest);
    else if (cmd == "ps") cmdPs(rest);
    else if (cmd.startsWith("/bin/")) {
      // Как в реальном bash - указание полного пути запускает
      // программу напрямую, без "run".
      if (!binVfsRun(cmd)) termPrint(cmd + ": no such program (see: ls /bin)");
    }
    else if (cmd == "clear") s_scrollback.clear();
    else if (cmd == "nano" || cmd == "edit") {
      if (rest.length() == 0) termPrint("usage: nano <file>");
      else { s_pendingEditorPath = resolvePath(rest); s_wantEditor = true; break; }
    }
    else if (cmd == "exit" || cmd == "quit") { s_wantExit = true; break; }
    else if (cmd == "help") {
      termPrint("ls cd pwd mkdir rmdir rm cat mv");
      termPrint("echo [>|>> file] nano/edit <f>");
      termPrint("set/unset/vars  $VAR  $(cat f)");
      termPrint("if/else/endif  while/endwhile");
      termPrint("for V in a b c/endfor");
      termPrint("function NAME/endfunction  funcload N f");
      termPrint("bash <file>  tu <file.tu>  clear help exit");
      termPrint("wifi connect/status/disconnect  time [sync]  curl <url>");
      termPrint("ping <host>  settings show/samplerate/rotation/brightness");
      termPrint("mount  umount <mp>          - see also /proc/mounts");
      termPrint("play <f> stop pause resume  - see also /proc/audio");
      termPrint("volume [0-100]  speed [x]  audiostatus");
      termPrint("run <prog>  /bin/<prog>     - see also /bin, ls /lib");
      termPrint("ps");
    }
    else if (cmd.length() > 0) {
      termPrint(cmd + ": command not found");
    }
  }
}

// Точка входа для одной введённой строки: ловит многострочный ввод
// блочных конструкций (if/while/for/function), набираемых построчно
// прямо в консоли.
static bool isOpenKw(const String &k)  { return k == "if" || k == "while" || k == "for" || k == "function"; }
static bool isCloseKw(const String &k) { return k == "endif" || k == "endwhile" || k == "endfor" || k == "endfunction"; }

static void handleLine(const String &lineIn) {
  String line = lineIn; line.trim();
  if (line.length() == 0 && !s_capturing) return;

  int sp = line.indexOf(' ');
  String first = sp < 0 ? line : line.substring(0, sp);

  if (s_capturing) {
    s_captureLines.push_back(lineIn);
    termPrint("> " + lineIn);
    if (isOpenKw(first)) s_captureDepth++;
    else if (isCloseKw(first)) {
      s_captureDepth--;
      if (s_captureDepth <= 0) {
        s_capturing = false;
        std::vector<String> script = s_captureLines;
        s_captureLines.clear();
        s_history.push_back(script.empty() ? "" : script[0]);
        while (s_history.size() > TERM_HISTORY_MAX) s_history.erase(s_history.begin());
        s_historyPos = -1;
        if (!script.empty()) {
          appendHistoryToDisk(script[0]);
          runLines(script, 0, (int)script.size() - 1);
        }
      }
    }
    return;
  }

  if (isOpenKw(first)) {
    s_capturing = true;
    s_captureDepth = 1;
    s_captureLines.clear();
    s_captureLines.push_back(lineIn);
    termPrint("$ " + lineIn);
    return;
  }

  runCommand(lineIn);
}

// ----------------------------------------------------------------
//  public API
// ----------------------------------------------------------------
void terminalInit() {
  s_cwd = "/";
  s_scrollback.clear();
  s_history.clear();
  loadHistoryFromDisk();
}

void terminalOnEnter() {
  s_input = "";
  s_cursor = 0;
  s_wantEditor = false;
  s_wantExit = false;
  if (s_scrollback.empty()) {
    termPrint("Text Reader v6 shell");
    termPrint("type 'help' for commands");
  }
}

bool terminalFeedChar(char c) {
  if (c == '\n' || c == '\r') {
    String line = s_input;
    s_input = "";
    s_cursor = 0;
    handleLine(line);
    return true;
  }
  if (c == 0x08 || c == 0x7F) { // backspace/delete
    if (s_cursor > 0) { s_input.remove(s_cursor - 1, 1); s_cursor--; return true; }
    return false;
  }
  if ((uint8_t)c < 0x20) return false; // ignore other control chars
  if ((int)s_input.length() >= TERM_LINE_MAX) return false;
  s_input = s_input.substring(0, s_cursor) + String(c) + s_input.substring(s_cursor);
  s_cursor++;
  return true;
}

bool terminalMoveCursor(int delta) {
  int nc = constrain(s_cursor + delta, 0, (int)s_input.length());
  if (nc == s_cursor) return false;
  s_cursor = nc;
  return true;
}

void terminalHistoryUp() {
  if (s_history.empty()) return;
  if (s_historyPos < 0) s_historyPos = (int)s_history.size() - 1;
  else if (s_historyPos > 0) s_historyPos--;
  s_input = s_history[s_historyPos];
  s_cursor = s_input.length();
}

void terminalHistoryDown() {
  if (s_historyPos < 0) return;
  s_historyPos++;
  if (s_historyPos >= (int)s_history.size()) { s_historyPos = -1; s_input = ""; }
  else s_input = s_history[s_historyPos];
  s_cursor = s_input.length();
}

bool terminalWantsEditor(String &pathOut) {
  if (!s_wantEditor) return false;
  pathOut = s_pendingEditorPath;
  s_wantEditor = false;
  return true;
}

bool terminalWantsExit() {
  if (!s_wantExit) return false;
  s_wantExit = false;
  return true;
}

void terminalDraw(int height) {
  int yTop = UI_LINE_H; // header line drawn by caller above us
  sendFillRect(0, yTop, UI_DISPLAY_WIDTH, height - yTop, 0, 0, 0);

  int visible = (height - UI_LINE_H) / UI_LINE_H - 1;
  if (visible < 1) visible = 1;
  int start = (int)s_scrollback.size() - visible;
  if (start < 0) start = 0;
  sendSetTextColor(150, 220, 150);
  for (int i = 0; i < visible && (start + i) < (int)s_scrollback.size(); i++) {
    String line = s_scrollback[start + i];
    int maxCh = UI_DISPLAY_WIDTH / UI_CHAR_W;
    if ((int)line.length() > maxCh) line = line.substring(0, maxCh);
    sendSetCursor(2, yTop + i * UI_LINE_H);
    sendPrintStr(line);
  }

  // input line, last row of this area
  int inY = yTop + visible * UI_LINE_H;
  sendFillRect(0, inY, UI_DISPLAY_WIDTH, UI_LINE_H, 10, 30, 10);
  sendSetTextColor(255, 255, 150);
  sendSetCursor(2, inY);
  String prompt = s_capturing ? "> " : (s_cwd + "$ ");
  String shown = prompt + s_input;
  int maxCh = UI_DISPLAY_WIDTH / UI_CHAR_W;
  int cursorScreenPos = prompt.length() + s_cursor;
  if ((int)shown.length() > maxCh) {
    int hideFromFront = shown.length() - maxCh;
    shown = shown.substring(hideFromFront);
    cursorScreenPos -= hideFromFront;
  }
  sendPrintStr(shown);
  if (cursorScreenPos >= 0 && cursorScreenPos < maxCh) {
    sendSetCursor(2 + cursorScreenPos * UI_CHAR_W, inY);
    sendSetTextColor(0, 255, 0);
    sendPrintText("_");
  }
}


void terminalToggleOsk() {
  if (s_oskActive) {
    oskTerminalHide();
    s_oskActive = false;
  } else {
    oskTerminalShow();
    s_oskActive = true;
  }
}
void terminalClear() {
  s_scrollback.clear();
  termPrint("Terminal cleared");
}

// ================================================================
//  Самопроверка / системная интроспекция
// ================================================================
void terminalListVars(std::vector<String> &namesOut, std::vector<String> &valuesOut) {
  namesOut = s_varNames;
  valuesOut = s_varValues;
}

void terminalRunSystemCommand(const String &cmdLine) {
  // runCommand() уже умеет всё (присвоения, $VAR, перенаправления и т.д.) -
  // self-test просто прогоняет через тот же путь, что и обычный ввод.
  runCommand(cmdLine);
}

void terminalGetLastLines(int n, std::vector<String> &outLines) {
  outLines.clear();
  int start = (int)s_scrollback.size() - n;
  if (start < 0) start = 0;
  for (int i = start; i < (int)s_scrollback.size(); i++) outLines.push_back(s_scrollback[i]);
}
