// ============================================================
//  Text Reader v6 — 160x128 ST7735 + RP2040
//  + BMP / PNG Image Viewer
//  + Rotary Encoder (GPIO28=A, GPIO27=B, GPIO22=BTN)
//  + FreeRTOS: audio decode runs as a task (core1-pinned), sample
//    output runs from a hardware timer ISR — glitch-free playback
//    even while reading/decoding from a slow USB flash drive.
//  + Dual storage VFS: /sda (LittleFS) + /sdb1.. (USB flash drive partitions)
//  + Generic file explorer (browse, open txt/md, view info, navigate folders)
//  + Folder-based music player (you pick the folder, no auto-scan)
//  + Calculator / Plotter / Settings kept as in v5 - untouched logic
//
//  This is a merge of your "Text Reader v5" sketch with the dual-storage
//  VFS + USB-host + PC-upload-protocol ideas from PicoFileHub, now ported
//  to FreeRTOS with a producer/consumer audio engine (see audio.h).
//  Calculator, Plotter and Settings are still your original, hand-rolled
//  implementations, untouched.
// ============================================================
#define __FREERTOS 1
#define POWER_PIN 29
#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>
#include <Arduino.h>
#include <LittleFS.h>
#include <math.h>
#include <PNGdec.h>
#include <vector>
#include "src/ui/osk_terminal.h"
// ---- USB host (external USB flash drive) ----
#include "pio_usb.h"
#include "hardware/clocks.h"
#include "hardware/watchdog.h"  // для перезагрузки из меню питания (watchdog_reboot)
#include "Adafruit_TinyUSB.h"

// ---- unified internal+external virtual filesystem ----
#include "src/vfs/vfs.h"
#include "src/core/config.h"
#include "src/vfs/gpio_vfs.h"
#include "src/vfs/devices_vfs.h"
#include "src/vfs/mount.h"          // mount table (/proc/mounts, bash mount/umount)
#include "src/vfs/input_vfs.h"      // /dev/input/buttons, /dev/input/keyboard
#include "src/vfs/proc_vfs.h"       // /proc (mounts, uptime, version, audio "process")
#include "src/vfs/lib_vfs.h"        // /lib - manifest of linked libraries
#include "src/vfs/bin_vfs.h"        // /bin - registry of runnable apps
// ---- FreeRTOS-based audio engine (producer/consumer ring buffer) ----
// WavInfo and the music transport API (startMusic/stopMusic/...) all
// come from here now - see audio.h for the architecture writeup.
#include "src/audio/audio.h"

// ---- shared button/display glue + new features ----
#include "src/core/ui_common.h"      // also brings in buttons.h (Btn/EncBtn types)
#include "src/input/keyboard_hid.h"   // optional USB keyboard, instead of a flash drive
#include "src/ui/osk.h"            // button-driven on-screen keyboard
#include "src/terminal/terminal.h"       // bash-like shell over the VFS
#include "src/ui/editor.h"         // minimal nano-like text editor
#include "src/net/net.h"            // WiFi / HTTP / NTP через ESP32-мост
#include "src/ui/clock.h"          // экран часов, таймер, будильник

// #include "doom_parus.h"



Adafruit_USBH_Host USBHost;

// ================================================================
//  DISPLAY & UART
// ================================================================
uint32_t audioSampleRate = 8000;   // частота дискретизации аудио (Гц)
#define UART_TX_PIN 0
#define UART_RX_PIN 1
#define UART_BAUD   2000000
#define SerialESP   Serial1
#define SerialPC    Serial

#define DISPLAY_WIDTH   160
#define DISPLAY_HEIGHT  128
#define CHAR_W          6
#define CHAR_H_PX       8
#define LINE_H          10

#define HDR_H           12
#define FTR_H           11
#define VIEW_Y0         (HDR_H + 1)
#define VIEW_Y1         (DISPLAY_HEIGHT - FTR_H - 1)
#define MAX_VIEW_LINES  ((VIEW_Y1 - VIEW_Y0) / LINE_H)
#define CHARS_PER_LINE  (DISPLAY_WIDTH / CHAR_W)

// ================================================================
//  BUTTONS & ENCODER
// ================================================================
#define BTN_UP      17
#define BTN_DOWN    18
#define BTN_LEFT    14
#define BTN_RIGHT   19
#define BTN_OK      20
#define BTN_HOME    15
#define BTN_CANCEL  16

#define DEBOUNCE_MS     50
#define REPEAT_DELAY    350
#define REPEAT_INTERVAL 100
#define LONG_PRESS_MS   600

#define ENC_A   28
#define ENC_B   27
#define ENC_BTN 22

volatile long encoderPos = 0;
volatile long encoderDelta = 0;
volatile int  encLastState = 0;

void onEncoderChange() {
  int a = digitalRead(ENC_A);
  int b = digitalRead(ENC_B);
  int curr = (a << 1) | b;
  int trans = (encLastState << 2) | curr;
  if (trans == 0b0100 || trans == 0b0010 ||
      trans == 0b1011 || trans == 0b1101) {
    encoderPos++; encoderDelta++;
  } else if (trans == 0b1000 || trans == 0b0001 ||
             trans == 0b0111 || trans == 0b1110) {
    encoderPos--; encoderDelta--;
  }
  encLastState = curr;
}

int readEncoderDelta() {
  noInterrupts();
  int d = encoderDelta;
  encoderDelta = 0;
  interrupts();
  return d;
}

void initEncoder() {
  pinMode(ENC_A, INPUT_PULLUP);
  pinMode(ENC_B, INPUT_PULLUP);
  encLastState = (digitalRead(ENC_A) << 1) | digitalRead(ENC_B);
  attachInterrupt(digitalPinToInterrupt(ENC_A), onEncoderChange, CHANGE);
  attachInterrupt(digitalPinToInterrupt(ENC_B), onEncoderChange, CHANGE);
  if (ENC_BTN >= 0) pinMode(ENC_BTN, INPUT_PULLUP);
}

// ================================================================
//  FILES & LINES
// ================================================================
#define MAX_LINES   600
#define MAX_HEADINGS 40

// AUDIO_PIN now lives in config.h (pulled in via audio.h)
#define MAX_FILENAME_LEN 64

// ================================================================
//  App States
// ================================================================
enum AppState {
  STATE_MENU,
  STATE_FILE_BROWSER,
  STATE_FILE_VIEWER,
  STATE_FILE_BROWSER_MENU,
  STATE_FILE_INFO,
  STATE_HEADING_MENU,
  STATE_SETTINGS,
  STATE_SETTINGS_SAMPLERATE,
  STATE_CALCULATOR,
  STATE_PLOTTER,
  STATE_MUSIC_PLAYER,
  STATE_IMAGE_VIEWER,
  STATE_STATUS_OVERLAY,
  STATE_TERMINAL,
  STATE_EDITOR,
  STATE_TU_RUNNER,
  STATE_CLOCK,
  STATE_SETTINGS_WIFI,
  STATE_POWER_MENU,
  STATE_DOOM,
  STATE_JAVA_MENU,      // список установленных JavaME-приложений
  STATE_JAVA_INSTALL,   // экран установки выбранного .jar/.jad
  STATE_JAVA_RUNNER     // работающий MIDlet (jvmTick)
};

uint32_t newSampleRate = 8000;
int sampleRateEditPos = 0;
char sampleRateStr[8] = "8000";

String infoFilePath = "";
uint32_t infoFileSize = 0;
String infoType = "";
String infoDetails = "";
int fbMenuSelected = 0;
AppState currentState = STATE_MENU;
AppState previousState = STATE_MENU;

// ================================================================
//  DISPLAY PRIMITIVES (UART to ESP32-C3)
// ================================================================
void sendReset() { uint8_t c[]={0xAA,0x0D,0x00,0x55}; SerialESP.write(c,4); delay(60); }
void sendSetRotation(uint8_t r) { uint8_t c[]={0xAA,0x0B,0x01,r,0x55}; SerialESP.write(c,5); delay(30); }
void sendFillScreen(uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x02,0x03,r,g,b,0x55}; SerialESP.write(c,7);   delay(2);}
void sendSetCursor(uint16_t x,uint16_t y) { uint8_t c[]={0xAA,0x08,0x04,(uint8_t)(x>>8),(uint8_t)x,(uint8_t)(y>>8),(uint8_t)y,0x55}; SerialESP.write(c,8);  delay(2); }
void sendSetTextColor(uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x09,0x03,r,g,b,0x55}; SerialESP.write(c,7);  delay(2); }
void sendPrintText(const char* t) { int n=strlen(t); if(n==0)return; if(n>255)n=255; SerialESP.write(0xAA); SerialESP.write(0x0A); SerialESP.write((uint8_t)n); SerialESP.write((const uint8_t*)t,n); SerialESP.write(0x55);  delay(2); }
void sendPrintStr(const String& s) { sendPrintText(s.c_str());   delay(2);}
void sendFillRect(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x05,0x0B,(uint8_t)(x>>8),(uint8_t)x,(uint8_t)(y>>8),(uint8_t)y,(uint8_t)(w>>8),(uint8_t)w,(uint8_t)(h>>8),(uint8_t)h,r,g,b,0x55}; SerialESP.write(c,15);  delay(2); }
void sendDrawRect(uint16_t x,uint16_t y,uint16_t w,uint16_t h,uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x06,0x0B,(uint8_t)(x>>8),(uint8_t)x,(uint8_t)(y>>8),(uint8_t)y,(uint8_t)(w>>8),(uint8_t)w,(uint8_t)(h>>8),(uint8_t)h,r,g,b,0x55}; SerialESP.write(c,15);  delay(2); }
void sendDrawPixel(uint16_t x,uint16_t y,uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x03,0x07,(uint8_t)(x>>8),(uint8_t)x,(uint8_t)(y>>8),(uint8_t)y,r,g,b,0x55}; SerialESP.write(c,11);  delay(2); }
void sendDrawLine(uint16_t x0,uint16_t y0,uint16_t x1,uint16_t y1,uint8_t r,uint8_t g,uint8_t b) { uint8_t c[]={0xAA,0x04,0x0B,(uint8_t)(x0>>8),(uint8_t)x0,(uint8_t)(y0>>8),(uint8_t)y0,(uint8_t)(x1>>8),(uint8_t)x1,(uint8_t)(y1>>8),(uint8_t)y1,r,g,b,0x55}; SerialESP.write(c,15);  delay(2); }

// ================================================================
//  UTF-8 HELPERS
// ================================================================
int utf8CharLen(uint8_t c){if(c<0x80)return 1;if((c&0xE0)==0xC0)return 2;if((c&0xF0)==0xE0)return 3;if((c&0xF8)==0xF0)return 4;return 1;}
int utf8Len(const String& s){int n=0,i=0;while(i<(int)s.length()){i+=utf8CharLen(s[i]);n++;}return n;}
String utf8Substr(const String& s,int from,int to){int bs=-1,be=(int)s.length(),ci=0,i=0;while(i<(int)s.length()){if(ci==from)bs=i;if(ci==to){be=i;break;}i+=utf8CharLen(s[i]);ci++;}if(bs<0)return "";return s.substring(bs,be);}

// ================================================================
//  BUTTON SYSTEM
// ================================================================
// Btn / EncBtn struct types now live in buttons.h (shared with
// terminal.cpp / editor.cpp / osk.cpp). Only the global instances are
// defined here, same as before.
Btn bUp,bDown,bLeft,bRight,bOk,bHome,bCancel;
EncBtn bEncBtn;

void initButtons(){bUp.pin=BTN_UP;bDown.pin=BTN_DOWN;bLeft.pin=BTN_LEFT;bRight.pin=BTN_RIGHT;bOk.pin=BTN_OK;bHome.pin=BTN_HOME;bCancel.pin=BTN_CANCEL;uint8_t pins[]={BTN_UP,BTN_DOWN,BTN_LEFT,BTN_RIGHT,BTN_OK,BTN_HOME,BTN_CANCEL};for(auto p:pins)pinMode(p,INPUT_PULLUP);}
void updateButtons(){bUp.update();bDown.update();bLeft.update();bRight.update();bOk.update();bHome.update();bCancel.update();if(ENC_BTN>=0)bEncBtn.update(ENC_BTN);}

// ---- Turbine .tu script engine (после Btn/SerialPC/DISPLAY_* выше) ----
#include "src/scripting/turbine_integration.h"
// ---- JavaME (.jar/.jad) runner + установка (после send*/b*/currentState) ----
#include "src/javame/java_ui.h"

// ================================================================
//  SELF-TEST (зажми HOME при старте) - выбор Bash / Turbine
//  bootLog()/bootStep()/bootWarn() определены ниже (перед setup()),
//  но в .ino это не проблема - Arduino авто-генерирует прототипы для
//  всех функций в файле, так что порядок текстового определения не важен.
// ================================================================
int selfTestMenuSel = 0;

void drawSelfTestChooser() {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 0, 60, 40);
  sendSetCursor(6, 2); sendSetTextColor(255, 220, 150); sendPrintText("SELF-TEST (HOME held)");
  const char* items[] = {"Bash self-test", "Turbine self-test", "Skip (continue boot)"};
  for (int i = 0; i < 3; i++) {
    int y = 26 + i * 16;
    if (selfTestMenuSel == i) { sendFillRect(4, y - 2, DISPLAY_WIDTH - 8, 14, 0, 70, 30); sendSetTextColor(0, 255, 160); }
    else sendSetTextColor(200, 200, 200);
    sendSetCursor(8, y); sendPrintText(items[i]);
  }
  sendSetCursor(4, DISPLAY_HEIGHT - 10); sendSetTextColor(120, 120, 120);
  sendPrintText("UD=sel  OK=run  CANCEL=skip");
}
std::vector<String>  bootLines;
std::vector<uint8_t> bootColors; // 0=инфо(белый) 1=ok(зелёный) 2=warn(жёлтый) 3=fail(красный)

// небольшая задержка после каждой строки - даёт эффект "печатающегося" лога
void bootLog(const String &msg, uint8_t color = 0, int delayMs = 120) {
  bootLines.push_back(msg);
  bootColors.push_back(color);
  bootRedraw();
  delay(delayMs);
}

void bootStep(const String &label, bool ok, int delayMs = 120) {
  bootLog((ok ? "[ OK ] " : "[FAIL] ") + label, ok ? 1 : 3, delayMs);
}

void bootWarn(const String &label, int delayMs = 150) {
  bootLog("[WARN] " + label, 2, delayMs);
}

void runBashSelfTestSequence() {
  sendFillScreen(0, 0, 0);
  bootLog("=== Bash self-test ===", 0);

  terminalInit();
  terminalOnEnter();
  bootStep("Init bash engine", true);

  std::vector<String> lines;
  int passed = 0, total = 0;
  
  auto runTest = [&](const String& name, const String& cmd, const String& expected) {
    total++;
    terminalRunSystemCommand(cmd);
    terminalGetLastLines(1, lines);
    bool ok = !lines.empty() && lines[0].indexOf(expected) >= 0;
    bootStep(name, ok);
    if (ok) passed++;
    return ok;
  };
  
  auto runTestFile = [&](const String& name, const String& cmd, const String& path, const String& expected) {
    total++;
    terminalRunSystemCommand(cmd);
    bool exists = vfsExists(path);
    bool ok = false;
    if (exists) {
      VfsFile f;
      if (f.openRead(path)) {
        String content = "";
        uint8_t b;
        while (f.read(&b, 1) == 1) content += (char)b;
        f.close();
        ok = content.indexOf(expected) >= 0;
      }
    }
    bootStep(name, ok);
    if (ok) passed++;
    return ok;
  };

  // 1. Basic output
  runTest("echo output", "echo Hello Parus", "Hello Parus");

  // 2. Variable creation
  terminalRunSystemCommand("x=42");
  terminalRunSystemCommand("echo $x");
  terminalGetLastLines(1, lines);
  bool varOk = !lines.empty() && lines[0] == "42";
  bootStep("Variable creation (x=42)", varOk);
  if (varOk) passed++;
  total++;

  // 3. Variable usage
  terminalRunSystemCommand("y=$x");
  terminalRunSystemCommand("echo $y");
  terminalGetLastLines(1, lines);
  bool varUseOk = !lines.empty() && lines[0] == "42";
  bootStep("Variable usage (y=$x)", varUseOk);
  if (varUseOk) passed++;
  total++;

  // 4. String concatenation with variables
  terminalRunSystemCommand("str=\"Hello\"");
  terminalRunSystemCommand("str=$str\" World\"");
  terminalRunSystemCommand("echo $str");
  terminalGetLastLines(1, lines);
  bool strConcatOk = !lines.empty() && lines[0].indexOf("Hello World") >= 0;
  bootStep("String concatenation", strConcatOk);
  if (strConcatOk) passed++;
  total++;

  // 5. Arithmetic
  terminalRunSystemCommand("a=10");
  terminalRunSystemCommand("b=20");
  terminalRunSystemCommand("c=$a+$b");
  terminalRunSystemCommand("echo $c");
  terminalGetLastLines(1, lines);
  bool arithOk = !lines.empty() && lines[0] == "30";
  bootStep("Arithmetic (a+b)", arithOk);
  if (arithOk) passed++;
  total++;

  // 6. Command substitution $(cat file)
  terminalRunSystemCommand("echo test_data > /sda/.selftest_tmp.txt");
  terminalRunSystemCommand("data=$(cat /sda/.selftest_tmp.txt)");
  terminalRunSystemCommand("echo $data");
  terminalGetLastLines(1, lines);
  bool cmdSubstOk = !lines.empty() && lines[0].indexOf("test_data") >= 0;
  bootStep("Command substitution $(cat)", cmdSubstOk);
  if (cmdSubstOk) passed++;
  total++;

  // 7. File operations: mkdir
  terminalRunSystemCommand("mkdir /sda/.selftest");
  bool mkdirOk = vfsExists("/sda/.selftest") && vfsIsDir("/sda/.selftest");
  bootStep("mkdir directory", mkdirOk);
  if (mkdirOk) passed++;
  total++;

  // 8. File write: echo > file
  terminalRunSystemCommand("echo selftest_ok > /sda/.selftest/t.txt");
  bool fileWriteOk = vfsExists("/sda/.selftest/t.txt");
  bootStep("echo > file write", fileWriteOk);
  if (fileWriteOk) passed++;
  total++;

  // 9. File read (independent VFS check)
  String content = "";
  if (fileWriteOk) {
    VfsFile f;
    if (f.openRead("/sda/.selftest/t.txt")) {
      uint8_t b;
      while (f.read(&b, 1) == 1) content += (char)b;
      f.close();
    }
  }
  bool fileReadOk = content.indexOf("selftest_ok") >= 0;
  bootStep("File read (VFS check)", fileReadOk);
  if (fileReadOk) passed++;
  total++;

  // 10. File append: echo >> file
  terminalRunSystemCommand("echo line2 >> /sda/.selftest/t.txt");
  String content2 = "";
  if (vfsExists("/sda/.selftest/t.txt")) {
    VfsFile f;
    if (f.openRead("/sda/.selftest/t.txt")) {
      uint8_t b;
      while (f.read(&b, 1) == 1) content2 += (char)b;
      f.close();
    }
  }
  bool appendOk = content2.indexOf("line2") >= 0 && content2.indexOf("selftest_ok") >= 0;
  bootStep("File append (echo >>)", appendOk);
  if (appendOk) passed++;
  total++;

  // 11. File delete: rm
  terminalRunSystemCommand("rm /sda/.selftest/t.txt");
  bool rmOk = !vfsExists("/sda/.selftest/t.txt");
  bootStep("rm file delete", rmOk);
  if (rmOk) passed++;
  total++;

  // 12. Directory delete: rmdir
  terminalRunSystemCommand("rmdir /sda/.selftest");
  bool rmdirOk = !vfsExists("/sda/.selftest");
  bootStep("rmdir directory", rmdirOk);
  if (rmdirOk) passed++;
  total++;

  // 13. Variable listing: vars command
  terminalRunSystemCommand("vars");
  terminalGetLastLines(5, lines);
  bool varsCmdOk = false;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("x=42") >= 0 && lines[i].indexOf("y=42") >= 0) {
      varsCmdOk = true;
      break;
    }
  }
  bootStep("vars command output", varsCmdOk);
  if (varsCmdOk) passed++;
  total++;

  // 14. Variable introspection (terminalListVars API)
  std::vector<String> names, vals;
  terminalListVars(names, vals);
  bool varsListOk = false;
  for (size_t i = 0; i < names.size(); i++) {
    if (names[i] == "x" || names[i] == "y") varsListOk = true;
  }
  bootStep("Variable introspection (terminalListVars)", varsListOk);
  if (varsListOk) passed++;
  total++;

  // 15. Working directory: pwd
  terminalRunSystemCommand("pwd");
  terminalGetLastLines(1, lines);
  bool pwdOk = !lines.empty() && (lines[0] == "/" || lines[0].indexOf("/") >= 0);
  bootStep("pwd command", pwdOk);
  if (pwdOk) passed++;
  total++;

  // 16. cd to /sda
  terminalRunSystemCommand("cd /sda");
  terminalRunSystemCommand("pwd");
  terminalGetLastLines(1, lines);
  bool cdOk = !lines.empty() && lines[0] == "/sda";
  bootStep("cd /sda", cdOk);
  if (cdOk) passed++;
  total++;

  // 17. cd back to root
  terminalRunSystemCommand("cd /");
  terminalRunSystemCommand("pwd");
  terminalGetLastLines(1, lines);
  bool cdRootOk = !lines.empty() && lines[0] == "/";
  bootStep("cd /", cdRootOk);
  if (cdRootOk) passed++;
  total++;

  // 18. ls command (basic)
  terminalRunSystemCommand("ls");
  terminalGetLastLines(3, lines);
  bool lsOk = false;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("sda") >= 0) { lsOk = true; break; }
  }
  bootStep("ls command", lsOk);
  if (lsOk) passed++;
  total++;

  // 19. Multi-line if/else
  String ifScript = 
    "if -f /sda/.selftest_nonexistent\n"
    "  echo file exists\n"
    "else\n"
    "  echo file not found\n"
    "endif\n";
  VfsFile f;
  if (f.openWrite("/sda/.selftest_if.tmp", false)) {
    f.write((const uint8_t*)ifScript.c_str(), ifScript.length());
    f.close();
  }
  terminalRunSystemCommand("bash /sda/.selftest_if.tmp");
  terminalGetLastLines(2, lines);
  bool ifOk = false;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("file not found") >= 0) { ifOk = true; break; }
  }
  bootStep("if/else conditional", ifOk);
  if (ifOk) passed++;
  total++;
  terminalRunSystemCommand("rm /sda/.selftest_if.tmp");

  // 20. while loop
  String whileScript = 
    "i=0\n"
    "while $i -lt 3\n"
    "  echo count $i\n"
    "  i=$i+1\n"
    "endwhile\n";
  VfsFile f2;
  if (f2.openWrite("/sda/.selftest_while.tmp", false)) {
    f2.write((const uint8_t*)whileScript.c_str(), whileScript.length());
    f2.close();
  }
  terminalRunSystemCommand("bash /sda/.selftest_while.tmp");
  terminalGetLastLines(4, lines);
  int countMatches = 0;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("count 0") >= 0) countMatches++;
    if (lines[i].indexOf("count 1") >= 0) countMatches++;
    if (lines[i].indexOf("count 2") >= 0) countMatches++;
  }
  bool whileOk = (countMatches == 3);
  bootStep("while loop", whileOk);
  if (whileOk) passed++;
  total++;
  terminalRunSystemCommand("rm /sda/.selftest_while.tmp");

  // 21. for loop
  String forScript = 
    "for fruit in apple banana cherry\n"
    "  echo fruit $fruit\n"
    "endfor\n";
  VfsFile f3;
  if (f3.openWrite("/sda/.selftest_for.tmp", false)) {
    f3.write((const uint8_t*)forScript.c_str(), forScript.length());
    f3.close();
  }
  terminalRunSystemCommand("bash /sda/.selftest_for.tmp");
  terminalGetLastLines(4, lines);
  int fruitMatches = 0;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("fruit apple") >= 0) fruitMatches++;
    if (lines[i].indexOf("fruit banana") >= 0) fruitMatches++;
    if (lines[i].indexOf("fruit cherry") >= 0) fruitMatches++;
  }
  bool forOk = (fruitMatches == 3);
  bootStep("for loop", forOk);
  if (forOk) passed++;
  total++;
  terminalRunSystemCommand("rm /sda/.selftest_for.tmp");

  // 22. User function definition and call
  String funcScript = 
    "function greet\n"
    "  echo Hello from function\n"
    "endfunction\n"
    "greet\n";
  VfsFile f4;
  if (f4.openWrite("/sda/.selftest_func.tmp", false)) {
    f4.write((const uint8_t*)funcScript.c_str(), funcScript.length());
    f4.close();
  }
  terminalRunSystemCommand("bash /sda/.selftest_func.tmp");
  terminalGetLastLines(2, lines);
  bool funcOk = false;
  for (size_t i = 0; i < lines.size(); i++) {
    if (lines[i].indexOf("Hello from function") >= 0) { funcOk = true; break; }
  }
  bootStep("function definition and call", funcOk);
  if (funcOk) passed++;
  total++;
  terminalRunSystemCommand("rm /sda/.selftest_func.tmp");

  // 23. Display drawing test
  sendFillRect(20, DISPLAY_HEIGHT - 20, 40, 10, 0, 160, 255);
  bootLog("[ OK ] Display drawing (sendFillRect)", 1, 500);

  // Summary
  bootLog("Bash self-test: " + String(passed) + "/" + String(total) + " passed", 
          passed == total ? 1 : 3, 300);

  bootLog("Press OK/CANCEL to continue boot", 0, 0);
  while (true) { updateButtons(); if (bOk.pressed() || bCancel.pressed() || bHome.pressed()) break; delay(20); }
}

// ── Turbine self-test: реальный .tu-скрипт, выполняемый через
//    gTurbine.runSource() с временно подменённым cbPrint, чтобы
//    перехватить и проверить его вывод ───────────────────────────────
static String s_ttCapture;
static void ttSelfTestPrintCb(const char* s) { s_ttCapture += s; }

void runTurbineSelfTestSequence() {
  sendFillScreen(0, 0, 0);
  bootLog("=== Turbine self-test ===", 0, 100);

  tuInitCallbacks(); // безопасно звать повторно
  bootStep("Init turbine engine", true);

  void (*savedPrint)(const char*) = gTurbine.cbPrint;
  gTurbine.cbPrint = ttSelfTestPrintCb;

  String src =
    "#main()\n"
    "  print(\"hello from turbine\")\n"
    "  - x int = 5\n"
    "  - y int = 0\n"
    "  y = x + 10\n"
    "  print(\"sum=\", y)\n"
    "  file.write(\"/sda/.tu_selftest.txt\", \"turbine_ok\")\n"
    "  - content string = file.read(\"/sda/.tu_selftest.txt\")\n"
    "  print(\"file content=\", content)\n"
    "  file.delete(\"/sda/.tu_selftest.txt\")\n"
    "  vars()\n";

  s_ttCapture = "";
  bool ok = gTurbine.runSource(src.c_str(), src.length());
  gTurbine.cbPrint = savedPrint;

  bootStep("Run script (lexer+parser+exec)", ok);
  if (!ok) {
    bootWarn(gTurbine.errMsg, 300);
  } else {
    bootStep("Display output (print)", s_ttCapture.indexOf("hello from turbine") >= 0);
    bool sumOk = s_ttCapture.indexOf("sum=15") >= 0 || s_ttCapture.indexOf("sum= 15") >= 0;
    bootStep("Variable creation+usage (y=x+10==15)", sumOk);

    bool fileOk = s_ttCapture.indexOf("turbine_ok") >= 0;
    bootStep("File write/read (file.* builtins)", fileOk);
    bootStep("File cleanup (file.delete)", !vfsExists("/sda/.tu_selftest.txt"));

    bool varsOk = s_ttCapture.indexOf("x=5") >= 0;
    bootStep("Variable introspection (vars() builtin)", varsOk);
  }

  // Работа с дисплеем - реальная отрисовка через cbFillRect движка
  gTurbine.cbFillRect(20, DISPLAY_HEIGHT - 20, 40, 10, 255, 160, 0);
  bootLog("[ OK ] Display drawing (display.fillRect via engine)", 1, 500);

  bootLog("Turbine self-test: " + String(ok ? "ALL OK" : "FAILED"), ok ? 1 : 3, 300);

  bootLog("Press OK/CANCEL to continue boot", 0, 0);
  while (true) { updateButtons(); if (bOk.pressed() || bCancel.pressed() || bHome.pressed()) break; delay(20); }
}

void runSelfTestChooser() {
  selfTestMenuSel = 0;
  drawSelfTestChooser();
  while (true) {
    updateButtons();
    int enc = readEncoderDelta();
    bool changed = false;
    if (bUp.pressed() || bUp.repeat())   { if (selfTestMenuSel > 0) { selfTestMenuSel--; changed = true; } }
    if (bDown.pressed() || bDown.repeat()) { if (selfTestMenuSel < 2) { selfTestMenuSel++; changed = true; } }
    if (enc != 0) { selfTestMenuSel = constrain(selfTestMenuSel + (enc > 0 ? 1 : -1), 0, 2); changed = true; }
    if (changed) drawSelfTestChooser();

    if (bOk.pressed() || bEncBtn.pressed()) {
      if (selfTestMenuSel == 0) runBashSelfTestSequence();
      else if (selfTestMenuSel == 1) runTurbineSelfTestSequence();
      break; // selfTestMenuSel==2 (Skip) тоже просто выходит
    }
    if (bCancel.pressed()) break;
    delay(20);
  }
  sendFillScreen(0, 0, 0);
}

// ================================================================
//  GENERIC FILE EXPLORER STATE (VFS: /sda + /sdb1, /sdb2, ...)
// ================================================================
String browserPath = "/";                 // current directory being shown
std::vector<VfsEntry> browserEntries;      // entries of browserPath
int browserSel = 0, browserScroll = 0;
#define BROWSER_VISIBLE 6

bool isTextFile(const String& name){String n=name;n.toLowerCase();return n.endsWith(".txt")||n.endsWith(".md");}
bool isImageFile(const String& name){String n=name;n.toLowerCase();return n.endsWith(".bmp")||n.endsWith(".png");}
bool isAudioFile(const String& name){String n=name;n.toLowerCase();return n.endsWith(".wav")||n.endsWith(".mp3")||n.endsWith(".pcm")||n.endsWith(".raw");}

String formatSize(uint32_t bytes){
  char buf[24];
  if(bytes<1024) snprintf(buf,sizeof(buf),"%luB",(unsigned long)bytes);
  else if(bytes<1024UL*1024UL) snprintf(buf,sizeof(buf),"%.1fK",bytes/1024.0f);
  else snprintf(buf,sizeof(buf),"%.1fM",bytes/(1024.0f*1024.0f));
  return String(buf);
}

void refreshBrowser(){
  browserEntries.clear();
  vfsListDir(browserPath, browserEntries);
  if(browserSel>=(int)browserEntries.size()) browserSel=max(0,(int)browserEntries.size()-1);
  browserScroll=0;
}

void browserGoUp(){
  if(browserPath=="/") return;
  int slash=browserPath.lastIndexOf('/');
  browserPath = (slash<=0) ? "/" : browserPath.substring(0,slash);
  browserSel=0;
  refreshBrowser();
}

void browserEnter(const String& dirName){
  browserPath = (browserPath=="/") ? ("/"+dirName) : vfsJoin(browserPath,dirName);
  browserSel=0;
  refreshBrowser();
}

// ================================================================
//  MENU STATE
// ================================================================
#define MENU_ITEMS_COUNT 7
#define MENU_VISIBLE     5

int selectedMenu=0;
int menuScrollOffset=0;

const char* MENU_LABELS[MENU_ITEMS_COUNT] = {
  "  Files",
  "  Music",
  "  Calculator",
  "  Plotter",
  "  Settings",
  "  Terminal",
  "  Java"
};

int settingsChoice=0,displayRotation=3;
bool needReboot=false;



// ================================================================
//  MUSIC PLAYLIST (built from ONE folder you navigate to - not a global scan)
// ================================================================
String musicDirPath = "";              // the folder the current playlist came from
std::vector<String> musicPlaylist;     // filenames (not full paths) in musicDirPath
int selectedMusic=0, musicScrollOffset=0;

void buildPlaylistFromDir(const String& dirPath){
  musicDirPath = dirPath;
  musicPlaylist.clear();
  std::vector<VfsEntry> entries;
  vfsListDir(dirPath, entries);
  for(auto &e : entries) if(!e.isDir && isAudioFile(e.name)) musicPlaylist.push_back(e.name);
  // simple alphabetical sort
  for(size_t i=0;i+1<musicPlaylist.size();i++) for(size_t j=i+1;j<musicPlaylist.size();j++) if(musicPlaylist[i]>musicPlaylist[j]){String t=musicPlaylist[i];musicPlaylist[i]=musicPlaylist[j];musicPlaylist[j]=t;}
}

// ================================================================
//  PNG DECODER (via VFS)
// ================================================================
PNG png;
bool isPng = false;
uint32_t pngWidth = 0, pngHeight = 0;
String imgFilePath = "";
float imgZoom = 1.0;
#define BMP_BLOCK_W 10
#define BMP_BLOCK_H 8
#define MIN_ZOOM 0.5f
#define MAX_ZOOM 4.0f
#define ZOOM_STEP 0.5f

void *pngOpen(const char *filename, int32_t *size) { VfsFile *f=new VfsFile(); if(!f->openRead(filename)){delete f; return nullptr;} *size=f->size(); return f; }
void pngClose(void *handle) { VfsFile *f=(VfsFile*)handle; if(f){f->close();delete f;} }
int32_t pngRead(PNGFILE *page,uint8_t *buffer,int32_t length) { VfsFile *f=(VfsFile*)page->fHandle; if(!f)return 0; return (int32_t)f->read(buffer,length); }
int32_t pngSeek(PNGFILE *page,int32_t position) { VfsFile *f=(VfsFile*)page->fHandle; if(!f)return 0; return f->seek(position) ? position : 0; }

#define PNG_BLOCK_W BMP_BLOCK_W
#define PNG_BLOCK_H BMP_BLOCK_H
int32_t imgOffsetX = 0;
int32_t imgOffsetY = 0;

void sendDrawImageBlock(uint16_t x,uint16_t y,uint16_t w,uint16_t h,const uint8_t* rgbData);

int pngDrawCallback(PNGDRAW *pDraw) {
  uint16_t w=png.getWidth();
  int y_src=pDraw->y;
  float screenY_f=(y_src-imgOffsetY)*imgZoom;
  int screenY=(int)round(screenY_f);
  if(screenY<0||screenY>=DISPLAY_HEIGHT)return 0;
  int repeat=1;
  if(imgZoom>1.0){repeat=(int)ceil(imgZoom);int offset=(repeat-1)/2;screenY-=offset;}
  uint16_t lineBuf565[w];
  png.getLineAsRGB565(pDraw,lineBuf565,0,0);
  for(int r=0;r<repeat;r++){
    int y=screenY+r;
    if(y<0||y>=DISPLAY_HEIGHT)continue;
    for(int sx=0;sx<DISPLAY_WIDTH;sx+=PNG_BLOCK_W){
      int blockW=PNG_BLOCK_W; if(sx+blockW>DISPLAY_WIDTH)blockW=DISPLAY_WIDTH-sx;
      uint8_t blockBuf[blockW*3];
      for(int dx=0;dx<blockW;dx++){
        float srcX_f=imgOffsetX+(sx+dx)/imgZoom;
        int srcX=(int)round(srcX_f);
        if(srcX>=0&&srcX<(int)w){uint16_t rgb565=lineBuf565[srcX];uint8_t r_val=(rgb565>>11)&0x1F;uint8_t g_val=(rgb565>>5)&0x3F;uint8_t b_val=rgb565&0x1F;blockBuf[dx*3+0]=(r_val<<3)|(r_val>>2);blockBuf[dx*3+1]=(g_val<<2)|(g_val>>4);blockBuf[dx*3+2]=(b_val<<3)|(b_val>>2);}
        else memset(blockBuf+dx*3,0,3);
      }
      sendDrawImageBlock(sx,y,blockW,1,blockBuf);
    }
  }
  return 1;
}

bool pngParseHeader(const String& path) { PNG pngInfo; int rc=pngInfo.open(const_cast<char*>(path.c_str()),pngOpen,pngClose,pngRead,pngSeek,NULL); if(rc!=PNG_SUCCESS)return false; pngWidth=pngInfo.getWidth(); pngHeight=pngInfo.getHeight(); pngInfo.close(); return true; }

void drawPngImage() {
  sendFillScreen(0,0,0);
  int rc=png.open(const_cast<char*>(imgFilePath.c_str()),pngOpen,pngClose,pngRead,pngSeek,pngDrawCallback);
  if(rc!=PNG_SUCCESS){sendSetCursor(10,60);sendSetTextColor(255,0,0);sendPrintText("PNG decode error");delay(2000);return;}
  png.decode(NULL,0); png.close();
  sendFillRect(0,DISPLAY_HEIGHT-10,DISPLAY_WIDTH,10,0,0,0);
  sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(80,80,80);
  char info[48]; snprintf(info,sizeof(info),"PNG %ldx%ld  Zoom:%.1fx  HOME=back",(long)pngWidth,(long)pngHeight,imgZoom);
  sendPrintText(info);
}

// ================================================================
//  BMP READER (via VFS)
// ================================================================
int32_t imgWidth=0,imgHeight=0;
uint32_t imgDataOffset=0;
int imgBpp=0;
int32_t imgRowBytes=0;

uint8_t vfsReadByte(VfsFile& f){uint8_t b=0;f.read(&b,1);return b;}
uint16_t bmpRead16(VfsFile& f){uint8_t lo=vfsReadByte(f),hi=vfsReadByte(f);return (uint16_t)lo|((uint16_t)hi<<8);}
uint32_t bmpRead32(VfsFile& f){uint8_t b0=vfsReadByte(f),b1=vfsReadByte(f),b2=vfsReadByte(f),b3=vfsReadByte(f);return (uint32_t)b0|((uint32_t)b1<<8)|((uint32_t)b2<<16)|((uint32_t)b3<<24);}

bool bmpParseHeader(const String& path){VfsFile f;if(!f.openRead(path))return false;uint8_t sig0=vfsReadByte(f),sig1=vfsReadByte(f);if(sig0!='B'||sig1!='M'){f.close();return false;}for(int i=0;i<8;i++)vfsReadByte(f);imgDataOffset=bmpRead32(f);uint32_t dibSize=bmpRead32(f);if(dibSize<40){f.close();return false;}imgWidth=(int32_t)bmpRead32(f);imgHeight=(int32_t)bmpRead32(f);bmpRead16(f);imgBpp=(int)bmpRead16(f);uint32_t compression=bmpRead32(f);f.close();if(imgBpp!=24)return false;if(compression!=0)return false;imgRowBytes=((imgWidth*3+3)/4)*4;return true;}

void sendDrawImageBlock(uint16_t x,uint16_t y,uint16_t w,uint16_t h,const uint8_t* rgbData){
  if(w==0||h==0)return;uint16_t dataLen=8+w*h*3;if(dataLen>255)return;
  while(SerialESP.available())SerialESP.read();
  SerialESP.write(0xAA);SerialESP.write(0x0F);SerialESP.write((uint8_t)dataLen);
  SerialESP.write(x>>8);SerialESP.write(x&0xFF);SerialESP.write(y>>8);SerialESP.write(y&0xFF);
  SerialESP.write(w>>8);SerialESP.write(w&0xFF);SerialESP.write(h>>8);SerialESP.write(h&0xFF);
  SerialESP.write(rgbData,w*h*3);SerialESP.write(0x55);
  unsigned long timeout=millis()+100;
  while(millis()<timeout){if(SerialESP.available()>=4){uint8_t b1=SerialESP.read(),b2=SerialESP.read(),b3=SerialESP.read(),b4=SerialESP.read();if(b1==0xAA&&b2==0x0F&&b3==0x01&&b4==0x55)break;}}
}

void drawBmpImage(){
  sendFillScreen(0,0,0);bool topDown=(imgHeight<0);int32_t realW=imgWidth,realH=topDown?-imgHeight:imgHeight;
  VfsFile f;if(!f.openRead(imgFilePath)){sendSetCursor(10,60);sendSetTextColor(255,0,0);sendPrintText("File open error");return;}
  for(int sy=0;sy<DISPLAY_HEIGHT;sy+=BMP_BLOCK_H){
    int blockH=BMP_BLOCK_H;if(sy+blockH>DISPLAY_HEIGHT)blockH=DISPLAY_HEIGHT-sy;
    float blockSrcTop=imgOffsetY+sy/imgZoom,blockSrcBottom=imgOffsetY+(sy+blockH)/imgZoom;
    if(blockSrcBottom<=0||blockSrcTop>=realH){sendFillRect(0,sy,DISPLAY_WIDTH,blockH,0,0,0);continue;}
    for(int sx=0;sx<DISPLAY_WIDTH;sx+=BMP_BLOCK_W){
      int blockW=BMP_BLOCK_W;if(sx+blockW>DISPLAY_WIDTH)blockW=DISPLAY_WIDTH-sx;
      float blockSrcLeft=imgOffsetX+sx/imgZoom,blockSrcRight=imgOffsetX+(sx+blockW)/imgZoom;
      if(blockSrcRight<=0||blockSrcLeft>=realW){sendFillRect(sx,sy,blockW,blockH,0,0,0);continue;}
      uint8_t* blockBuf=(uint8_t*)malloc(blockW*blockH*3);if(!blockBuf){f.close();return;}
      uint8_t* ptr=blockBuf;
      for(int dy=0;dy<blockH;dy++){
        int yScreen=sy+dy;float srcY_f=imgOffsetY+yScreen/imgZoom;int srcY0=floor(srcY_f);float fracY=srcY_f-srcY0;
        for(int dx=0;dx<blockW;dx++){
          int xScreen=sx+dx;float srcX_f=imgOffsetX+xScreen/imgZoom;int srcX0=floor(srcX_f);float fracX=srcX_f-srcX0;
          uint8_t r=0,g=0,b=0;
          if(srcX0>=0&&srcX0<realW&&srcY0>=0&&srcY0<realH){
            if(imgZoom>=1.0){int srcX=(int)round(srcX_f),srcY=(int)round(srcY_f);if(srcX<0)srcX=0;if(srcX>=realW)srcX=realW-1;if(srcY<0)srcY=0;if(srcY>=realH)srcY=realH-1;int32_t fileRow=topDown?srcY:(realH-1-srcY);uint32_t rowStart=imgDataOffset+fileRow*imgRowBytes;if(f.seek(rowStart+srcX*3)){b=vfsReadByte(f);g=vfsReadByte(f);r=vfsReadByte(f);}}
            else{int srcX1=srcX0,srcX2=srcX0+1,srcY1=srcY0,srcY2=srcY0+1;if(srcX1<0)srcX1=0;if(srcX1>=realW)srcX1=realW-1;if(srcX2<0)srcX2=0;if(srcX2>=realW)srcX2=realW-1;if(srcY1<0)srcY1=0;if(srcY1>=realH)srcY1=realH-1;if(srcY2<0)srcY2=0;if(srcY2>=realH)srcY2=realH-1;auto readPixel=[&](int sx,int sy,uint8_t& rr,uint8_t& gg,uint8_t& bb){int32_t row=topDown?sy:(realH-1-sy);uint32_t rs=imgDataOffset+row*imgRowBytes;if(f.seek(rs+sx*3)){bb=vfsReadByte(f);gg=vfsReadByte(f);rr=vfsReadByte(f);}else{rr=gg=bb=0;}};uint8_t r11,g11,b11,r12,g12,b12,r21,g21,b21,r22,g22,b22;readPixel(srcX1,srcY1,r11,g11,b11);readPixel(srcX2,srcY1,r12,g12,b12);readPixel(srcX1,srcY2,r21,g21,b21);readPixel(srcX2,srcY2,r22,g22,b22);float fx=fracX,fy=fracY;float r1=r11*(1-fx)+r12*fx,g1=g11*(1-fx)+g12*fx,b1=b11*(1-fx)+b12*fx;float r2=r21*(1-fx)+r22*fx,g2=g21*(1-fx)+g22*fx,b2=b21*(1-fx)+b22*fx;r=(uint8_t)(r1*(1-fy)+r2*fy);g=(uint8_t)(g1*(1-fy)+g2*fy);b=(uint8_t)(b1*(1-fy)+b2*fy);}
          }
          *ptr++=r;*ptr++=g;*ptr++=b;
        }
      }
      sendDrawImageBlock(sx,sy,blockW,blockH,blockBuf);free(blockBuf);
    }
  }
  f.close();
  sendFillRect(0,DISPLAY_HEIGHT-10,DISPLAY_WIDTH,10,0,0,0);sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(80,80,80);
  char info[48];snprintf(info,sizeof(info),"Zoom:%.1fx  %ldx%ld  HOME=back",imgZoom,(long)imgWidth,(long)(imgHeight<0?-imgHeight:imgHeight));sendPrintText(info);
}
void sendDrawKeyboardBlock(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b, bool fill = true) {
  if (w == 0 || h == 0) return;
  
  uint16_t dataLen = 8 + 3; // координаты + размер + цвет
  if (dataLen > 255) return;
  
  // Очищаем буфер
  while (SerialESP.available()) SerialESP.read();
  
  // Отправляем команду
  SerialESP.write(0xAA);
  if (fill) {
    SerialESP.write(0x05); // fill rect
  } else {
    SerialESP.write(0x06); // draw rect
  }
  SerialESP.write((uint8_t)dataLen);
  SerialESP.write(x >> 8); SerialESP.write(x & 0xFF);
  SerialESP.write(y >> 8); SerialESP.write(y & 0xFF);
  SerialESP.write(w >> 8); SerialESP.write(w & 0xFF);
  SerialESP.write(h >> 8); SerialESP.write(h & 0xFF);
  SerialESP.write(r); SerialESP.write(g); SerialESP.write(b);
  SerialESP.write(0x55);
  
  // Ждём подтверждение
  unsigned long timeout = millis() + 100;
  while (millis() < timeout) {
    if (SerialESP.available() >= 4) {
      uint8_t b1 = SerialESP.read();
      uint8_t b2 = SerialESP.read();
      uint8_t b3 = SerialESP.read();
      uint8_t b4 = SerialESP.read();
      if (b1 == 0xAA && b2 == 0x05 && b3 == 0x01 && b4 == 0x55) break;
      if (b1 == 0xAA && b2 == 0x06 && b3 == 0x01 && b4 == 0x55) break;
    }
    delay(1);
  }
  delay(2); // небольшая задержка между командами
}

void drawImage(){if(isPng)drawPngImage();else drawBmpImage();}
bool openImage(const String& path){imgFilePath=path;imgOffsetX=0;imgOffsetY=0;imgZoom=1.0;String lower=path;lower.toLowerCase();if(lower.endsWith(".bmp")){if(!bmpParseHeader(path)){sendFillScreen(0,0,0);sendSetCursor(5,55);sendSetTextColor(255,80,80);sendPrintText("Unsupported BMP");delay(2000);return false;}isPng=false;return true;}else if(lower.endsWith(".png")){if(!pngParseHeader(path)){sendFillScreen(0,0,0);sendSetCursor(5,55);sendSetTextColor(255,80,80);sendPrintText("Unsupported PNG");delay(2000);return false;}isPng=true;return true;}return false;}
#define IMG_PAN_STEP 60

// ================================================================
//  ПОДСВЕТКА ДИСПЛЕЯ (DISPLAY_LED_PIN)
// ================================================================
#define DISPLAY_LED_PIN 21
uint8_t displayBrightness = 255; // 0..255, 255 = полная яркость

void setDisplayBrightness(uint8_t b) {
  displayBrightness = b;
  analogWrite(DISPLAY_LED_PIN, b); // ШИМ-регулировка яркости подсветки
}

// ================================================================
//  SETTINGS PERSIST
// ================================================================
struct Settings{uint32_t sampleRate;uint8_t rotation,volume,brightness;float speed;};
void saveSettings(){Settings cfg;cfg.sampleRate=audioSampleRate;cfg.rotation=displayRotation;cfg.volume=audioVolume;cfg.brightness=displayBrightness;cfg.speed=audioSpeed;File f=LittleFS.open("/settings.dat","w");if(f){f.write((uint8_t*)&cfg,sizeof(cfg));f.close();}}
void loadSettings(){if(!LittleFS.exists("/settings.dat")){audioSampleRate=8000;displayRotation=3;audioVolume=128;displayBrightness=255;audioSpeed=1.0;return;}File f=LittleFS.open("/settings.dat","r");if(f){Settings cfg;if(f.read((uint8_t*)&cfg,sizeof(cfg))==sizeof(cfg)){audioSampleRate=cfg.sampleRate;displayRotation=cfg.rotation;audioVolume=cfg.volume;displayBrightness=cfg.brightness;audioSpeed=cfg.speed;sendSetRotation(displayRotation);setVolume(audioVolume);setDisplayBrightness(displayBrightness);setSpeed(audioSpeed);}f.close();}}

void initLittleFS(){
  if(!LittleFS.begin()){sendFillScreen(0,0,0);sendSetCursor(5,50);sendSetTextColor(255,0,0);sendPrintText("LittleFS error!");delay(2000);return;}
  if(!LittleFS.exists("/readme.md")){File f=LittleFS.open("/readme.md","w");if(f){f.println("# Text Reader v6");f.println();f.println("## Controls");f.println();f.println("UP/DOWN or Encoder - scroll");f.println("LEFT/RIGHT - horizontal scroll");f.println("OK (hold) - headings menu");f.println("HOME - back");f.println();f.println("## Storage");f.println("/sda = onboard flash, /sdb1 (sdb2...) = USB drive partitions");f.close();}}
}

void formatInternal(){stopMusic();sendFillScreen(0,0,0);sendSetCursor(20,50);sendSetTextColor(255,255,0);sendPrintText("Formatting...");LittleFS.end();LittleFS.format();LittleFS.begin();initLittleFS();sendFillScreen(0,0,0);sendSetCursor(25,50);sendSetTextColor(0,255,0);sendPrintText("Done!");delay(1200);}

// ================================================================
//  SERIAL FILE TRANSFER (text protocol, same as PicoFileHub:
//  LIST/INFO/GET/PUT/MKDIR/DEL - so the same pico_tool.py PC script works)
// ================================================================
static String g_serialLineBuf;

static void splitFirstToken(const String &in, String &head, String &rest) {
  int sp=in.indexOf(' ');
  if(sp<0){head=in;rest="";} else {head=in.substring(0,sp);rest=in.substring(sp+1);}
  head.trim();rest.trim();
}

static void scmdList(const String &path) {
  if(!vfsExists(path)||!vfsIsDir(path)){SerialPC.println("ERR not_a_directory");return;}
  std::vector<VfsEntry> entries; vfsListDir(path,entries);
  for(auto &e:entries){ if(e.isDir) SerialPC.println("D "+e.name); else SerialPC.println("F "+e.name+" "+String(e.size)); }
  SerialPC.println("OK");
}
static void scmdInfo() { SerialPC.println(String("external_mounted=")+(vfsExternalMounted()?"1":"0")); SerialPC.println(String("external_partitions=")+String(vfsExternalPartitionCount())); SerialPC.println("OK"); }
static void scmdGet(const String &path) {
  VfsFile f; if(!f.openRead(path)){SerialPC.println("ERR open_failed");return;}
  uint32_t sz=f.size(); SerialPC.println("SIZE:"+String(sz));
  uint8_t buf[512]; uint32_t remaining=sz;
  while(remaining>0){ size_t chunk=remaining>sizeof(buf)?sizeof(buf):remaining; size_t got=f.read(buf,chunk); if(got==0)break; SerialPC.write(buf,got); remaining-=got; }
  f.close(); SerialPC.println("OK");
}
static void scmdPut(const String &path, uint32_t size) {
  VfsFile f; if(!f.openWrite(path)){SerialPC.println("ERR open_failed");return;}
  uint8_t buf[512]; uint32_t remaining=size; uint32_t lastByte=millis(); bool timedOut=false;
  while(remaining>0){
    size_t want=remaining>sizeof(buf)?sizeof(buf):remaining;
    size_t got=SerialPC.readBytes(buf,want);
    if(got>0){ f.write(buf,got); remaining-=got; lastByte=millis(); }
    else if(millis()-lastByte>5000){ timedOut=true; break; }
  }
  f.close();
  SerialPC.println(timedOut?"ERR timeout":"OK");
}
static void scmdMkdir(const String &path){ SerialPC.println(vfsMkdir(path)?"OK":"ERR mkdir_failed"); }
static void scmdDel(const String &path){ SerialPC.println(vfsRemove(path)?"OK":"ERR remove_failed"); }

static void handleSerialLine(const String &line) {
  String head, rest; splitFirstToken(line, head, rest);
  if(head=="LIST") scmdList(rest);
  else if(head=="INFO") scmdInfo();
  else if(head=="GET") scmdGet(rest);
  else if(head=="MKDIR") scmdMkdir(rest);
  else if(head=="DEL") scmdDel(rest);
  else if(head=="PUT") { String p2,sizeStr; splitFirstToken(rest,p2,sizeStr); scmdPut(p2,(uint32_t)sizeStr.toInt()); }
  else if(head.length()==0) { /* ignore */ }
  else SerialPC.println("ERR unknown_command");
}

void handleSerialCommands(){
  while(SerialPC.available()){
    char c=(char)SerialPC.read();
    if(c=='\n'){ handleSerialLine(g_serialLineBuf); g_serialLineBuf=""; if(currentState==STATE_FILE_BROWSER) refreshBrowser(); }
    else if(c!='\r'){ g_serialLineBuf+=c; if(g_serialLineBuf.length()>512) g_serialLineBuf=""; }
  }
}

// ================================================================
//  MUSIC PLAYER UI (folder-scoped playlist)
// ================================================================
void drawMusicPlayer();
void playNextTrack(){if(!autoPlayNext||musicPlaylist.empty())return;if(selectedMusic<(int)musicPlaylist.size()-1){selectedMusic++;if(selectedMusic>=musicScrollOffset+3)musicScrollOffset=selectedMusic-2;}else{selectedMusic=0;musicScrollOffset=0;}startMusic(vfsJoin(musicDirPath,musicPlaylist[selectedMusic]));drawMusicPlayer();}
void playPreviousTrack(){if(musicPlaylist.empty())return;if(selectedMusic>0){selectedMusic--;if(selectedMusic<musicScrollOffset)musicScrollOffset=selectedMusic;}else{selectedMusic=(int)musicPlaylist.size()-1;musicScrollOffset=max(0,selectedMusic-2);}startMusic(vfsJoin(musicDirPath,musicPlaylist[selectedMusic]));drawMusicPlayer();}

void drawMusicPlayer(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,13,0,70,130);sendSetCursor(20,2);sendSetTextColor(255,255,255);sendPrintText("MUSIC PLAYER");
  sendFillRect(0,14,DISPLAY_WIDTH,20,20,20,40);sendSetCursor(4,18);sendSetTextColor(200,220,255);
  if(musicPlaying&&musicFileNameForUI.length()>0){sendPrintText("Now:");sendSetCursor(4+9+9+9,17);String fn=musicFileNameForUI;if(utf8Len(fn)>22)fn=utf8Substr(fn,0,19)+"...";sendPrintStr(fn);if(musicPaused){sendSetCursor(120,18);sendSetTextColor(255,200,0);sendPrintText("PAUSE");}}
  else{sendPrintText("No track");sendSetCursor(4,28);sendSetTextColor(150,150,150);String dn=musicDirPath.length()?musicDirPath:"(no folder)";if(utf8Len(dn)>24)dn=utf8Substr(dn,0,21)+"...";sendPrintStr(dn);}
  int leftX=5,volY=42,volHeight=58;sendDrawRect(leftX,volY,12,volHeight,80,80,80);int volFill=(audioVolume*volHeight)/255;if(volFill>0)sendFillRect(leftX+1,volY+volHeight-volFill,10,volFill,0,200,255);char volText[8];snprintf(volText,sizeof(volText),"%d%%",(audioVolume*100)/255);sendSetCursor(leftX,volY+volHeight+2);sendSetTextColor(200,200,200);sendPrintText(volText);
  int rightX=DISPLAY_WIDTH-17,spdY=42,spdHeight=58;sendDrawRect(rightX,spdY,12,spdHeight,80,80,80);int speedPercent=(int)((audioSpeed-0.5)*100/1.5);speedPercent=constrain(speedPercent,0,100);int spdFill=(speedPercent*spdHeight)/100;if(spdFill>0)sendFillRect(rightX+1,spdY+spdHeight-spdFill,10,spdFill,255,150,0);char spdText[8];if(audioSpeed==(int)audioSpeed)snprintf(spdText,sizeof(spdText),"%dx",(int)audioSpeed);else snprintf(spdText,sizeof(spdText),"%.1fx",audioSpeed);sendSetCursor(rightX,spdY+spdHeight+2);sendSetTextColor(200,200,200);sendPrintText(spdText);
  int playlistX=20,playlistY=42,playlistWidth=DISPLAY_WIDTH-40,playlistHeight=58;sendDrawRect(playlistX-2,playlistY-2,playlistWidth+4,playlistHeight+4,40,40,60);sendSetCursor(playlistX,playlistY-9);sendSetTextColor(180,180,180);char plTitle[24];snprintf(plTitle,sizeof(plTitle),"FOLDER (%d)",(int)musicPlaylist.size());sendPrintText(plTitle);
  int vis=4,itemHeight=13;
  if(musicPlaylist.empty()){sendSetCursor(playlistX+2,playlistY+10);sendSetTextColor(150,80,80);sendPrintText("No audio files");sendSetCursor(playlistX+2,playlistY+23);sendSetTextColor(150,150,150);sendPrintText("HOME=pick folder");}
  for(int i=0;i<vis&&(musicScrollOffset+i)<(int)musicPlaylist.size();i++){int idx=musicScrollOffset+i,yPos=playlistY+i*itemHeight;if(idx==selectedMusic){sendFillRect(playlistX-1,yPos-1,playlistWidth,itemHeight-1,0,80,80);sendSetTextColor(0,255,200);}else sendSetTextColor(160,160,160);char numStr[5];snprintf(numStr,sizeof(numStr),"%d.",idx+1);sendSetCursor(playlistX,yPos);sendPrintText(numStr);String fn=musicPlaylist[idx];int maxLen=(playlistWidth-20)/CHAR_W;if(utf8Len(fn)>maxLen)fn=utf8Substr(fn,0,maxLen-2)+"..";sendSetCursor(playlistX+15,yPos);sendPrintStr(fn);if(musicPlaying&&musicFileNameForUI==musicPlaylist[idx]){sendSetCursor(playlistX+playlistWidth-10,yPos);sendSetTextColor(0,255,0);sendPrintText(musicPaused?"||":">");}}
  sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,60);sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(110,110,110);sendPrintText("ENC=track L/R=vol OK=play H=folders");
}

void updateProgressBar(){
  static unsigned long lastUpdate=0;unsigned long now=millis();if(now-lastUpdate>=300){lastUpdate=now;if(musicPlaying&&!musicPaused&&currentState==STATE_MUSIC_PLAYER&&musicTotalSize>0){int progress=(musicPosition*100)/musicTotalSize;if(progress>100)progress=100;int barWidth=DISPLAY_WIDTH-20,filledWidth=(barWidth*progress)/100;sendDrawRect(10,33,barWidth,7,80,80,80);if(filledWidth>0)sendFillRect(11,34,filledWidth-2,5,0,200,100);}}
}

// ================================================================
//  SAMPLE RATE EDITOR (unchanged from v5)
// ================================================================
void drawSampleRateEditor(){sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,13,0,70,100);sendSetCursor(20,2);sendSetTextColor(255,255,255);sendPrintText("SET SAMPLE RATE");sendFillRect(0,20,DISPLAY_WIDTH,20,10,10,30);sendSetCursor(2,23);sendSetTextColor(200,230,255);sendPrintText("Rate (Hz): ");sendPrintText(sampleRateStr);sendSetTextColor(255,255,0);int cursorX=2+strlen("Rate (Hz): ")*CHAR_W+sampleRateEditPos*CHAR_W;sendSetCursor(cursorX,23);sendPrintText("_");sendSetCursor(5,55);sendSetTextColor(150,150,150);sendPrintText("UP/DN or ENC: change digit");sendSetCursor(5,67);sendPrintText("LEFT/RIGHT: move");sendSetCursor(5,79);sendPrintText("OK: save   HOME: cancel");sendSetCursor(5,100);sendSetTextColor(100,200,100);sendPrintText("Range: 1000-48000 Hz");}

// ================================================================
//  INTRO (unchanged from v5)
// ================================================================
void drawFancyIntro(){
  bool skip=false;
  for(int y=0;y<DISPLAY_HEIGHT&&!skip;y++){if(y%4==0){updateButtons();if(bUp.pressed()||bDown.pressed()||bLeft.pressed()||bRight.pressed()||bOk.pressed()||bHome.pressed()||bCancel.pressed()||bEncBtn.pressed())skip=true;if(readEncoderDelta()!=0)skip=true;}uint8_t r=30+(y*170)/DISPLAY_HEIGHT,g=40+(y*100)/DISPLAY_HEIGHT,b=80+(y*120)/DISPLAY_HEIGHT;sendDrawLine(0,y,DISPLAY_WIDTH-1,y,r,g,b);delay(3);}
  const char* line1="TEXT READER v6";int line1_x=(DISPLAY_WIDTH-strlen(line1)*CHAR_W)/2;
  sendSetTextColor(255,200,50);for(int i=0;i<=(int)strlen(line1)&&!skip;i++){updateButtons();if(bOk.pressed()||bHome.pressed()||bEncBtn.pressed()){skip=true;break;}if(readEncoderDelta()!=0){skip=true;break;}sendSetCursor(line1_x,40);char part[20];strncpy(part,line1,i);part[i]=0;sendPrintText(part);delay(60);}
  sendFillRect(30,100,DISPLAY_WIDTH-60,8,20,20,20);sendDrawRect(30,100,DISPLAY_WIDTH-60,8,100,100,200);
  for(int p=0;p<=100&&!skip;p++){updateButtons();if(bOk.pressed()||bHome.pressed()||bEncBtn.pressed()){skip=true;break;}if(readEncoderDelta()!=0){skip=true;break;}int filled=(DISPLAY_WIDTH-62)*p/100;sendFillRect(31,101,filled,6,0,200,100);sendSetCursor(DISPLAY_WIDTH/2-20,88);sendSetTextColor(255,255,200);char buf[16];snprintf(buf,sizeof(buf),"Loading %d%%",p);sendPrintText(buf);delay(15);}
  sendFillScreen(0,0,0);
}

// ================================================================
//  FILE BROWSER MENU / INFO (VFS-based)
// ================================================================
void drawFileBrowserMenu(){sendFillRect(0,0,DISPLAY_WIDTH,DISPLAY_HEIGHT,20,20,30);int menuW=110,menuH=78,menuX=(DISPLAY_WIDTH-menuW)/2,menuY=(DISPLAY_HEIGHT-menuH)/2;sendFillRect(menuX,menuY,menuW,menuH,40,40,50);sendDrawRect(menuX,menuY,menuW,menuH,160,160,200);sendSetCursor(menuX+10,menuY+5);sendSetTextColor(220,220,255);sendPrintText("Action");const char* items[]={"Open","Delete","Info"};for(int i=0;i<3;i++){int y=menuY+20+i*18;if(i==fbMenuSelected){sendFillRect(menuX+5,y-2,menuW-10,14,0,100,150);sendSetTextColor(255,255,100);}else sendSetTextColor(200,200,200);sendSetCursor(menuX+(menuW-strlen(items[i])*CHAR_W)/2,y+2);sendPrintText(items[i]);}sendSetCursor(menuX+5,menuY+menuH-10);sendSetTextColor(130,130,130);sendPrintText("OK=select  H=back");}

void collectFileInfo(const String& path){
  infoFilePath=path;infoFileSize=vfsFileSize(path);infoType="";infoDetails="";
  String lower=path;lower.toLowerCase();
  if(isTextFile(path)){infoType="Text file";VfsFile tf;if(tf.openRead(path)){int lines=0;uint8_t b;while(tf.read(&b,1)==1){if(b=='\n')lines++;}if(lines==0&&infoFileSize>0)lines=1;tf.close();infoDetails=String(lines)+" lines";}else infoDetails="? lines";}
  else if(lower.endsWith(".bmp")){infoType="BMP image";if(bmpParseHeader(path)){int32_t w=imgWidth,h=(imgHeight<0)?-imgHeight:imgHeight;infoDetails=String(w)+"x"+String(h)+" px, 24bpp";}else infoDetails="Unsupported BMP";}
  else if(lower.endsWith(".png")){infoType="PNG image";if(pngParseHeader(path))infoDetails=String(pngWidth)+"x"+String(pngHeight)+" px";else infoDetails="Unsupported PNG";}
  else if(isAudioFile(path)){String t,d;audioProbeFile(path,t,d);infoType=t;infoDetails=d;}
  else{infoType="File";infoDetails="No preview available";}
}

void drawFileInfo(){sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,13,0,70,100);sendSetCursor(38,2);sendSetTextColor(255,255,255);sendPrintText("FILE INFO");String shortName=infoFilePath.substring(infoFilePath.lastIndexOf('/')+1);if(utf8Len(shortName)>20)shortName=utf8Substr(shortName,0,17)+"...";sendSetCursor(5,20);sendSetTextColor(200,220,255);sendPrintText("Name: ");sendSetTextColor(255,255,200);sendPrintStr(shortName);sendSetCursor(5,33);sendSetTextColor(200,220,255);sendPrintText("Size: ");sendSetTextColor(255,255,200);char sizeBuf[32];if(infoFileSize<1024)snprintf(sizeBuf,sizeof(sizeBuf),"%lu B",infoFileSize);else if(infoFileSize<1024*1024)snprintf(sizeBuf,sizeof(sizeBuf),"%.2f KB",infoFileSize/1024.0);else snprintf(sizeBuf,sizeof(sizeBuf),"%.2f MB",infoFileSize/(1024.0*1024.0));sendPrintText(sizeBuf);sendSetCursor(5,46);sendSetTextColor(200,220,255);sendPrintText("Type: ");sendSetTextColor(255,255,200);sendPrintStr(infoType);if(infoDetails.length()>0){sendSetCursor(5,59);sendSetTextColor(200,220,255);sendPrintText("Details: ");sendSetTextColor(255,255,200);if(utf8Len(infoDetails)>20)infoDetails=utf8Substr(infoDetails,0,17)+"...";sendPrintStr(infoDetails);}sendSetCursor(5,72);sendSetTextColor(200,220,255);sendPrintText("Path: ");sendSetTextColor(150,200,255);String pp=infoFilePath;if(utf8Len(pp)>22)pp=utf8Substr(pp,0,19)+"...";sendPrintStr(pp);sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,60);sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(130,130,130);sendPrintText("ANY KEY = back");}



// Функция ожидания подтверждения от дисплея
void waitForDisplayAck() {
  unsigned long timeout = millis() + 50;
  while (millis() < timeout) {
    if (SerialESP.available() >= 4) {
      uint8_t b1 = SerialESP.read();
      uint8_t b2 = SerialESP.read();
      uint8_t b3 = SerialESP.read();
      uint8_t b4 = SerialESP.read();
      if (b1 == 0xAA && b2 == 0x0F && b3 == 0x01 && b4 == 0x55) break;
      if (b1 == 0xAA && b2 == 0x05 && b3 == 0x01 && b4 == 0x55) break;
      if (b1 == 0xAA && b2 == 0x06 && b3 == 0x01 && b4 == 0x55) break;
    }
    delay(1);
  }
}

// Функции с ожиданием подтверждения
void sendFillRectWithWait(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b) {
  if (w == 0 || h == 0) return;
  
  while (SerialESP.available()) SerialESP.read();
  
  uint8_t c[] = {0xAA, 0x05, 0x0B, 
                 (uint8_t)(x>>8), (uint8_t)x, 
                 (uint8_t)(y>>8), (uint8_t)y,
                 (uint8_t)(w>>8), (uint8_t)w,
                 (uint8_t)(h>>8), (uint8_t)h,
                 r, g, b, 0x55};
  SerialESP.write(c, 15);
  waitForDisplayAck();
  delay(1);
}

void sendDrawRectWithWait(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint8_t r, uint8_t g, uint8_t b) {
  if (w == 0 || h == 0) return;
  
  while (SerialESP.available()) SerialESP.read();
  
  uint8_t c[] = {0xAA, 0x06, 0x0B,
                 (uint8_t)(x>>8), (uint8_t)x,
                 (uint8_t)(y>>8), (uint8_t)y,
                 (uint8_t)(w>>8), (uint8_t)w,
                 (uint8_t)(h>>8), (uint8_t)h,
                 r, g, b, 0x55};
  SerialESP.write(c, 15);
  waitForDisplayAck();
  delay(1);
}

void sendSetCursorWithWait(uint16_t x, uint16_t y) {
  while (SerialESP.available()) SerialESP.read();
  
  uint8_t c[] = {0xAA, 0x08, 0x04, (uint8_t)(x>>8), (uint8_t)x, (uint8_t)(y>>8), (uint8_t)y, 0x55};
  SerialESP.write(c, 8);
  waitForDisplayAck();
  delay(1);
}

void sendSetTextColorWithWait(uint8_t r, uint8_t g, uint8_t b) {
  while (SerialESP.available()) SerialESP.read();
  
  uint8_t c[] = {0xAA, 0x09, 0x03, r, g, b, 0x55};
  SerialESP.write(c, 7);
  waitForDisplayAck();
  delay(1);
}

void sendPrintTextWithWait(const char* t) {
  int n = strlen(t);
  if (n == 0) return;
  if (n > 255) n = 255;
  
  while (SerialESP.available()) SerialESP.read();
  
  SerialESP.write(0xAA);
  SerialESP.write(0x0A);
  SerialESP.write((uint8_t)n);
  SerialESP.write((const uint8_t*)t, n);
  SerialESP.write(0x55);
  waitForDisplayAck();
  delay(1);
}



// ================================================================
//  STATUS OVERLAY (unchanged from v5)
// ================================================================
unsigned long statusWindowStart=0;
const unsigned long STATUS_WINDOW_DURATION=3000;

String getUptimeString(){unsigned long seconds=millis()/1000,hours=seconds/3600;seconds%=3600;unsigned long minutes=seconds/60;seconds%=60;char buf[12];snprintf(buf,sizeof(buf),"%02lu:%02lu:%02lu",hours,minutes,seconds);return String(buf);}

void drawStatusOverlay(){
  sendFillScreen(10,10,30);sendDrawRect(0,0,DISPLAY_WIDTH-1,DISPLAY_HEIGHT-1,100,150,200);
  sendSetCursor((DISPLAY_WIDTH-strlen(" SYSTEM STATUS ")*CHAR_W)/2,8);sendSetTextColor(255,200,0);sendPrintText(" SYSTEM STATUS ");
  sendDrawLine(10,18,DISPLAY_WIDTH-10,18,80,120,180);
  sendSetCursor(10,30);sendSetTextColor(150,200,255);sendPrintText("Uptime:");sendSetCursor(10+CHAR_W*8,30);sendSetTextColor(100,255,100);sendPrintText(getUptimeString().c_str());
  sendSetCursor(10,42);sendSetTextColor(150,200,255);sendPrintText("USB drive:");sendSetCursor(10+CHAR_W*11,42);if(vfsExternalMounted()){sendSetTextColor(100,255,100);char pc[16];snprintf(pc,sizeof(pc),"%d part(s)",vfsExternalPartitionCount());sendPrintText(pc);}else{sendSetTextColor(150,150,150);sendPrintText("not present");}
  int yMusic=58;
  if(musicPlaying&&!musicPaused){sendSetCursor(10,yMusic);sendSetTextColor(255,200,100);sendPrintText("Now playing:");String shortName=musicFileNameForUI;int maxLen=(DISPLAY_WIDTH/CHAR_W)-12;if(utf8Len(shortName)>maxLen)shortName=utf8Substr(shortName,0,maxLen-2)+"..";sendSetCursor(10+CHAR_W*12,yMusic);sendSetTextColor(255,255,200);sendPrintStr(shortName);if(musicTotalSize>0){int progress=(musicPosition*100)/musicTotalSize;if(progress>100)progress=100;int barX=10,barY=yMusic+12,barW=DISPLAY_WIDTH-20,filled=(barW*progress)/100;sendDrawRect(barX,barY,barW,8,80,80,80);if(filled>2)sendFillRect(barX+1,barY+1,filled-2,6,0,200,100);}}
  else{sendSetCursor(10,yMusic);sendSetTextColor(150,150,150);sendPrintText("Music: not playing");}
  sendFillRect(0,DISPLAY_HEIGHT-12,DISPLAY_WIDTH,12,0,0,40);sendSetCursor(5,DISPLAY_HEIGHT-9);sendSetTextColor(100,100,120);sendPrintText("Press any key to close");
}

// ================================================================
//  TEXT VIEWER (loads from VFS) + HEADINGS
// ================================================================
String lineCache[MAX_LINES];
int totalLines=0;
int headingLines[MAX_HEADINGS];
String headingTexts[MAX_HEADINGS];
int headingCount=0;
int textScrollLine=0,textScrollCol=0;
int hmSelected=0,hmScroll=0;
#define HM_VISIBLE 7
String currentFilePath="";

bool loadFileLines(const String& path){
  if(!vfsExists(path))return false;
  VfsFile f; if(!f.openRead(path))return false;
  totalLines=0;headingCount=0;String line="";
  uint8_t b;
  while(f.read(&b,1)==1){
    char c=(char)b;
    if(c=='\r')continue;
    if(c=='\n'){if(totalLines<MAX_LINES){lineCache[totalLines]=line;if(line.startsWith("#")&&headingCount<MAX_HEADINGS){headingLines[headingCount]=totalLines;headingTexts[headingCount]=line.substring(0,40);headingCount++;}totalLines++;}line="";}
    else line+=c;
  }
  if(line.length()>0&&totalLines<MAX_LINES){lineCache[totalLines]=line;if(line.startsWith("#")&&headingCount<MAX_HEADINGS){headingLines[headingCount]=totalLines;headingTexts[headingCount]=line.substring(0,40);headingCount++;}totalLines++;}
  f.close();if(totalLines==0){lineCache[0]="(empty)";totalLines=1;}return true;
}

int maxScrollCol(){int mx=0;for(int i=0;i<MAX_VIEW_LINES;i++){int idx=textScrollLine+i;if(idx>=totalLines)break;int l=utf8Len(lineCache[idx]);if(l>mx)mx=l;}return max(0,mx-CHARS_PER_LINE);}
void setLineColor(const String& line){if(line.startsWith("### "))sendSetTextColor(100,200,255);else if(line.startsWith("## "))sendSetTextColor(0,220,180);else if(line.startsWith("# "))sendSetTextColor(0,255,255);else if(line.startsWith("- ")||line.startsWith("* "))sendSetTextColor(200,200,200);else sendSetTextColor(255,255,255);}

void drawFileViewer(){
  sendFillRect(0,VIEW_Y0,DISPLAY_WIDTH,VIEW_Y1-VIEW_Y0,0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,HDR_H,0,0,100);sendSetCursor(2,2);sendSetTextColor(255,255,255);
  String fn=currentFilePath.substring(currentFilePath.lastIndexOf('/')+1);if(utf8Len(fn)>16)fn=utf8Substr(fn,0,13)+"...";sendPrintStr(fn);
  char pos[12];snprintf(pos,sizeof(pos),"%d/%d",textScrollLine+1,totalLines);sendSetCursor(DISPLAY_WIDTH-(int)strlen(pos)*CHAR_W-2,2);sendPrintText(pos);
  for(int i=0;i<MAX_VIEW_LINES;i++){int idx=textScrollLine+i;if(idx>=totalLines)break;const String& raw=lineCache[idx];int len=utf8Len(raw);if(textScrollCol>=len)continue;String slice=utf8Substr(raw,textScrollCol,textScrollCol+CHARS_PER_LINE);if(slice.length()==0)continue;setLineColor(raw);sendSetCursor(0,VIEW_Y0+i*LINE_H);sendPrintStr(slice);}
  sendFillRect(0,DISPLAY_HEIGHT-FTR_H,DISPLAY_WIDTH,FTR_H,0,0,60);sendSetCursor(2,DISPLAY_HEIGHT-FTR_H+1);sendSetTextColor(130,130,130);if(headingCount>0){char inf[32];snprintf(inf,sizeof(inf),"ENC=scroll  %d #headings",headingCount);sendPrintText(inf);}else sendPrintText("ENC=scroll  LR=col  HOME=back");
}

void drawHeadingMenu(){
  int bx=8,by=10,bw=DISPLAY_WIDTH-16,bh=DISPLAY_HEIGHT-20;sendFillRect(bx,by,bw,bh,10,10,40);sendDrawRect(bx,by,bw,bh,0,150,200);sendSetCursor(bx+4,by+2);sendSetTextColor(0,220,255);sendPrintText("# HEADINGS");char cnt[12];snprintf(cnt,sizeof(cnt),"(%d)",headingCount);sendSetCursor(bx+bw-strlen(cnt)*CHAR_W-4,by+2);sendPrintText(cnt);
  if(headingCount==0){sendSetCursor(bx+10,by+25);sendSetTextColor(180,100,100);sendPrintText("No headings found");sendSetCursor(bx+10,by+38);sendSetTextColor(130,130,130);sendPrintText("OK/HOME = close");return;}
  int yStart=by+13,lh=11;
  for(int i=0;i<HM_VISIBLE&&(hmScroll+i)<headingCount;i++){int hi=hmScroll+i,yPx=yStart+i*lh;if(hi==hmSelected){sendFillRect(bx+1,yPx-1,bw-2,lh,0,80,120);sendSetTextColor(255,255,100);}else sendSetTextColor(200,200,200);sendSetCursor(bx+4,yPx);String ht=headingTexts[hi];int maxCh=(bw/CHAR_W)-1;if(utf8Len(ht)>maxCh)ht=utf8Substr(ht,0,maxCh-2)+"..";sendPrintStr(ht);}
  if(hmScroll>0){sendSetCursor(bx+bw-8,yStart);sendSetTextColor(0,220,0);sendPrintText("^");}
  if(hmScroll+HM_VISIBLE<headingCount){sendSetCursor(bx+bw-8,yStart+(HM_VISIBLE-1)*lh);sendSetTextColor(0,220,0);sendPrintText("v");}
  sendSetCursor(bx+4,by+bh-10);sendSetTextColor(100,100,100);sendPrintText("OK/ENC=jump  HOME=close");
}

// ================================================================
//  MAIN MENU
// ================================================================
void drawMenu(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,14,0,50,90);sendSetCursor(10,3);sendSetTextColor(255,255,255);sendPrintText("TEXT READER v6");
  for(int i=0;i<MENU_VISIBLE&&(menuScrollOffset+i)<MENU_ITEMS_COUNT;i++){int idx=menuScrollOffset+i,y=18+i*20;if(selectedMenu==idx){sendFillRect(3,y-1,DISPLAY_WIDTH-6,18,0,70,30);sendDrawRect(3,y-1,DISPLAY_WIDTH-6,18,0,160,80);sendSetTextColor(0,255,160);}else sendSetTextColor(180,180,180);sendSetCursor(8,y+3);sendPrintText(MENU_LABELS[idx]);}
  if(menuScrollOffset>0){sendSetCursor(DISPLAY_WIDTH-10,18);sendSetTextColor(0,200,100);sendPrintText("^");}
  if(menuScrollOffset+MENU_VISIBLE<MENU_ITEMS_COUNT){sendSetCursor(DISPLAY_WIDTH-10,18+(MENU_VISIBLE-1)*20);sendSetTextColor(0,200,100);sendPrintText("v");}
  sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,60);sendSetCursor(3,DISPLAY_HEIGHT-9);sendSetTextColor(120,120,120);sendPrintText("ENC/UD  OK=open");
}

// ================================================================
//  GENERIC FILE BROWSER (VFS: /sda + /sdb1, /sdb2, ..., full explorer)
// ================================================================
void drawFileBrowser(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,13,0,50,90);sendSetCursor(2,2);sendSetTextColor(255,255,255);
  String hdr=browserPath; if(utf8Len(hdr)>18) hdr=utf8Substr(hdr,utf8Len(hdr)-18,utf8Len(hdr));
  sendPrintStr(hdr);
  char cnt[8];snprintf(cnt,sizeof(cnt),"[%d]",(int)browserEntries.size());sendSetCursor(DISPLAY_WIDTH-strlen(cnt)*CHAR_W-3,2);sendSetTextColor(200,200,0);sendPrintText(cnt);

  int vis=6,yS=15,lh=17;
  if(browserEntries.empty()){
    sendSetCursor(15,55);sendSetTextColor(150,80,80);sendPrintText("(empty)");
  }
  for(int i=0;i<vis&&(browserScroll+i)<(int)browserEntries.size();i++){
    int fi=browserScroll+i,yP=yS+i*lh;
    const VfsEntry &e=browserEntries[fi];
    bool sel=(fi==browserSel);
    bool img=!e.isDir&&isImageFile(e.name), audio=!e.isDir&&isAudioFile(e.name), txt=!e.isDir&&isTextFile(e.name), java=!e.isDir&&isJavaAppFile(e.name);
    if(sel){sendFillRect(3,yP-1,DISPLAY_WIDTH-6,lh-2,0,70,30);sendDrawRect(3,yP-1,DISPLAY_WIDTH-6,lh-2,0,160,70);sendSetTextColor(0,255,160);}
    else if(e.isDir) sendSetTextColor(255,220,120);
    else if(img) sendSetTextColor(100,200,255);
    else if(audio) sendSetTextColor(180,255,180);
    else if(txt) sendSetTextColor(200,200,200);
    else if(java) sendSetTextColor(220,150,255);
    else sendSetTextColor(130,130,130);
    sendSetCursor(7,yP+3);
    const char* tag = e.isDir?"[D] ":(img?"[I] ":(audio?"[A] ":(txt?"[T] ":(java?"[J] ":"    "))));
    sendPrintText(tag);
    String dn=e.name;if(utf8Len(dn)>14)dn=utf8Substr(dn,0,11)+"...";sendPrintStr(dn);
    if(!e.isDir){String sz=formatSize(e.size);sendSetCursor(DISPLAY_WIDTH-sz.length()*CHAR_W-3,yP+3);if(!sel)sendSetTextColor(140,140,140);sendPrintStr(sz);}
  }
  sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,60);sendSetCursor(3,DISPLAY_HEIGHT-9);sendSetTextColor(120,120,120);sendPrintText("ENC=sel OK=open(hold=menu) H=back");
}

// ================================================================
//  WiFi-настройки (экран в Settings -> WiFi Connect)
//  Простой экран: поле SSID + поле Password, ввод через OSK-терминала.
// ================================================================
static int    s_wifiField = 0;   // 0 = SSID, 1 = Password
static String s_wifiSSID  = "";
static String s_wifiPass  = "";
static bool   s_wifiConnecting = false;
static String s_wifiMsg   = "";

void drawWifiSettings() {
  sendFillScreen(0, 0, 0);
  sendFillRect(0, 0, DISPLAY_WIDTH, 13, 0, 60, 90);
  sendSetCursor(30, 2); sendSetTextColor(255, 255, 255);
  sendPrintText("WiFi Connect");

  sendSetCursor(4, 18); sendSetTextColor(160, 160, 160); sendPrintText("SSID:");
  if(s_wifiField==0) sendFillRect(0,27,DISPLAY_WIDTH,12,0,16,64); else sendFillRect(0,27,DISPLAY_WIDTH,12,0,8,24);
  if (s_wifiField == 0) sendDrawRect(0, 27, DISPLAY_WIDTH, 12, 0, 140, 220);
  sendSetCursor(4, 29); sendSetTextColor(255, 255, 255);
  String shown = s_wifiSSID.length() <= 24 ? s_wifiSSID : s_wifiSSID.substring(s_wifiSSID.length() - 24);
  sendPrintStr(shown);

  sendSetCursor(4, 44); sendSetTextColor(160, 160, 160); sendPrintText("Pass:");
  if(s_wifiField==1) sendFillRect(0,53,DISPLAY_WIDTH,12,0,16,64); else sendFillRect(0,53,DISPLAY_WIDTH,12,0,8,24);
  if (s_wifiField == 1) sendDrawRect(0, 53, DISPLAY_WIDTH, 12, 0, 140, 220);
  sendSetCursor(4, 55); sendSetTextColor(255, 255, 255);
  String pshown = s_wifiPass.length() <= 24 ? s_wifiPass : s_wifiPass.substring(s_wifiPass.length() - 24);
  sendPrintStr(pshown);

  if (s_wifiMsg.length()) {
    sendSetCursor(4, 72); sendSetTextColor(255, 200, 80);
    sendPrintStr(s_wifiMsg.length() > 24 ? s_wifiMsg.substring(0, 24) : s_wifiMsg);
  }

  // pre-fill saved config
  if (s_wifiSSID.length() == 0) {
    String ss, sp;
    if (netLoadWifiConfig(ss, sp)) { s_wifiSSID = ss; s_wifiPass = sp; }
  }

  // OSK
  int oskY = 88;
  if (!oskTerminalIsVisible()) {
    sendFillRect(0, oskY, DISPLAY_WIDTH, DISPLAY_HEIGHT - oskY - 11, 5, 5, 16);
    sendSetCursor(4, oskY + 4); sendSetTextColor(140, 140, 140);
    sendPrintText("UD=field  OK=OSK  LR=conn/back");
  } else {
    // oskTerminalDraw() уже управляет своей областью
  }
  sendFillRect(0, DISPLAY_HEIGHT - 11, DISPLAY_WIDTH, 11, 0, 30, 50);
  sendSetCursor(3, DISPLAY_HEIGHT - 9); sendSetTextColor(110, 110, 110);
  sendPrintText("LR=Connect/Back OK=kbd");
}

void handleWifiSettings(int encDelta) {
  // OSK принимает символы
  if (oskTerminalIsVisible()) {
    oskTerminalProcess();
    if (oskTerminalHasChar()) {
      char c = oskTerminalGetChar();
      if (c == '\n' || c == '\r') { oskTerminalHide(); drawWifiSettings(); }
      else if (c == 0x08) { // backspace
        if (s_wifiField == 0 && s_wifiSSID.length()) s_wifiSSID.remove(s_wifiSSID.length()-1);
        else if (s_wifiField == 1 && s_wifiPass.length()) s_wifiPass.remove(s_wifiPass.length()-1);
        drawWifiSettings();
      } else if (c >= 0x20) {
        if (s_wifiField == 0) s_wifiSSID += c;
        else s_wifiPass += c;
        drawWifiSettings();
      }
    }
    return;
  }

  if (bUp.pressed() || bDown.pressed()) { s_wifiField ^= 1; drawWifiSettings(); }
  if (bOk.pressed()) { oskTerminalShow(); }
  if (bRight.pressed()) {
    if (s_wifiSSID.length() == 0) { s_wifiMsg = "Enter SSID first"; drawWifiSettings(); return; }
    s_wifiMsg = "Connecting...";
    drawWifiSettings();
    bool ok = netWifiConnect(s_wifiSSID, s_wifiPass);
    if (ok) {
      netSaveWifiConfig(s_wifiSSID, s_wifiPass);
      s_wifiMsg = "Connected!";
      netTimeSync(); // сразу синхронизируем время
    } else {
      s_wifiMsg = "Failed!";
    }
    drawWifiSettings();
  }
  if (bLeft.pressed() || bHome.pressed() || bCancel.pressed()) {
    oskTerminalHide();
    currentState = STATE_SETTINGS;
    drawSettings();
  }
}

// ================================================================
//  Статус-бар: часы + WiFi-бары (дёргается из drawMenu/drawHeader)
// ================================================================
void drawStatusBar() {
  // рисует в 0..HDR_H полосу с временем слева и WiFi-барами справа
  // Вызывай из drawMenu() / из любого экрана, где нужна шторка.
  String hhmm = netTimeHHMM();
  sendSetCursor(2, 2); sendSetTextColor(220, 220, 255);
  sendPrintStr(hhmm);

  int bars = netWifiBars();
  if (bars >= 0) {
    // рисуем 4 столбика разной высоты (каждый 3px шириной, расстояние 1px)
    for (int b = 0; b < 4; b++) {
      uint8_t r = (b < bars) ? 0 : 60;
      uint8_t g = (b < bars) ? 200 : 60;
      uint8_t bl = (b < bars) ? 80 : 60;
      int bh = 2 + b * 2;         // высота столбика: 2,4,6,8 px
      int bx = DISPLAY_WIDTH - 20 + b * 5;
      int by = HDR_H - 1 - bh;
      sendFillRect(bx, by, 4, bh, r, g, bl);
    }
  } else {
    sendSetCursor(DISPLAY_WIDTH - 16, 2);
    sendSetTextColor(100, 100, 100);
    sendPrintText("--");
  }
}

void drawSettings(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,13,0,60,80);sendSetCursor(45,2);sendSetTextColor(255,255,255);sendPrintText("SETTINGS");
  // пункты меню настроек (item 2 = WiFi, item 3 = Clock)
  const char* items[]={"Display Rotation","Audio Sample Rate","WiFi Connect","Clock / Timer","Format Internal","About"};
  const int NSETTINGS=6;
  for(int i=0;i<NSETTINGS;i++){
    int y=17+i*17;
    if(settingsChoice==i){sendFillRect(3,y-2,DISPLAY_WIDTH-6,15,0,60,80);sendDrawRect(3,y-2,DISPLAY_WIDTH-6,15,0,140,180);sendSetTextColor(0,220,255);}
    else sendSetTextColor(200,200,200);
    sendSetCursor(8,y+2);sendPrintText(items[i]);
    if(i==0){char rv[8];snprintf(rv,sizeof(rv),"%d",displayRotation==3?270:displayRotation*90);sendSetCursor(130,y+2);sendPrintText(rv);}
    else if(i==1){char sr[12];snprintf(sr,sizeof(sr),"%u Hz",audioSampleRate);sendSetCursor(115,y+2);sendPrintText(sr);}
    else if(i==2){bool wc;int wr;String wip;netWifiStatus(wc,wr,wip);sendSetCursor(120,y+2);if(wc){sendSetTextColor(0,220,80);sendPrintText("OK");}else{sendSetTextColor(120,120,120);sendPrintText("--");}}
  }
  sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,50);sendSetCursor(3,DISPLAY_HEIGHT-9);sendSetTextColor(120,120,120);sendPrintText("ENC/UD=sel  OK  H=back");
}

// ================================================================
//  CALCULATOR (original, unchanged)
// ================================================================
namespace OmniMath {
const char* expr; int pos; double result; bool error; char errMsg[32];
void setError(const char* msg){error=true;strncpy(errMsg,msg,31);errMsg[31]=0;}
void skipWs(){while(expr[pos]==' '||expr[pos]=='\t')pos++;}
double parseExpr();double parseTerm();double parsePower();double parseUnary();double parsePrimary();
double callFunc(const char* name,double arg){if(!strcmp(name,"sin"))return sin(arg);if(!strcmp(name,"cos"))return cos(arg);if(!strcmp(name,"tan"))return tan(arg);if(!strcmp(name,"asin"))return asin(arg);if(!strcmp(name,"acos"))return acos(arg);if(!strcmp(name,"atan"))return atan(arg);if(!strcmp(name,"sqrt"))return sqrt(arg);if(!strcmp(name,"log"))return log10(arg);if(!strcmp(name,"ln"))return log(arg);if(!strcmp(name,"exp"))return exp(arg);if(!strcmp(name,"abs"))return fabs(arg);if(!strcmp(name,"floor"))return floor(arg);if(!strcmp(name,"ceil"))return ceil(arg);if(!strcmp(name,"deg"))return arg*180.0/M_PI;if(!strcmp(name,"rad"))return arg*M_PI/180.0;setError("Unknown func");return 0;}
double parsePrimary(){if(error)return 0;skipWs();char c=expr[pos];if(isdigit(c)||c=='.'){char* end;double v=strtod(expr+pos,&end);pos=(int)(end-expr);return v;}if(c=='('){pos++;double v=parseExpr();skipWs();if(expr[pos]==')')pos++;else setError("Expected )");return v;}if(isalpha(c)){char id[16];int il=0;while(isalpha(expr[pos])&&il<15){id[il++]=tolower(expr[pos++]);}id[il]=0;skipWs();if(!strcmp(id,"pi"))return M_PI;if(!strcmp(id,"e"))return M_E;if(!strcmp(id,"inf"))return INFINITY;if(expr[pos]=='('){pos++;double arg=parseExpr();skipWs();if(expr[pos]==')')pos++;else setError("Expected )");return callFunc(id,arg);}setError("Expected (");return 0;}setError("Unexpected char");return 0;}
double parseUnary(){if(error)return 0;skipWs();if(expr[pos]=='-'){pos++;return -parseUnary();}if(expr[pos]=='+'){pos++;return parseUnary();}return parsePrimary();}
double parsePower(){double base=parseUnary();if(error)return 0;skipWs();if(expr[pos]=='^'){pos++;double e=parseUnary();return pow(base,e);}return base;}
double parseTerm(){double v=parsePower();if(error)return 0;while(true){skipWs();char c=expr[pos];if(c=='*'){pos++;v*=parsePower();}else if(c=='/'){pos++;double d=parsePower();if(fabs(d)<1e-300){setError("Div by zero");return 0;}v/=d;}else break;}return v;}
double parseExpr(){double v=parseTerm();if(error)return 0;while(true){skipWs();char c=expr[pos];if(c=='+'){pos++;v+=parseTerm();}else if(c=='-'){pos++;v-=parseTerm();}else break;}return v;}
double evaluate(const char* expression,bool& ok,char* errOut){expr=expression;pos=0;error=false;errMsg[0]=0;double v=parseExpr();skipWs();if(!error&&expr[pos]!='\0')setError("Trailing chars");ok=!error;if(!ok&&errOut)strncpy(errOut,errMsg,31);return v;}
}

#define CALC_EXPR_LEN 64
char calcExpr[CALC_EXPR_LEN+1]="";
char calcResult[32]="";
bool calcHasError=false;
int calcCursor=0;
struct Key{const char* label;const char* ins;};
const Key CALC_KEYS[5][6]={
  {{"7","7"},{"8","8"},{"9","9"},{"+","+"},{"(","("},{")",")"}},
  {{"4","4"},{"5","5"},{"6","6"},{"-","-"},{"^","^"},{"pi","pi"}},
  {{"1","1"},{"2","2"},{"3","3"},{"*","*"},{"sq","sqrt("},{"e","e"}},
  {{"0","0"},{".","."},{" ",""},{"/ ","/ "},{"ln","ln("},{"log","log("}},
  {{"sin","sin("},{"cos","cos("},{"tan","tan("},{"<","<"},{"C","C"},{"=","="}}
};
int calcRow=0,calcCol=0;
void formatResult(double v,char* buf,int sz){if(isnan(v)){strncpy(buf,"NaN",sz);return;}if(isinf(v)){strncpy(buf,v>0?"Inf":"-Inf",sz);return;}if(fabs(v)<1e10&&fabs(v-round(v))<1e-9)snprintf(buf,sz,"%.0f",v);else if(fabs(v)>=1e-4&&fabs(v)<1e8)snprintf(buf,sz,"%.6g",v);else snprintf(buf,sz,"%.4e",v);}
void calcEvaluate(){char errBuf[32]="";bool ok;double v=OmniMath::evaluate(calcExpr,ok,errBuf);if(ok){calcHasError=false;formatResult(v,calcResult,sizeof(calcResult));}else{calcHasError=true;strncpy(calcResult,errBuf,sizeof(calcResult)-1);}}
void drawCalculator(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,11,0,70,90);sendSetCursor(40,2);sendSetTextColor(255,255,255);sendPrintText("CALCULATOR");
  sendFillRect(0,12,DISPLAY_WIDTH,12,10,10,30);sendSetCursor(2,13);sendSetTextColor(200,230,255);int el=strlen(calcExpr),startC=max(0,el-(CHARS_PER_LINE-1));sendPrintText(calcExpr+startC);int cx=min(el-startC,CHARS_PER_LINE-1)*CHAR_W+2;sendSetCursor(cx,13);sendSetTextColor(255,255,0);sendPrintText("|");
  sendFillRect(0,25,DISPLAY_WIDTH,11,5,5,20);sendSetCursor(2,26);sendSetTextColor(calcHasError?255:0,calcHasError?80:255,calcHasError?80:150);sendPrintText("= ");sendPrintText(calcResult);
  int kx0=0,ky0=37,kw=26,kh=17;
  for(int r=0;r<5;r++){for(int c=0;c<6;c++){int kx=kx0+c*kw,ky=ky0+r*kh;bool sel=(r==calcRow&&c==calcCol);delay(4);if(sel){sendFillRect(kx,ky,kw-1,kh-1,0,120,60);sendDrawRect(kx,ky,kw-1,kh-1,0,220,120);sendSetTextColor(255,255,100);}else{sendFillRect(kx,ky,kw-1,kh-1,20,20,40);sendSetTextColor(200,200,200);}const char* lb=CALC_KEYS[r][c].label;int llen=strlen(lb);sendSetCursor(kx+(kw-1-llen*CHAR_W)/2,ky+(kh-1-CHAR_H_PX)/2);sendPrintText(lb);}}
  sendFillRect(0,DISPLAY_HEIGHT-10,DISPLAY_WIDTH,10,0,30,50);sendSetCursor(2,DISPLAY_HEIGHT-8);sendSetTextColor(110,110,110);sendPrintText("ENC=row  Arrows=nav  OK  H=back");
}
void calcPressKey(int r,int c){const char* ins=CALC_KEYS[r][c].ins;if(ins[0]=='<'){int el=strlen(calcExpr);if(el>0){int nb=1;while(el-nb>0&&(calcExpr[el-nb]&0xC0)==0x80)nb++;calcExpr[el-nb]=0;calcCursor=el-nb;}calcResult[0]=0;calcHasError=false;}else if(ins[0]=='C'&&ins[1]==0){calcExpr[0]=0;calcResult[0]=0;calcCursor=0;calcHasError=false;}else if(ins[0]=='='&&ins[1]==0){calcEvaluate();}else if(ins[0]==' '&&ins[1]==0){}else{int el=strlen(calcExpr),il=strlen(ins);if(el+il<CALC_EXPR_LEN)strcat(calcExpr,ins);}drawCalculator();}

// ================================================================
//  PLOTTER (original, unchanged)
// ================================================================
#define PLOT_FUNC_LEN 48
char plotFunc[PLOT_FUNC_LEN+1]="sin(x)";
double plotXMin=-6.28318,plotXMax=6.28318,plotYMin=-2.0,plotYMax=2.0;
bool plotAutoY=true;
int plotEditMode=0,plotViewMode=0;
#define PLOT_X0 20
#define PLOT_Y0 10
#define PLOT_W  (DISPLAY_WIDTH-PLOT_X0-2)
#define PLOT_H  (DISPLAY_HEIGHT-PLOT_Y0-22)
const char* VIEW_MODE_NAMES[]={"NORMAL","FILL","POINTS","STEP","GRID"};
const int VIEW_MODE_COUNT=5;
int plotMapX(double x){return PLOT_X0+(int)((x-plotXMin)/(plotXMax-plotXMin)*PLOT_W);}
int plotMapY(double y){return PLOT_Y0+PLOT_H-(int)((y-plotYMin)/(plotYMax-plotYMin)*PLOT_H);}
double getNiceStep(double range,int t){double rs=range/t,m=pow(10,floor(log10(rs))),r=rs/m;if(r<1.5)return m;if(r<3.5)return 2*m;if(r<7.5)return 5*m;return 10*m;}

void drawGrid(){double xStep=getNiceStep(plotXMax-plotXMin,6),yStep=getNiceStep(plotYMax-plotYMin,5);for(double y=ceil(plotYMin/yStep)*yStep;y<=plotYMax+yStep/2;y+=yStep){delay(2);int sy=plotMapY(y);if(sy>=PLOT_Y0&&sy<=PLOT_Y0+PLOT_H){sendDrawLine(PLOT_X0,sy,PLOT_X0+PLOT_W,sy,40,40,50);char yl[16];if(fabs(y)<0.0001)snprintf(yl,sizeof(yl),"0");else if(fabs(y)<10)snprintf(yl,sizeof(yl),"%.2f",y);else snprintf(yl,sizeof(yl),"%.1f",y);int ly=sy-CHAR_H_PX/2;if(ly>=PLOT_Y0&&ly<=PLOT_Y0+PLOT_H-CHAR_H_PX){sendFillRect(1,ly-1,30,CHAR_H_PX+2,0,0,0);sendSetCursor(2,ly);sendSetTextColor(100,200,150);sendPrintText(yl);}}}for(double x=ceil(plotXMin/xStep)*xStep;x<=plotXMax+xStep/2;x+=xStep){delay(2);int sx=plotMapX(x);if(sx>=PLOT_X0&&sx<=PLOT_X0+PLOT_W){if(plotViewMode!=4)sendDrawLine(sx,PLOT_Y0,sx,PLOT_Y0+PLOT_H,40,40,50);char xl[16];if(fabs(x)<0.0001)snprintf(xl,sizeof(xl),"0");else if(fabs(x)<10)snprintf(xl,sizeof(xl),"%.2f",x);else snprintf(xl,sizeof(xl),"%.1f",x);int lw=strlen(xl)*CHAR_W,lx=sx-lw/2,ly=PLOT_Y0+PLOT_H+2;if(lx<PLOT_X0)lx=PLOT_X0;if(lx+lw>DISPLAY_WIDTH)lx=DISPLAY_WIDTH-lw;if(ly+CHAR_H_PX<DISPLAY_HEIGHT-FTR_H){sendFillRect(lx-1,ly-1,lw+2,CHAR_H_PX+2,0,0,0);sendSetCursor(lx,ly);sendSetTextColor(150,180,220);sendPrintText(xl);}}}if(plotXMin<=0&&plotXMax>=0){int p=plotMapX(0);if(p>=PLOT_X0&&p<=PLOT_X0+PLOT_W)sendDrawLine(p,PLOT_Y0,p,PLOT_Y0+PLOT_H,150,200,100);}if(plotYMin<=0&&plotYMax>=0){int p=plotMapY(0);if(p>=PLOT_Y0&&p<=PLOT_Y0+PLOT_H)sendDrawLine(PLOT_X0,p,PLOT_X0+PLOT_W,p,150,200,100);}}

void plotEvalAutoY(){if(!plotAutoY)return;double ymin=1e300,ymax=-1e300;int valid=0;for(int px=0;px<PLOT_W;px++){double x=plotXMin+(double)px/PLOT_W*(plotXMax-plotXMin);char tmp[PLOT_FUNC_LEN*3+10]="";int ti=0;char xStr[20];snprintf(xStr,sizeof(xStr),"(%.8g)",x);for(int i=0;plotFunc[i];i++){if(plotFunc[i]=='x'&&(i==0||!isalpha(plotFunc[i-1]))&&!isalpha(plotFunc[i+1])){for(const char* p=xStr;*p&&ti<(int)sizeof(tmp)-2;p++)tmp[ti++]=*p;}else{if(ti<(int)sizeof(tmp)-2)tmp[ti++]=plotFunc[i];}}tmp[ti]=0;bool ok;char err[32];double y=OmniMath::evaluate(tmp,ok,err);if(ok&&!isnan(y)&&!isinf(y)){if(y<ymin)ymin=y;if(y>ymax)ymax=y;valid++;}}if(valid<2){ymin=-1;ymax=1;}else if(ymin>=ymax){ymin-=1;ymax+=1;}double m=(ymax-ymin)*0.1;if(m<0.001)m=0.5;plotYMin=ymin-m;plotYMax=ymax+m;}

void drawPlot(){
  sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,PLOT_Y0,0,60,80);sendSetCursor(2,1);sendSetTextColor(255,255,255);sendPrintText("y=");String fs=String(plotFunc);if(utf8Len(fs)>10)fs=utf8Substr(fs,0,8)+"...";sendPrintStr(fs);sendSetCursor(DISPLAY_WIDTH-48,1);sendSetTextColor(100,255,100);sendPrintText(VIEW_MODE_NAMES[plotViewMode]);
  if(plotViewMode==4)drawGrid();else{if(plotXMin<=0&&plotXMax>=0){int p=plotMapX(0);if(p>=PLOT_X0&&p<=PLOT_X0+PLOT_W)sendDrawLine(p,PLOT_Y0,p,PLOT_Y0+PLOT_H,100,150,100);}if(plotYMin<=0&&plotYMax>=0){int p=plotMapY(0);if(p>=PLOT_Y0&&p<=PLOT_Y0+PLOT_H)sendDrawLine(PLOT_X0,p,PLOT_X0+PLOT_W,p,100,150,100);}}
  sendDrawLine(PLOT_X0,PLOT_Y0,PLOT_X0,PLOT_Y0+PLOT_H,60,60,60);sendDrawLine(PLOT_X0,PLOT_Y0+PLOT_H,PLOT_X0+PLOT_W,PLOT_Y0+PLOT_H,60,60,60);
  if(plotViewMode!=4){sendSetTextColor(100,160,100);char yl[12];snprintf(yl,sizeof(yl),"%.2g",plotYMax);sendSetCursor(0,PLOT_Y0);sendPrintText(yl);snprintf(yl,sizeof(yl),"%.2g",plotYMin);sendSetCursor(0,PLOT_Y0+PLOT_H-CHAR_H_PX);sendPrintText(yl);snprintf(yl,sizeof(yl),"%.2g",plotXMin);sendSetCursor(PLOT_X0,PLOT_Y0+PLOT_H+2);sendPrintText(yl);snprintf(yl,sizeof(yl),"%.2g",plotXMax);sendSetCursor(DISPLAY_WIDTH-strlen(yl)*CHAR_W-2,PLOT_Y0+PLOT_H+2);sendPrintText(yl);}
  double pointsY[PLOT_W];bool pointsValid[PLOT_W];
  for(int px=0;px<PLOT_W;px++){double x=plotXMin+(double)px/PLOT_W*(plotXMax-plotXMin);char tmp[PLOT_FUNC_LEN*3+10]="";int ti=0;char xStr[20];snprintf(xStr,sizeof(xStr),"(%.8g)",x);for(int i=0;plotFunc[i];i++){if(plotFunc[i]=='x'&&(i==0||!isalpha(plotFunc[i-1]))&&!isalpha(plotFunc[i+1])){for(const char* p=xStr;*p&&ti<(int)sizeof(tmp)-2;p++)tmp[ti++]=*p;}else{if(ti<(int)sizeof(tmp)-2)tmp[ti++]=plotFunc[i];}}tmp[ti]=0;bool ok;char err[32];double y=OmniMath::evaluate(tmp,ok,err);pointsY[px]=y;pointsValid[px]=(ok&&!isnan(y)&&!isinf(y));}
  for(int px=0;px<PLOT_W-1;px++){delay(2);if(pointsValid[px]&&pointsValid[px+1]){bool y1ok=(pointsY[px]>=plotYMin&&pointsY[px]<=plotYMax),y2ok=(pointsY[px+1]>=plotYMin&&pointsY[px+1]<=plotYMax);if(y1ok&&y2ok)sendDrawLine(PLOT_X0+px,constrain(plotMapY(pointsY[px]),PLOT_Y0,PLOT_Y0+PLOT_H),PLOT_X0+px+1,constrain(plotMapY(pointsY[px+1]),PLOT_Y0,PLOT_Y0+PLOT_H),0,200,255);else if(y1ok)sendDrawPixel(PLOT_X0+px,constrain(plotMapY(pointsY[px]),PLOT_Y0,PLOT_Y0+PLOT_H),0,200,255);else if(y2ok)sendDrawPixel(PLOT_X0+px+1,constrain(plotMapY(pointsY[px+1]),PLOT_Y0,PLOT_Y0+PLOT_H),0,200,255);}else if(pointsValid[px]&&pointsY[px]>=plotYMin&&pointsY[px]<=plotYMax)sendDrawPixel(PLOT_X0+px,constrain(plotMapY(pointsY[px]),PLOT_Y0,PLOT_Y0+PLOT_H),0,200,255);}
  sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,50);sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(110,110,110);sendPrintText("ENC=panX  UD=zoomY  OK=edit  H=back");
}

void adjustYScale(double factor){double cy=(plotYMin+plotYMax)/2,ry=(plotYMax-plotYMin)*factor;plotYMin=cy-ry/2;plotYMax=cy+ry/2;plotAutoY=false;}
char plotEditChar='x';int plotEditPos=0;
const char EDIT_CHARS[]="xabcdefghijklmnopqrstuvwxyz0123456789+-*/^().sincotalgebqrd ";
const int  EDIT_CHARS_N=sizeof(EDIT_CHARS)-1;
int editCharIdx=0;
void drawPlotEdit(){sendFillScreen(0,0,0);sendFillRect(0,0,DISPLAY_WIDTH,12,0,70,80);sendSetCursor(30,2);sendSetTextColor(255,255,255);sendPrintText("EDIT FUNCTION");sendFillRect(0,14,DISPLAY_WIDTH,12,10,10,30);sendSetCursor(2,15);sendSetTextColor(200,230,255);sendPrintText("y=");sendPrintText(plotFunc);int cx=2+2*CHAR_W+plotEditPos*CHAR_W;sendSetCursor(cx,15);sendSetTextColor(255,255,0);sendPrintText("_");sendSetCursor(5,34);sendSetTextColor(150,150,150);sendPrintText("ENC or UP/DN=char");sendSetCursor(5,46);sendPrintText("LR=move  OK=confirm  C=del");char cur[3]={plotFunc[plotEditPos],' ',0};if(cur[0]==0)cur[0]='_';sendSetCursor(72,60);sendSetTextColor(0,255,200);sendPrintText(cur);char preview[16]="";int pi=0;for(int i=-1;i<=10&&pi<14;i++){int idx=(editCharIdx+i+EDIT_CHARS_N)%EDIT_CHARS_N;preview[pi++]=EDIT_CHARS[idx];}preview[pi]=0;sendSetCursor(5,90);sendSetTextColor(160,160,160);sendPrintText(preview);sendFillRect(0,DISPLAY_HEIGHT-11,DISPLAY_WIDTH,11,0,30,50);sendSetCursor(2,DISPLAY_HEIGHT-9);sendSetTextColor(110,110,110);sendPrintText("HOME=cancel edit");}

// ================================================================
//  REFRESH CURRENT SCREEN
// ================================================================
void refreshCurrentScreen() {
  switch (currentState) {
    case STATE_MENU: drawMenu(); break;
    case STATE_FILE_BROWSER: drawFileBrowser(); break;
    case STATE_FILE_VIEWER: drawFileViewer(); break;
    case STATE_MUSIC_PLAYER: drawMusicPlayer(); break;
    case STATE_IMAGE_VIEWER: drawImage(); break;
    case STATE_CALCULATOR: drawCalculator(); break;
    case STATE_PLOTTER: drawPlot(); break;
    case STATE_SETTINGS: drawSettings(); break;
    case STATE_TU_RUNNER: drawTuOutput(); break;
    case STATE_POWER_MENU: drawPowerMenu(); break;
    case STATE_JAVA_MENU: drawJavaMenu(); break;
    case STATE_JAVA_INSTALL: drawJavaInstall(); break;
    case STATE_JAVA_RUNNER: drawJavaRunner(); break;
    default: drawMenu(); break;
  }
}

// ================================================================
//  /bin launcher — bridges bin_vfs.h's file-based program registry
//  to the actual AppState screen switch. Registered once from
//  setup() via binVfsSetLauncher(appLaunchByName), so "run <name>"
//  in bash and "cat/ls /bin" (bin_vfs.cpp) never need to know what
//  an AppState even is.
// ================================================================
bool appLaunchByName(const String &name) {
  if (name == "explorer") {
    browserPath = "/"; browserSel = 0; refreshBrowser();
    currentState = STATE_FILE_BROWSER; drawFileBrowser();
    return true;
  }
  if (name == "terminal") {
    terminalInit();
    terminalOnEnter();
    currentState = STATE_TERMINAL;
    terminalDraw(DISPLAY_HEIGHT);
    return true;
  }
  if (name == "calc") {
    calcExpr[0] = 0; calcResult[0] = 0; calcRow = 2; calcCol = 0;
    currentState = STATE_CALCULATOR; drawCalculator();
    return true;
  }
  if (name == "plotter") {
    plotAutoY = true; plotEvalAutoY();
    currentState = STATE_PLOTTER; drawPlot();
    return true;
  }
  if (name == "settings") {
    settingsChoice = 0;
    currentState = STATE_SETTINGS; drawSettings();
    return true;
  }
  if (name == "clock") {
    clockInit();
    currentState = STATE_CLOCK;
    return true;
  }
  if (name == "player") {
    // Без указанного файла просто открывает экран плеера с тем, что
    // уже было загружено (или пусто) - выбрать трек можно из explorer.
    currentState = STATE_MUSIC_PLAYER; drawMusicPlayer();
    return true;
  }
  if (name == "doom") {
    sendFillScreen(0, 0, 0);
    sendSetCursor(20, 55);
    sendSetTextColor(255, 100, 0);
    sendPrintText("Loading DOOM...");
    delay(500);
    currentState = STATE_DOOM;
    return true;
  }
  // editor/imageview/tu на самом деле "аргументы" - нужен файл; без
  // него честнее открыть проводник, чтобы пользователь его выбрал,
  // чем притворяться, что программа запустилась без данных.
  if (name == "editor" || name == "imageview" || name == "tu") {
    browserPath = "/"; browserSel = 0; refreshBrowser();
    currentState = STATE_FILE_BROWSER; drawFileBrowser();
    return true;
  }
  if (name == "java") {
    openJavaMenu();
    return true;
  }
  return false;
}

// ================================================================
//  USB HOST (pio-usb) - MSC callbacks wire straight into the VFS
// ================================================================
extern "C" {
void tuh_msc_mount_cb(uint8_t dev_addr) {
  if(vfsExternalBegin(dev_addr)){SerialPC.print(F("USB drive mounted: "));SerialPC.print(vfsExternalPartitionCount());SerialPC.println(F(" partition(s) -> /sdb1.."));}else{SerialPC.println(F("USB drive: mount failed"));}
  if (currentState == STATE_FILE_BROWSER) refreshBrowser();
}
void tuh_msc_umount_cb(uint8_t dev_addr) {
  (void) dev_addr;
  vfsExternalEnd();
  SerialPC.println(F("USB drive removed."));
  if (currentState == STATE_FILE_BROWSER) refreshBrowser();
}
}  // extern "C"

// ================================================================
//  BOOT LOG (Linux-style лог инициализации вместо старой заставки)
// ================================================================


void bootRedraw() {
  sendFillScreen(0, 0, 0);
  int visible = DISPLAY_HEIGHT / LINE_H;
  int start = (int)bootLines.size() - visible;
  if (start < 0) start = 0;
  for (int i = 0; i < visible && (start + i) < (int)bootLines.size(); i++) {
    int idx = start + i;
    switch (bootColors[idx]) {
      case 1: sendSetTextColor(0, 220, 100); break;
      case 2: sendSetTextColor(255, 200, 0); break;
      case 3: sendSetTextColor(255, 70, 70); break;
      default: sendSetTextColor(200, 200, 200); break;
    }
    sendSetCursor(2, i * LINE_H);
    String ln = bootLines[idx];
    int maxCh = DISPLAY_WIDTH / CHAR_W;
    if ((int)ln.length() > maxCh) ln = ln.substring(0, maxCh);
    sendPrintStr(ln);
  }
}



// ================================================================
//  POWER MENU (HOME+CANCEL, работает поверх любого текущего экрана)
// ================================================================
AppState previousStateBeforePower = STATE_MENU;
int      powerMenuSel = 0;

void drawPowerMenu() {
  int mw = 110, mh = 70, mx = (DISPLAY_WIDTH - mw) / 2, my = (DISPLAY_HEIGHT - mh) / 2;
  sendFillRect(mx, my, mw, mh, 20, 20, 30);
  sendDrawRect(mx, my, mw, mh, 200, 60, 60);
  sendSetCursor(mx + 30, my + 4); sendSetTextColor(255, 180, 80); sendPrintText("POWER");
  const char* items[] = {"Power Off", "Reboot", "Cancel"};
  for (int i = 0; i < 3; i++) {
    int y = my + 20 + i * 15;
    if (powerMenuSel == i) { sendFillRect(mx + 4, y - 2, mw - 8, 13, 80, 20, 20); sendSetTextColor(255, 255, 150); }
    else sendSetTextColor(200, 200, 200);
    sendSetCursor(mx + (mw - (int)strlen(items[i]) * CHAR_W) / 2, y);
    sendPrintText(items[i]);
  }
  sendSetCursor(mx + 2, my + mh - 9); sendSetTextColor(140, 100, 100);
  sendPrintText("UD=sel OK=go");
}

void doPowerOff() {
  sendFillScreen(0, 0, 0);
  sendSetCursor(14, 55); sendSetTextColor(255, 90, 90); sendPrintText("Shutting down...");
  delay(500);
  sendFillScreen(0, 0, 0);
  digitalWrite(DISPLAY_LED_PIN, LOW); // гасим подсветку
  // POWER_PIN был установлен в 0 при старте (см. setup()) - переключаем в
  // противоположный уровень, чтобы разорвать самоблокировку питания. Если
  // в твоей схеме защёлка работает наоборот - поменяй местами 0/1 здесь.
  digitalWrite(POWER_PIN, 0);
  while (true) { delay(1000); } // если внешней схемы отключения питания нет - просто остаёмся с выключенным экраном
}

void doReboot() {
  sendFillScreen(0, 0, 0);
  sendSetCursor(20, 55); sendSetTextColor(255, 255, 80); sendPrintText("Rebooting...");
  delay(400);
  watchdog_reboot(0, 0, 10);
  while (true) {}
}

void handlePowerMenu(int encDelta) {
  bool changed = false;
  if (bUp.pressed() || bUp.repeat())   { if (powerMenuSel > 0) { powerMenuSel--; changed = true; } }
  if (bDown.pressed() || bDown.repeat()) { if (powerMenuSel < 2) { powerMenuSel++; changed = true; } }
  if (encDelta != 0) { powerMenuSel = constrain(powerMenuSel + (encDelta > 0 ? 1 : -1), 0, 2); changed = true; }
  if (changed) drawPowerMenu();

  if (bOk.pressed() || bEncBtn.pressed()) {
    if (powerMenuSel == 0) doPowerOff();
    else if (powerMenuSel == 1) doReboot();
    else { currentState = previousStateBeforePower; refreshCurrentScreen(); }
  }
  // одиночное нажатие Cancel или Home (без второй зажатой кнопки) тоже закрывает меню
  if ((bCancel.pressed() && !bHome.state) || (bHome.pressed() && !bCancel.state)) {
    currentState = previousStateBeforePower;
    refreshCurrentScreen();
  }
}

// ================================================================
//  SETUP
// ================================================================
void setup() {
  pinMode(POWER_PIN, OUTPUT);
  digitalWrite(POWER_PIN, 1);

  // --- Последовательные порты ---
  SerialPC.begin(115200);
  SerialESP.setTX(UART_TX_PIN);
  SerialESP.setRX(UART_RX_PIN);
  SerialESP.begin(UART_BAUD);

  // --- Сброс и инициализация дисплея (нужен ПЕРВЫМ - на нём весь boot-лог) ---
  delay(500);
  sendReset();
  delay(1000);
  sendSetRotation(displayRotation);
  sendFillScreen(0, 0, 0);

  bootLog("init display OK", 1, 150);
  bootLog("start Parus OS 1.2", 0, 150);
  bootLog("Bash 0.0.3", 0, 150);
  bootLog("Turbine 0.0.1", 0, 250);

  // --- Подсветка дисплея ---
  pinMode(DISPLAY_LED_PIN, OUTPUT);
  digitalWrite(DISPLAY_LED_PIN, 1); // полная яркость по умолчанию, до загрузки сохранённой настройки
  bootStep("Display backlight", true);

  // --- Кнопки и энкодер ---
  initButtons();
  bootStep("Init buttons", true);
  initEncoder();
  bootStep("Init encoder", true);

  // --- Файловая система (внутренняя сразу, внешняя - когда подключат флешку) ---
  vfsBegin();
  bootStep("Mount /sda (LittleFS)", true);
  mountInit();
  bootStep("Init mount table", true);
  initLittleFS();
  bootStep("Init filesystem", true);
  loadSettings(); // применит в т.ч. сохранённую яркость/поворот/sample rate
  bootStep("Load settings", true);

  // --- Меню самопроверки: если при старте зажат HOME, показываем выбор
  //     "Bash self-test" / "Turbine self-test" / "Skip" ---
  updateButtons();
  if (bHome.state) {
    runSelfTestChooser();
  }

  // --- Аудио: PWM-выход, аппаратный sample-clock (ISR) и FreeRTOS
  //     задача-продюсер (декодирует WAV/MP3 в кольцевой буфер) ---
  audioInit();
  bootStep("Init audio engine", true);
  setSpeed(audioSpeed);

  // --- USB-host для внешней флешки ---
  // pio-usb требует тактовую частоту 120 или 240 МГц (Tools > CPU Speed).
  {
    uint32_t cpu_hz = clock_get_hz(clk_sys);
    bool cpuOk = (cpu_hz == 120000000UL || cpu_hz == 240000000UL);
    if (!cpuOk) {
      char buf[64];
      snprintf(buf, sizeof(buf), "CPU clock %u Hz (need 120/240 MHz)", (unsigned)cpu_hz);
      bootWarn(buf, 250);
      SerialPC.printf("WARNING: CPU clock is %u Hz - set Tools > CPU Speed to 120 or 240 MHz for the USB flash drive to work!\n", (unsigned)cpu_hz);
    } else {
      bootStep("CPU clock OK (" + String(cpu_hz / 1000000) + " MHz)", true);
    }
  }
  // Аудио теперь не занимает core1 целиком (ISR + FreeRTOS-задача вместо
  // блокирующего loop1()), так что USB-host обслуживается из обычного
  // loop() на core0, как и раньше.
  {
    pio_usb_configuration_t pio_cfg = PIO_USB_DEFAULT_CONFIG;
    pio_cfg.pin_dp = USB_HOST_DP_PIN;
    USBHost.configure_pio_usb(1, &pio_cfg);
    USBHost.begin(1);
  }
  bootStep("USB host (pio-usb)", true);

  // --- Файловый браузер стартует в корне VFS ---
  browserPath = "/";
  refreshBrowser();
  bootStep("File browser ready", true);

  gpioManager.begin();
  bootStep("Init GPIO manager", true);
  devicesVfsInit();
  bootStep("Init devices VFS", true);
  inputVfsInit();
  bootStep("Init /dev/input (buttons, keyboard)", true);
  procVfsInit();
  bootStep("Init /proc (mounts, audio)", true);
  libVfsInit();
  bootStep("Init /lib", true);
  binVfsInit();
  binVfsSetLauncher(appLaunchByName);
  bootStep("Init /bin", true);

  jvmEngineInit();
  bootStep("Init JavaME engine", true);

  // ---- автоподключение WiFi по сохранённым данным ----
  netInit();
  if (netAutoConnect()) {
    bootStep("WiFi connected", true);
    if (netTimeSync()) bootStep("Time sync (NTP)", true);
    else bootWarn("Time sync failed");
  } else {
    bootLog("[ -- ] WiFi: not configured", 0, 150);
  }

  SerialPC.println("RP2040 Ready - dual storage (/sda + /sdb1..)");
  bootLog("Boot complete", 1, 400);

  // --- Главное меню ---
  drawMenu();
  currentState = STATE_MENU;
}

// ================================================================
//  LOOP
// ================================================================
// ================================================================
//  LOOP
// ================================================================
// ================================================================
//  LOOP
// ================================================================
void loop() {
  // ---- фоновые задачи: WiFi-статус и проверка будильника ----
  netPoll();        // не блокирует, реальный запрос не чаще раза в 5с
  clockTickAlarm(); // проверка будильника/таймера (1 раз/сек внутри)

  // Keep servicing the USB host stack every iteration (core1 is dedicated
  // to audio sample timing, so this can't live there).
  USBHost.task();

  // ----------------------------------------------------------------
  // Обработка конца трека
  // ----------------------------------------------------------------
  if (trackEndedSignal) {
    trackEndedSignal = false;
    if (autoPlayNext) playNextTrack();
    else if (currentState == STATE_MUSIC_PLAYER) drawMusicPlayer();
  }

  // ----------------------------------------------------------------
  // Окно статуса (OK+HOME)
  // ----------------------------------------------------------------
  if (currentState == STATE_STATUS_OVERLAY) {
    if (millis() - statusWindowStart > STATUS_WINDOW_DURATION) {
      currentState = previousState;
      refreshCurrentScreen();
    } else if (bOk.pressed() || bHome.pressed() || bCancel.pressed() || bEncBtn.pressed()) {
      currentState = previousState;
      refreshCurrentScreen();
    }
    updateButtons();
    delay(20);
    return;
  }

  // ----------------------------------------------------------------
  // Меню питания (HOME+CANCEL) - активный режим. Работает поверх
  // ЛЮБОГО текущего экрана/состояния, см. комбо-детектор чуть ниже.
  // ----------------------------------------------------------------
  if (currentState == STATE_POWER_MENU) {
    updateButtons();
    int pEnc = readEncoderDelta();
    handlePowerMenu(pEnc);
    delay(20);
    return;
  }

  // ----------------------------------------------------------------
  // Запоминаем предыдущее состояние для STATUS_OVERLAY
  // ----------------------------------------------------------------
  if (bOk.state && bHome.state && currentState != STATE_STATUS_OVERLAY) {
    previousState = currentState;
    currentState = STATE_STATUS_OVERLAY;
    statusWindowStart = millis();
    drawStatusOverlay();
    delay(50);
    return;
  }

  // ----------------------------------------------------------------
  // Меню питания: детектор удержания HOME+CANCEL вместе (~0.5с).
  // Проверяется на каждой итерации loop(), т.е. срабатывает независимо
  // от того, какой экран сейчас активен (терминал, плеер, часы и т.д.)
  // ----------------------------------------------------------------
  {
    static unsigned long powerComboStart = 0;
    static bool powerComboArmed = false;
    if (bHome.state && bCancel.state) {
      if (!powerComboArmed) { powerComboStart = millis(); powerComboArmed = true; }
      else if (millis() - powerComboStart > 500 && currentState != STATE_POWER_MENU) {
        previousStateBeforePower = currentState;
        currentState = STATE_POWER_MENU;
        powerMenuSel = 0;
        drawPowerMenu();
        powerComboArmed = false;
        delay(50);
        return;
      }
    } else {
      powerComboArmed = false;
    }
  }

  // ----------------------------------------------------------------
  // Обновление прогресс-бара музыки + серийные команды (PC <-> VFS)
  // ----------------------------------------------------------------
  updateProgressBar();
  handleSerialCommands();

  // ----------------------------------------------------------------
  // Чтение кнопок и энкодера
  // ----------------------------------------------------------------
  static unsigned long lastLoop = 0;
  unsigned long now = millis();
  if (now - lastLoop < 20) return;
  lastLoop = now;

  updateButtons();
  int encDelta = readEncoderDelta();
  bool encClicked = bEncBtn.pressed();

  // ----------------------------------------------------------------
  //  STATE_DOOM - обрабатываем ДО всех остальных состояний
  // ----------------------------------------------------------------
  if (currentState == STATE_DOOM) {
    // Doom запускается блокирующе, но мы проверяем кнопки до вызова
    updateButtons();
    
    // Если HOME или CANCEL нажаты до старта - выходим
    if (bHome.pressed() || bCancel.pressed()) {
      currentState = STATE_MENU;
      drawMenu();
      return;
    }
    
    // Запускаем Doom (блокирующий цикл)
    // Внутри runDoom() есть свой цикл с проверкой кнопок
    // runDoom();
    
    // После выхода из Doom - возвращаемся в меню
    currentState = STATE_MENU;
    drawMenu();
    return;
  }

  // ----------------------------------------------------------------
  //  STATE_MENU
  // ----------------------------------------------------------------
  if (currentState == STATE_MENU) {
    bool changed = false;
    if (bUp.pressed() || bUp.repeat()) {
      if (selectedMenu > 0) { selectedMenu--; if (selectedMenu < menuScrollOffset) menuScrollOffset = selectedMenu; changed = true; }
    }
    if (bDown.pressed() || bDown.repeat()) {
      if (selectedMenu < MENU_ITEMS_COUNT - 1) { selectedMenu++; if (selectedMenu >= menuScrollOffset + MENU_VISIBLE) menuScrollOffset = selectedMenu - MENU_VISIBLE + 1; changed = true; }
    }
    if (encDelta != 0) {
      selectedMenu = constrain(selectedMenu + (encDelta > 0 ? 1 : -1), 0, MENU_ITEMS_COUNT - 1);
      if (selectedMenu < menuScrollOffset) menuScrollOffset = selectedMenu;
      if (selectedMenu >= menuScrollOffset + MENU_VISIBLE) menuScrollOffset = selectedMenu - MENU_VISIBLE + 1;
      changed = true;
    }
    if (changed) drawMenu();

    if (bOk.pressed() || encClicked) {
      if (selectedMenu == 0 || selectedMenu == 1) {
        browserPath = "/"; browserSel = 0; refreshBrowser();
        currentState = STATE_FILE_BROWSER; drawFileBrowser();
      }
      else if (selectedMenu == 2) { calcExpr[0] = 0; calcResult[0] = 0; calcRow = 2; calcCol = 0; currentState = STATE_CALCULATOR; drawCalculator(); }
      else if (selectedMenu == 3) { plotAutoY = true; plotEvalAutoY(); currentState = STATE_PLOTTER; drawPlot(); }
      else if (selectedMenu == 4) { settingsChoice = 0; currentState = STATE_SETTINGS; drawSettings(); }
      else if (selectedMenu == 5) { // Terminal
        terminalInit();
        terminalOnEnter();
        currentState = STATE_TERMINAL;
        terminalDraw(DISPLAY_HEIGHT);
      }
      else if (selectedMenu == 6) { // Java
        openJavaMenu();
      }
    }
  }

  // ----------------------------------------------------------------
  //  STATE_FILE_BROWSER (generic dual-storage explorer)
  // ----------------------------------------------------------------
  else if (currentState == STATE_FILE_BROWSER) {
    int n = (int)browserEntries.size();

    if (bUp.pressed() || bUp.repeat()) {
      if (browserSel > 0) { browserSel--; if (browserSel < browserScroll) browserScroll = browserSel; drawFileBrowser(); }
    }
    if (bDown.pressed() || bDown.repeat()) {
      if (browserSel < n - 1) { browserSel++; if (browserSel >= browserScroll + BROWSER_VISIBLE) browserScroll = browserSel - BROWSER_VISIBLE + 1; drawFileBrowser(); }
    }
    if (encDelta != 0 && n > 0) {
      browserSel = constrain(browserSel + (encDelta > 0 ? 1 : -1), 0, n - 1);
      if (browserSel < browserScroll) browserScroll = browserSel;
      if (browserSel >= browserScroll + BROWSER_VISIBLE) browserScroll = browserSel - BROWSER_VISIBLE + 1;
      drawFileBrowser();
    }

    auto openSelected = [&]() {
      if (n == 0) return;
      VfsEntry e = browserEntries[browserSel];
      String fullPath = (browserPath == "/") ? ("/" + e.name) : vfsJoin(browserPath, e.name);

      if (e.isDir) {
        browserEnter(e.name);
        drawFileBrowser();
      } else if (isImageFile(e.name)) {
        sendFillScreen(0, 0, 0); sendSetCursor(20, 60);
        sendSetTextColor(200, 200, 0); sendPrintText("Loading image...");
        if (openImage(fullPath)) { currentState = STATE_IMAGE_VIEWER; drawImage(); }
        else drawFileBrowser();
      } else if (isTextFile(e.name)) {
        currentFilePath = fullPath;
        if (loadFileLines(currentFilePath)) { textScrollLine = 0; textScrollCol = 0; currentState = STATE_FILE_VIEWER; drawFileViewer(); }
        else drawFileBrowser();
      } else if (isAudioFile(e.name)) {
        buildPlaylistFromDir(browserPath);
        selectedMusic = 0;
        for (size_t i = 0; i < musicPlaylist.size(); i++) if (musicPlaylist[i] == e.name) { selectedMusic = (int)i; break; }
        musicScrollOffset = max(0, selectedMusic - 1);
        startMusic(fullPath);
        currentState = STATE_MUSIC_PLAYER; drawMusicPlayer();
      } else if (isTuFile(e.name)) {
        currentState = STATE_TU_RUNNER;
        runTuFile(fullPath);
      } else if (isJavaAppFile(e.name)) {
        openJavaInstall(fullPath);
      } else {
        sendFillScreen(0, 0, 0); sendSetCursor(10, 55);
        sendSetTextColor(255, 120, 0); sendPrintText("Unsupported file type");
        delay(1200);
        drawFileBrowser();
      }
    };

    static unsigned long okPressStart = 0;
    static bool longPressTriggered = false;
    if (bOk.pressed() && n > 0) { okPressStart = millis(); longPressTriggered = false; }
    if (bOk.held(LONG_PRESS_MS) && !longPressTriggered && n > 0) {
      longPressTriggered = true;
      fbMenuSelected = 0;
      currentState = STATE_FILE_BROWSER_MENU;
      drawFileBrowserMenu();
    }
    if (bOk.released() && !longPressTriggered && n > 0) {
      if (millis() - okPressStart < LONG_PRESS_MS) openSelected();
    }
    if ((bRight.pressed()) && n > 0) openSelected();
    if (encClicked && n > 0) openSelected();

    if (bLeft.pressed() || bCancel.pressed()) {
      if (browserPath != "/") { browserGoUp(); drawFileBrowser(); }
      else { currentState = STATE_MENU; drawMenu(); }
    }
    if (bHome.pressed()) { currentState = STATE_MENU; drawMenu(); }
  }

  // ----------------------------------------------------------------
  //  STATE_IMAGE_VIEWER
  // ----------------------------------------------------------------
  else if (currentState == STATE_IMAGE_VIEWER) {
    bool needRedraw = false;
    int32_t realW = isPng ? (int32_t)pngWidth : imgWidth;
    int32_t realH = isPng ? (int32_t)pngHeight : ((imgHeight < 0) ? -imgHeight : imgHeight);
    if (realW <= 0 || realH <= 0) { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }

    if (bLeft.pressed() || bLeft.repeat()) { imgOffsetX -= IMG_PAN_STEP; needRedraw = true; }
    if (bRight.pressed() || bRight.repeat()) { imgOffsetX += IMG_PAN_STEP; needRedraw = true; }
    if (bUp.pressed() || bUp.repeat()) { imgOffsetY -= IMG_PAN_STEP; needRedraw = true; }
    if (bDown.pressed() || bDown.repeat()) { imgOffsetY += IMG_PAN_STEP; needRedraw = true; }
    if (encDelta != 0) { imgOffsetY += encDelta * IMG_PAN_STEP; needRedraw = true; }

    if (bOk.held(0)) {
      if (bUp.pressed() || bUp.repeat()) { if (imgZoom < MAX_ZOOM) { imgZoom += ZOOM_STEP; if (imgZoom > MAX_ZOOM) imgZoom = MAX_ZOOM; needRedraw = true; } }
      if (bDown.pressed() || bDown.repeat()) { if (imgZoom > MIN_ZOOM) { imgZoom -= ZOOM_STEP; if (imgZoom < MIN_ZOOM) imgZoom = MIN_ZOOM; needRedraw = true; } }
      int step = max(1, (int)(4 / imgZoom));
      if (bLeft.pressed() || bLeft.repeat()) { imgOffsetX -= step; needRedraw = true; }
      if (bRight.pressed() || bRight.repeat()) { imgOffsetX += step; needRedraw = true; }
    }
    if (bOk.pressed() && !bOk.held(0)) { imgOffsetX = 0; imgOffsetY = 0; needRedraw = true; }

    if (needRedraw) {
      int32_t maxX = max(0, (int32_t)(realW - DISPLAY_WIDTH / imgZoom));
      int32_t maxY = max(0, (int32_t)(realH - DISPLAY_HEIGHT / imgZoom));
      if (imgOffsetX < 0) imgOffsetX = 0; if (imgOffsetX > maxX) imgOffsetX = maxX;
      if (imgOffsetY < 0) imgOffsetY = 0; if (imgOffsetY > maxY) imgOffsetY = maxY;
      drawImage();
    }
    if (bHome.pressed() || bCancel.pressed()) { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
  }

  // ----------------------------------------------------------------
  //  STATE_FILE_VIEWER
  // ----------------------------------------------------------------
  else if (currentState == STATE_FILE_VIEWER) {
    bool redraw = false;
    if (bUp.pressed() || bUp.repeat()) { if (textScrollLine > 0) { textScrollLine--; redraw = true; } }
    if (bDown.pressed() || bDown.repeat()) { if (textScrollLine < totalLines - 1) { textScrollLine++; redraw = true; } }
    if (encDelta != 0) { textScrollLine = constrain(textScrollLine + encDelta, 0, totalLines - 1); redraw = true; }
    if (bRight.pressed() || bRight.repeat()) { int mc = maxScrollCol(); if (textScrollCol < mc) { textScrollCol++; redraw = true; } }
    if (bLeft.pressed() || bLeft.repeat()) { if (textScrollCol > 0) { textScrollCol--; redraw = true; } }
    if (redraw) drawFileViewer();

    if (encClicked || bOk.released()) {
      unsigned long held = millis() - bOk.pressedAt;
      if (encClicked || (held >= LONG_PRESS_MS && headingCount > 0)) {
        hmSelected = 0; hmScroll = 0;
        currentState = STATE_HEADING_MENU;
        drawHeadingMenu();
      }
    }
    if (bCancel.pressed()) {
      if (headingCount > 0) {
        for (int i = headingCount - 1; i >= 0; i--) {
          if (headingLines[i] < textScrollLine) { textScrollLine = headingLines[i]; textScrollCol = 0; drawFileViewer(); break; }
        }
      }
    }
    if (bHome.pressed()) { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
  }

  // ----------------------------------------------------------------
  //  STATE_MUSIC_PLAYER (plays the folder you navigated to)
  // ----------------------------------------------------------------
  else if (currentState == STATE_MUSIC_PLAYER) {
    int n = (int)musicPlaylist.size();
    if (encDelta != 0 && n > 0) {
      int newSel = constrain(selectedMusic + (encDelta > 0 ? 1 : -1), 0, n - 1);
      if (newSel != selectedMusic) {
        selectedMusic = newSel;
        if (selectedMusic < musicScrollOffset) musicScrollOffset = selectedMusic;
        if (selectedMusic >= musicScrollOffset + 4) musicScrollOffset = selectedMusic - 3;
        drawMusicPlayer();
      }
    }
    if (bUp.pressed() || bUp.repeat()) {
      if (!bOk.held(0) && n > 0 && selectedMusic > 0) { selectedMusic--; if (selectedMusic < musicScrollOffset) musicScrollOffset = selectedMusic; drawMusicPlayer(); }
    }
    if (bDown.pressed() || bDown.repeat()) {
      if (!bOk.held(0) && n > 0 && selectedMusic < n - 1) { selectedMusic++; if (selectedMusic >= musicScrollOffset + 4) musicScrollOffset = selectedMusic - 3; drawMusicPlayer(); }
    }
    if (!bOk.held(0)) {
      if (bLeft.pressed() || bLeft.repeat()) { volumeDown(); drawMusicPlayer(); }
      if (bRight.pressed() || bRight.repeat()) { volumeUp(); drawMusicPlayer(); }
    }
    static unsigned long lastSeekTime = 0;
    if (bOk.held(0)) {
      if (bUp.pressed() || (bUp.repeat() && millis() - lastSeekTime > 150)) { speedUp(); drawMusicPlayer(); lastSeekTime = millis(); }
      if (bDown.pressed() || (bDown.repeat() && millis() - lastSeekTime > 150)) { speedDown(); drawMusicPlayer(); lastSeekTime = millis(); }
    }
    static unsigned long okPressTime = 0;
    static bool okWasPressed = false;
    if (bOk.pressed()) { okPressTime = millis(); okWasPressed = true; }
    if (bOk.released() && okWasPressed) {
      if (millis() - okPressTime < LONG_PRESS_MS) {
        if (musicPlaying) { if (musicPaused) resumeMusic(); else pauseMusic(); drawMusicPlayer(); }
        else if (n > 0) { if (startMusic(vfsJoin(musicDirPath, musicPlaylist[selectedMusic]))) drawMusicPlayer(); }
      }
      okWasPressed = false;
    }
    if (encClicked) {
      if (musicPlaying) { if (musicPaused) resumeMusic(); else pauseMusic(); drawMusicPlayer(); }
      else if (n > 0) { if (startMusic(vfsJoin(musicDirPath, musicPlaylist[selectedMusic]))) drawMusicPlayer(); }
    }
    if (bCancel.pressed()) { if (musicPlaying) { stopMusic(); drawMusicPlayer(); } }
    if (bHome.pressed()) {
      stopMusic();
      browserPath = musicDirPath.length() ? musicDirPath : "/";
      refreshBrowser();
      currentState = STATE_FILE_BROWSER;
      drawFileBrowser();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_TERMINAL
  // ----------------------------------------------------------------
  else if (currentState == STATE_TERMINAL) {
    // Проверяем, не хочет ли терминал открыть редактор
    String editorPath;
    if (terminalWantsEditor(editorPath)) {
      editorOpen(editorPath);
      currentState = STATE_EDITOR;
      editorDraw(DISPLAY_HEIGHT);
      return;
    }
    
    // Проверяем, не хочет ли терминал выйти
    if (terminalWantsExit()) {
      currentState = STATE_MENU;
      drawMenu();
      return;
    }
    
    bool redraw = false;
    
    // --- Экранная клавиатура ---
    static unsigned long oskPressStart = 0;
    static bool oskLongPressTriggered = false;
    
    if (bOk.pressed()) {
      oskPressStart = millis();
      oskLongPressTriggered = false;
    }
    
    // Долгое нажатие OK = показать/скрыть клавиатуру
    if (bOk.held(600) && !oskLongPressTriggered && currentState == STATE_TERMINAL) {
      oskLongPressTriggered = true;
      terminalToggleOsk();
      if (oskTerminalIsVisible()) {
        oskTerminalDraw();
        redraw = true;
      }
    }
    
    // Короткое нажатие OK - Enter (только если клавиатура не активна)
    if (bOk.released() && !oskLongPressTriggered && !oskTerminalIsVisible()) {
      terminalFeedChar('\n');
      redraw = true;
    }
    
    // Обработка экранной клавиатуры
    if (oskTerminalIsVisible()) {
      oskTerminalProcess();
      
      // Проверяем, есть ли символ от OSK
      if (oskTerminalHasChar()) {
        char ch = oskTerminalGetChar();
        SerialPC.print("Got char from OSK: ");
        SerialPC.println(ch);
        
        if (ch == 0x08) { // Backspace
          terminalFeedChar('\b');
          redraw = true;
        } else if (ch == '\n') {
          terminalFeedChar('\n');
          redraw = true;
        } else if (ch == ' ') {
          terminalFeedChar(' ');
          redraw = true;
        } else if (ch == 0x01) { // Up
          terminalHistoryUp();
          redraw = true;
        } else if (ch == 0x02) { // Down
          terminalHistoryDown();
          redraw = true;
        } else if (ch == 0x03) { // Left
          terminalMoveCursor(-1);
          redraw = true;
        } else if (ch == 0x04) { // Right
          terminalMoveCursor(1);
          redraw = true;
        } else if (ch == 0x05) { // Home
          terminalMoveCursor(-999);
          redraw = true;
        } else if (ch == 0x06) { // End
          terminalMoveCursor(999);
          redraw = true;
        } else if (ch == 0x0C) { // Clear
          terminalClear();
          redraw = true;
        } else if (ch == 0x1B) { // Escape
          currentState = STATE_MENU;
          drawMenu();
          return;
        } else if (ch >= 32 && ch <= 126) { // Печатные символы
          terminalFeedChar(ch);
          redraw = true;
        }
      }
    }
    
    // Обработка энкодера (только если клавиатура не активна)
    if (!oskTerminalIsVisible()) {
      if (encDelta != 0) {
        terminalMoveCursor(encDelta);
        redraw = true;
      }
      
      if (bLeft.pressed()) { terminalMoveCursor(-1); redraw = true; }
      if (bRight.pressed()) { terminalMoveCursor(1); redraw = true; }
      if (bUp.pressed()) { terminalHistoryUp(); redraw = true; }
      if (bDown.pressed()) { terminalHistoryDown(); redraw = true; }
    }
    
    // Ввод с USB-клавиатуры
    HidKeyEvent ev;
    while (hidKeyboardPopEvent(ev)) {
      if (ev.kind == HK_CHAR) {
        terminalFeedChar(ev.ch);
        redraw = true;
      } else if (ev.kind == HK_ENTER) {
        terminalFeedChar('\n');
        redraw = true;
      } else if (ev.kind == HK_BACKSPACE) {
        terminalFeedChar('\b');
        redraw = true;
      } else if (ev.kind == HK_UP) {
        terminalHistoryUp();
        redraw = true;
      } else if (ev.kind == HK_DOWN) {
        terminalHistoryDown();
        redraw = true;
      } else if (ev.kind == HK_LEFT) {
        terminalMoveCursor(-1);
        redraw = true;
      } else if (ev.kind == HK_RIGHT) {
        terminalMoveCursor(1);
        redraw = true;
      } else if (ev.kind == HK_ESC) {
        currentState = STATE_MENU;
        drawMenu();
        return;
      }
    }
    
    // Физические кнопки (когда клавиатура не активна)
    if (!oskTerminalIsVisible()) {
      if (bCancel.pressed()) {
        terminalFeedChar('\b');
        redraw = true;
      }
    }
    
    // HOME - выход или скрыть клавиатуру
    if (bHome.pressed()) {
      if (oskTerminalIsVisible()) {
        terminalToggleOsk();
        redraw = true;
      } else {
        currentState = STATE_MENU;
        drawMenu();
        return;
      }
    }
    
    if (redraw) {
      terminalDraw(DISPLAY_HEIGHT);
      if (oskTerminalIsVisible()) {
        oskTerminalDraw();
      }
    }
  }

  // ----------------------------------------------------------------
  //  STATE_EDITOR
  // ----------------------------------------------------------------
  else if (currentState == STATE_EDITOR) {
    bool redraw = false;
    
    // Ввод с USB-клавиатуры
    HidKeyEvent ev;
    while (hidKeyboardPopEvent(ev)) {
      if (ev.kind == HK_CHAR) {
        editorFeedChar(ev.ch);
        redraw = true;
      } else if (ev.kind == HK_ENTER) {
        editorFeedChar('\n');
        redraw = true;
      } else if (ev.kind == HK_BACKSPACE) {
        editorFeedChar('\b');
        redraw = true;
      } else if (ev.kind == HK_UP) {
        editorMoveCursor(0, -1);
        redraw = true;
      } else if (ev.kind == HK_DOWN) {
        editorMoveCursor(0, 1);
        redraw = true;
      } else if (ev.kind == HK_LEFT) {
        editorMoveCursor(-1, 0);
        redraw = true;
      } else if (ev.kind == HK_RIGHT) {
        editorMoveCursor(1, 0);
        redraw = true;
      } else if (ev.kind == HK_ESC) {
        currentState = STATE_TERMINAL;
        terminalDraw(DISPLAY_HEIGHT);
        return;
      }
    }
    
    // Физические кнопки
    if (bOk.pressed()) {
      if (editorIsDirty()) {
        editorSave();
      }
      currentState = STATE_TERMINAL;
      terminalDraw(DISPLAY_HEIGHT);
      return;
    }
    
    if (bCancel.pressed()) {
      currentState = STATE_TERMINAL;
      terminalDraw(DISPLAY_HEIGHT);
      return;
    }
    
    if (bHome.pressed()) {
      currentState = STATE_TERMINAL;
      terminalDraw(DISPLAY_HEIGHT);
      return;
    }
    
    if (bUp.pressed()) { editorMoveCursor(0, -1); redraw = true; }
    if (bDown.pressed()) { editorMoveCursor(0, 1); redraw = true; }
    if (bLeft.pressed()) { editorMoveCursor(-1, 0); redraw = true; }
    if (bRight.pressed()) { editorMoveCursor(1, 0); redraw = true; }
    if (encDelta != 0) { editorMoveCursor(0, encDelta); redraw = true; }
    
    if (redraw) {
      editorDraw(DISPLAY_HEIGHT);
    }
  }

  // ----------------------------------------------------------------
  //  STATE_SETTINGS
  // ----------------------------------------------------------------
  else if (currentState == STATE_SETTINGS) {
    bool changed = false;
    if (bUp.pressed() || bUp.repeat()) { if (settingsChoice > 0) { settingsChoice--; changed = true; } }
    if (bDown.pressed() || bDown.repeat()) { if (settingsChoice < 5) { settingsChoice++; changed = true; } }
    if (encDelta != 0) { settingsChoice = constrain(settingsChoice + (encDelta > 0 ? 1 : -1), 0, 5); changed = true; }
    if (changed) drawSettings();

    if (bOk.pressed() || encClicked) {
      switch (settingsChoice) {
        case 0: // Display Rotation
          displayRotation = (displayRotation == 3) ? 0 : (displayRotation == 0 ? 1 : (displayRotation == 1 ? 2 : 3));
          sendSetRotation(displayRotation);
          saveSettings();
          drawSettings();
          break;
        case 1: // Audio Sample Rate
          snprintf(sampleRateStr, sizeof(sampleRateStr), "%u", audioSampleRate);
          sampleRateEditPos = strlen(sampleRateStr) - 1;
          currentState = STATE_SETTINGS_SAMPLERATE;
          drawSampleRateEditor();
          break;
        case 2: // WiFi Connect
          currentState = STATE_SETTINGS_WIFI;
          drawWifiSettings();
          break;
        case 3: // Clock / Timer
          clockInit();
          currentState = STATE_CLOCK;
          clockDraw();
          break;
        case 4: // Format Internal
          formatInternal();
          drawSettings();
          break;
        case 5: // About
          sendFillScreen(0, 0, 0);
          sendSetCursor(5, 30);
          sendSetTextColor(0, 200, 255);
          sendPrintText("Text Reader v6");
          sendSetCursor(5, 45);
          sendPrintText("RP2040 + ESP32-C3");
          sendSetCursor(5, 60);
          sendPrintText("/sda + /sdb1.. VFS");
          delay(2000);
          drawSettings();
          break;
      }
    }
    if (bHome.pressed() || bCancel.pressed()) { currentState = STATE_MENU; drawMenu(); }
  }

  // ----------------------------------------------------------------
  //  STATE_SETTINGS_SAMPLERATE
  // ----------------------------------------------------------------
  else if (currentState == STATE_SETTINGS_SAMPLERATE) {
    int enc = readEncoderDelta();
    if (enc != 0) {
      int digit = sampleRateStr[sampleRateEditPos] - '0';
      digit = constrain(digit + enc, 0, 9);
      sampleRateStr[sampleRateEditPos] = '0' + digit;
      drawSampleRateEditor();
    }
    if (bLeft.pressed()) {
      if (sampleRateEditPos > 0) sampleRateEditPos--;
      else sampleRateEditPos = strlen(sampleRateStr) - 1;
      drawSampleRateEditor();
    }
    if (bRight.pressed()) {
      if (sampleRateEditPos < (int)strlen(sampleRateStr) - 1) sampleRateEditPos++;
      else sampleRateEditPos = 0;
      drawSampleRateEditor();
    }
    if (bOk.pressed() || bEncBtn.pressed()) {
      uint32_t newRate = atol(sampleRateStr);
      if (newRate >= 1000 && newRate <= 48000) {
        audioSampleRate = newRate;
        setSpeed(audioSpeed);
        saveSettings();
      }
      currentState = STATE_SETTINGS;
      drawSettings();
    }
    if (bHome.pressed() || bCancel.pressed()) {
      currentState = STATE_SETTINGS;
      drawSettings();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_SETTINGS_WIFI  (WiFi-подключение из меню настроек)
  // ----------------------------------------------------------------
  else if (currentState == STATE_SETTINGS_WIFI) {
    // рисуется через drawWifiSettings(), ввод SSID/пароль через OSK
    // для простоты - однократно показываем форму с двумя полями и
    // используем уже существующую OSK-клавиатуру терминала.
    // Навигация: bUp/bDown = переключение поля, OK = подтвердить,
    // Home = выйти обратно в Settings.
    handleWifiSettings(encDelta);
  }

  // ----------------------------------------------------------------
  //  STATE_CLOCK  (часы, таймер, будильник)
  // ----------------------------------------------------------------
  else if (currentState == STATE_CLOCK) {
    clockHandleInput(encDelta);
    bool ringing = clockTickAlarm();
    if (ringing) clockDraw(); // перерисовать при срабатывании звонка
    if (bHome.pressed() && !clockAlarmIsRinging()) {
      currentState = STATE_MENU;
      drawMenu();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_FILE_BROWSER_MENU  (Open / Delete / Info on the highlighted entry)
  // ----------------------------------------------------------------
  else if (currentState == STATE_FILE_BROWSER_MENU) {
    if (bUp.pressed()) { if (fbMenuSelected > 0) { fbMenuSelected--; drawFileBrowserMenu(); } }
    if (bDown.pressed()) { if (fbMenuSelected < 2) { fbMenuSelected++; drawFileBrowserMenu(); } }
    if (encDelta != 0) { fbMenuSelected = constrain(fbMenuSelected + (encDelta > 0 ? 1 : -1), 0, 2); drawFileBrowserMenu(); }
    if (bOk.pressed() || encClicked) {
      if (browserSel < (int)browserEntries.size()) {
        VfsEntry e = browserEntries[browserSel];
        String fullPath = (browserPath == "/") ? ("/" + e.name) : vfsJoin(browserPath, e.name);

        if (fbMenuSelected == 0) { // Open
          if (e.isDir) { browserEnter(e.name); currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
          else if (isImageFile(e.name)) {
            sendFillScreen(0, 0, 0); sendSetCursor(20, 60); sendSetTextColor(200, 200, 0); sendPrintText("Loading image...");
            if (openImage(fullPath)) { currentState = STATE_IMAGE_VIEWER; drawImage(); }
            else { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
          } else if (isTextFile(e.name)) {
            currentFilePath = fullPath;
            if (loadFileLines(currentFilePath)) { textScrollLine = 0; textScrollCol = 0; currentState = STATE_FILE_VIEWER; drawFileViewer(); }
            else { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
          } else if (isAudioFile(e.name)) {
            buildPlaylistFromDir(browserPath);
            selectedMusic = 0;
            for (size_t i = 0; i < musicPlaylist.size(); i++) if (musicPlaylist[i] == e.name) { selectedMusic = (int)i; break; }
            startMusic(fullPath);
            currentState = STATE_MUSIC_PLAYER; drawMusicPlayer();
          } else if (isTuFile(e.name)) {
            currentState = STATE_TU_RUNNER;
            runTuFile(fullPath);
          } else if (isJavaAppFile(e.name)) {
            openJavaInstall(fullPath);
          } else { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
        } else if (fbMenuSelected == 1) { // Delete
          vfsRemove(fullPath);
          refreshBrowser();
          currentState = STATE_FILE_BROWSER;
          drawFileBrowser();
        } else if (fbMenuSelected == 2) { // Info
          collectFileInfo(fullPath);
          currentState = STATE_FILE_INFO;
          drawFileInfo();
        }
      } else { currentState = STATE_FILE_BROWSER; drawFileBrowser(); }
    }
    if (bHome.pressed() || bCancel.pressed()) {
      currentState = STATE_FILE_BROWSER;
      drawFileBrowser();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_FILE_INFO
  // ----------------------------------------------------------------
  else if (currentState == STATE_FILE_INFO) {
    if (bOk.pressed() || bCancel.pressed() || bHome.pressed() || encClicked || encDelta != 0) {
      currentState = STATE_FILE_BROWSER;
      drawFileBrowser();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_HEADING_MENU
  // ----------------------------------------------------------------
  else if (currentState == STATE_HEADING_MENU) {
    if (bUp.pressed() || bUp.repeat()) {
      if (hmSelected > 0) { hmSelected--; if (hmSelected < hmScroll) hmScroll = hmSelected; drawHeadingMenu(); }
    }
    if (bDown.pressed() || bDown.repeat()) {
      if (hmSelected < headingCount - 1) { hmSelected++; if (hmSelected >= hmScroll + HM_VISIBLE) hmScroll = hmSelected - HM_VISIBLE + 1; drawHeadingMenu(); }
    }
    if (encDelta != 0) {
      hmSelected = constrain(hmSelected + (encDelta > 0 ? 1 : -1), 0, headingCount - 1);
      if (hmSelected < hmScroll) hmScroll = hmSelected;
      if (hmSelected >= hmScroll + HM_VISIBLE) hmScroll = hmSelected - HM_VISIBLE + 1;
      drawHeadingMenu();
    }
    if (bOk.pressed() || encClicked) {
      textScrollLine = headingLines[hmSelected];
      textScrollCol = 0;
      currentState = STATE_FILE_VIEWER;
      drawFileViewer();
    }
    if (bHome.pressed() || bCancel.pressed()) {
      currentState = STATE_FILE_VIEWER;
      drawFileViewer();
    }
  }

  // ----------------------------------------------------------------
  //  STATE_CALCULATOR
  // ----------------------------------------------------------------
  else if (currentState == STATE_CALCULATOR) {
    bool needRedraw = false;
    if (bUp.pressed())    { if (calcRow > 0) { calcRow--; needRedraw = true; } }
    if (bDown.pressed())  { if (calcRow < 4) { calcRow++; needRedraw = true; } }
    if (bLeft.pressed())  { if (calcCol > 0) { calcCol--; needRedraw = true; } }
    if (bRight.pressed()) { if (calcCol < 5) { calcCol++; needRedraw = true; } }
    if (encDelta != 0) { calcCol = constrain(calcCol + encDelta, 0, 5); needRedraw = true; }
    if (needRedraw) drawCalculator();
    if (bOk.pressed() || encClicked) { calcPressKey(calcRow, calcCol); }
    if (bHome.pressed() || bCancel.pressed()) { currentState = STATE_MENU; drawMenu(); }
  }

  // ----------------------------------------------------------------
  //  STATE_PLOTTER
  // ----------------------------------------------------------------
  else if (currentState == STATE_PLOTTER) {
    if (plotEditMode == 0) {
      bool needRedraw = false;
      if (encDelta != 0) { double delta = (plotXMax - plotXMin) * 0.05 * encDelta; plotXMin += delta; plotXMax += delta; plotEvalAutoY(); needRedraw = true; }
      if (bUp.pressed() || bUp.repeat()) { adjustYScale(0.8); needRedraw = true; }
      if (bDown.pressed() || bDown.repeat()) { adjustYScale(1.25); needRedraw = true; }
      if (bLeft.pressed() || bLeft.repeat()) { double w = plotXMax - plotXMin; plotXMin -= w * 0.05; plotXMax -= w * 0.05; plotEvalAutoY(); needRedraw = true; }
      if (bRight.pressed() || bRight.repeat()) { double w = plotXMax - plotXMin; plotXMin += w * 0.05; plotXMax += w * 0.05; plotEvalAutoY(); needRedraw = true; }
      if (bOk.pressed()) { plotEditMode = 1; drawPlotEdit(); }
      if (bCancel.pressed()) { plotAutoY = true; plotEvalAutoY(); needRedraw = true; }
      if (needRedraw) drawPlot();
      if (bHome.pressed()) { currentState = STATE_MENU; drawMenu(); }
    } else {
      int enc = readEncoderDelta();
      if (enc != 0) {
        editCharIdx = (editCharIdx + enc + EDIT_CHARS_N) % EDIT_CHARS_N;
        char newChar = EDIT_CHARS[editCharIdx];
        if (newChar != ' ') { plotFunc[plotEditPos] = newChar; drawPlotEdit(); }
      }
      if (bLeft.pressed()) { if (plotEditPos > 0) plotEditPos--; else plotEditPos = strlen(plotFunc); editCharIdx = 0; drawPlotEdit(); }
      if (bRight.pressed()) { if (plotEditPos < (int)strlen(plotFunc)) plotEditPos++; else plotEditPos = strlen(plotFunc); editCharIdx = 0; drawPlotEdit(); }
      if (bOk.pressed() || encClicked) {
        if (plotEditPos < (int)strlen(plotFunc)) {
          for (int i = plotEditPos; i < (int)strlen(plotFunc); i++) plotFunc[i] = plotFunc[i+1];
          if (plotEditPos > (int)strlen(plotFunc)) plotEditPos = strlen(plotFunc);
          drawPlotEdit();
        } else {
          plotEditMode = 0;
          plotEvalAutoY();
          drawPlot();
        }
      }
      if (bCancel.pressed() || bHome.pressed()) {
        plotEditMode = 0;
        plotEvalAutoY();
        drawPlot();
      }
    }
  }

  // ----------------------------------------------------------------
  //  STATE_TU_RUNNER  (вывод запущенного .tu скрипта, Turbine engine)
  // ----------------------------------------------------------------
  else if (currentState == STATE_TU_RUNNER) {
    handleTuRunner(encDelta);
  }

  // ----------------------------------------------------------------
  //  JavaME (.jar/.jad): список приложений / установка / раннер
  // ----------------------------------------------------------------
  else if (currentState == STATE_JAVA_MENU) {
    handleJavaMenu(encDelta);
  }
  else if (currentState == STATE_JAVA_INSTALL) {
    handleJavaInstall(encDelta);
  }
  else if (currentState == STATE_JAVA_RUNNER) {
    handleJavaRunner();
  }

  // ----------------------------------------------------------------
  //  Неизвестное состояние - возврат в меню
  // ----------------------------------------------------------------
  else {
    currentState = STATE_MENU;
    drawMenu();
  }
}
