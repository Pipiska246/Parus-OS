# Parus OS

Кастомная ОС для карманного устройства на RP2040 (+ ESP32-C3 Super Mini
как дисплейный/сетевой мост). Arduino C++, FreeRTOS, собственная VFS
в духе Unix ("всё есть файл"), bash-подобный терминал, скриптовый
движок Turbine, набор встроенных приложений.

Подробная история и архитектурные заметки о FreeRTOS/аудио-движке —
в `docs/HISTORY.md`.

## Структура проекта

```
Parus_OS/
├── Parus_OS.ino          # точка входа: setup()/loop(), UI-экраны, дисплей/UART-glue
├── README.md
├── docs/
│   └── HISTORY.md        # архитектурные заметки предыдущих ревизий
└── src/                  # компилируется рекурсивно Arduino IDE/arduino-cli
    ├── core/              # общая конфигурация и общие UI-примитивы
    │   ├── config.h            # пины, константы (AUDIO_PIN, буферы и т.д.)
    │   ├── FreeRTOSConfig.h    # конфиг FreeRTOS (ядра, тики, куча)
    │   ├── ui_common.h         # общий UI-глий, подключает buttons.h
    │   └── buttons.h           # типы Btn/EncBtn
    │
    ├── vfs/               # виртуальная файловая система "всё есть файл"
    │   ├── vfs.cpp/.h          # ядро VFS: /sda, /sdb1.., диспетчеризация
    │   ├── mount.cpp/.h        # таблица монтирования (/proc/mounts, mount/umount)
    │   ├── devices_vfs.cpp/.h  # /dev/display, /dev/serial и т.п.
    │   ├── gpio_vfs.cpp/.h     # /dev/gpio
    │   ├── input_vfs.cpp/.h    # /dev/input/buttons, /dev/input/keyboard
    │   ├── proc_vfs.cpp/.h     # /proc/mounts, /proc/uptime, /proc/version
    │   ├── audio_vfs.cpp/.h    # /proc/audio — интроспекция аудио-процесса
    │   ├── lib_vfs.cpp/.h      # /lib — манифест слинкованных библиотек
    │   └── bin_vfs.cpp/.h      # /bin — реестр запускаемых приложений
    │
    ├── audio/             # FreeRTOS-движок воспроизведения
    │   └── audio.cpp/.h       # producer/consumer, кольцевой буфер, WAV/MP3
    │
    ├── ui/                # экраны и приложения
    │   ├── osk.cpp/.h          # экранная клавиатура (кнопки)
    │   ├── osk_terminal.cpp/.h # экранная клавиатура для терминала
    │   ├── editor.cpp/.h       # nano-подобный текстовый редактор
    │   └── clock.cpp/.h        # часы, таймер, будильник
    │
    ├── input/             # физические устройства ввода
    │   └── keyboard_hid.cpp/.h # USB HID-клавиатура (хост)
    │
    ├── net/                # сеть через ESP32-мост
    │   └── net.cpp/.h          # WiFi/HTTP/NTP команды
    │
    ├── terminal/           # bash-подобная оболочка
    │   └── terminal.cpp/.h
    │
    ├── scripting/          # скриптовый движок Turbine (.tu файлы)
    │   ├── turbine.h
    │   ├── turbine_lexer.h
    │   ├── turbine_parser.h
    │   ├── turbine_interp.h
    │   ├── turbine_eval.h
    │   ├── turbine_integration.h
    │   └── turbine_logger.h
    │
    └── javame/             # JavaME (.class) runner - CLDC 1.1 подмножество + мини-lcdui
        ├── jvm_config.h          # тюнинг (размер кучи, лимиты стека/классов)
        ├── jvm_types.h           # структуры .class-файла (constant pool, методы, поля)
        ├── jvm_object.h          # модель объектов рантайма (куча, хендлы)
        ├── jvm_classfile.h/.cpp  # парсер .class (через VFS)
        ├── jvm_interp.h/.cpp     # линковка классов (layout полей/static)
        ├── jvm_interp_exec.cpp   # сам байткод-интерпретатор
        ├── jvm_natives.h/.cpp    # System/String/PrintStream/lcdui-lite/MIDlet
        ├── jvm_display_bridge.h  # extern-мост в дисплей/кнопки .ino
        ├── jvm.h/.cpp            # публичный вход (jvmRunMidlet/jvmTick/...)
        └── java_integration.h    # вставляемый в .ino шим (как turbine_integration.h)
```

## Сборка

Это по-прежнему обычный Arduino-скетч — просто открой
`Parus_OS.ino` в Arduino IDE (или собери через `arduino-cli`).
Файлы в `src/**` компилируются рекурсивно самим Arduino-тулчейном
(официально поддерживаемая раскладка sketch'а, см.
[Sketch specification](https://docs.arduino.cc/arduino-cli/sketch-specification/) —
раздел про `src`).

Важно: компиляция `.cpp`-файлов из `src/**` действительно происходит
рекурсивно "из коробки", но **поиск заголовков по путям подпапок
Arduino-тулчейн сам не расширяет** — поэтому все внутрипроектные
`#include` переписаны на явные пути:

- из `Parus_OS.ino` (корень скетча): `#include "src/ui/osk_terminal.h"`
- из файлов внутри `src/<папка>/`: соседние файлы той же папки —
  как раньше (`#include "vfs.h"`), а файлы из других папок — с
  явным относительным путём (`#include "../core/config.h"`,
  `#include "../vfs/vfs.h"` и т.п.)

Это обычное поведение препроцессора C/C++ для `#include "..."`
(сначала ищет рядом с файлом, где стоит `#include`, независимо от
настроек тулчейна), поэтому такая раскладка гарантированно
компилируется в любой версии Arduino IDE/arduino-cli — без
дополнительных `-I` флагов.

Если добавляешь новый файл в один из модулей — не забудь прописать
в нём такие же относительные пути `#include` (или `src/<папка>/файл.h`,
если подключаешь его из `.ino`).

Требуемые платы/библиотеки — см. `docs/HISTORY.md` (раздел
"Необходимые библиотеки / настройки Arduino IDE").
